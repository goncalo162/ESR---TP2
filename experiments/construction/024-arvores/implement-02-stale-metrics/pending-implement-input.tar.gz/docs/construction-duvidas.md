# Dúvidas de Construction

## Q-C-07 — Base de Implement do IMP-004 não compila após alteração externa

- Estado: resolvida por autorização explícita do utilizador para alterar o ficheiro
  e repor as classes, prosseguindo Implement. A suspensão abaixo é histórica.
- O utilizador aprovou ADR e autorizou Implement de 003-overlay, limitado a
  Neighbor.java, NeighborManager.java e NeighborManagerTest.java, preservando
  Q-C-05/Q-C-06 e D01–D22. Pediu identificar separadamente a alteração externa
  de legibilidade em BootstrapServer.java e confirmar equivalência.
- Evidência: contra a base aprovada `26aaa4ae6775e9c78e1d7658472ccaca0b376427`,
  BootstrapServer.java tem +481/−164 linhas. A alteração externa removeu as
  classes internas EventLoop e RealDeadlines, ainda usadas nas linhas 102/107.
  Não é possível confirmar equivalência: a base atual não compila.
- Compilação de diagnóstico com Java 21: `mvn -B -ntp -DskipTests compile`, em
  Projeto/, falhou com quatro erros cannot find symbol para essas classes.
  [Log novo](../experiments/construction/003-overlay/implement-entry-compile.log),
  [diff externo](../experiments/construction/003-overlay/implement-entry-bootstrap-external.diff)
  e [numstat acumulado de Projeto/](../experiments/construction/003-overlay/implement-entry-project.diff.numstat).
  Uma confirmação offline também falhou pelos mesmos quatro erros.
  Não houve execução V-007/regressão/manual nem implementação nos três ficheiros.
- Impacto: não se consegue executar os oráculos/regressão sobre a base atual;
  corrigir BootstrapServer está fora dos três ficheiros autorizados. A regra do
  utilizador exige parar quando o código contradiz o ADD ou exige intervenção
  fora do âmbito aditivo autorizado.
- Proposta para aprovação: restaurar exclusivamente EventLoop e RealDeadlines
  da base aprovada, como correção externa separada, preservando a formatação
  restante; compilar e voltar a verificar a equivalência antes de Implement.
  Não exige substituir uma decisão arquitetural nem criar ADR: é reposição de
  código removido numa alteração externa. Nenhuma correção aplicada nesta inspeção.

- Resolução executada: EventLoop e RealDeadlines repostas da base aprovada;
  compilação passou. Auditoria javac encontrou 102 declarações normalizadas
  equivalentes; 19 testes existentes de bootstrap passaram na regressão final
  de 903 testes. Evidência e limites em
  [Implement](../memory-bank/bolts/003-overlay/implementation-walkthrough.md#correção-externa--q-c-07).

## Q-C-01 — Testes primeiro no IMP-001

- Registada: 2026-11-03T21:03:35Z.
- Estado: resolvida; adaptação aprovada exclusivamente para IMP-001.
- Âmbito: IMP-001, bolt/unidade 001-base-validada.
- Evidência: [IMP-001](../add.md#imp-001) exige verificar TASK-001–005 DONE sem
  reimplementar; o pedido desta execução exige interfaces e testes primeiro,
  com testes a falhar antes de implementar. Não há nova funcionalidade ou API
  prevista neste incremento. O tipo Simple e a DoD excluem código/testes artificiais.
- Proposta: no checkpoint 2 auditar assinaturas/records/enums e correspondência
  entre os testes existentes e V-001–005/V-ADD; não acrescentar ou provocar uma
  falha artificial só para imitar um ciclo de funcionalidade nova. Executar a
  regressão com evidência nova na validação autorizada. Qualquer lacuna real
  deve ser apresentada ao utilizador antes de alterar fundações/testes.
- Impacto: nenhuma mudança de bytes, arquitetura, requisitos ou dependências;
  adapta o procedimento de testes primeiro à natureza de verificação de IMP-001.
- Aprovação: explícita pelo utilizador nesta sessão, registada em
  2026-11-03T21:08:48Z. Apenas conferir interfaces e mapear testes no checkpoint 2,
  apresentando lacunas antes de alterar fundações/testes e parando para revisão.
  Não se autoriza omitir a regressão com log novo ou o teste manual na validação.
  Não altera o procedimento dos restantes IMP nem requer nova ADR.

## Q-C-02 — Compatibilidade do mecanismo de fecho

- Registo do diagnóstico/ensaio: 2026-11-03T21:42:27Z; apenas IMP-001/checkpoint 5.
- Estado: resolvida; ensaio em cópia temporária e fecho real aplicado após
  aprovação/integração em 2026-11-03T21:56:48Z. [Saída real](../experiments/construction/001-base-validada/completion-real.log).
- O script local não existe; o instalado em /home/luis/.specsmd/aidlc/scripts/bolt-complete.cjs
  falha por falta de fs-extra. Também não está disponível js-yaml. A inspeção
  do serializer mostra YAML genérico, incompatível com os valores JSON do
  parser local; não se alterou esse parser nem se instalaram dependências.
- Solução de ferramenta: [preload](../experiments/construction/001-base-validada/bolt-complete-json-frontmatter.cjs)
  que fornece apenas as quatro operações fs-extra utilizadas a partir de Node
  builtin e load/dump do subset local, preservando a lógica/cascata instalada.
- [Ensaio isolado](../experiments/construction/001-base-validada/completion-tool-compatibility.json):
  execução nativa falha antes de escrever; com adaptação, código 0, metadados
  aceites pelo parser local, bolt/história/unidade completos só na cópia,
  intent e os outros 32 bolts preservados. Sem fecho real ou história editada
  manualmente. A primeira tentativa do auxiliar de ensaio assumia a presença
  das dependências; o diagnóstico e o log foram preservados.
- Impacto: nenhum no runtime Java, wire, âmbito ou ADR; é adaptação de ferramenta
  ao esquema já existente. Não dispensa revisão final nem integração, exigidas
  pelo utilizador/DoD antes do estado complete.

## Q-C-03 — Gramática decimal de alpha

- Estado: resolvida; aprovação explícita do utilizador registada em
  2026-11-03T22:25:30Z, juntamente com a aprovação de Design do IMP-002.
- Âmbito: monitor.ewma.alpha, bolt 019-overlay / TASK-032. O
  [ADD 6.3](../add.md#63-parâmetros-operacionais-opcionais) exige representação
  decimal com ponto e valor finito em (0,1]; a gramática exata é o detalhe
  especificado no [Design, secção 4](../memory-bank/bolts/019-overlay/ddd-02-technical-design.md#4-unidades-gramática-e-conversões-verificadas).
- Decisão aprovada: depois de strip, exigir correspondência da string inteira
  com `(?:[0-9]+(?:\.[0-9]+)?|\.[0-9]+)`. Aceitar, por exemplo, `1`, `1.0`,
  `0.2` e `.2`; os exemplos continuam sujeitos ao domínio numérico.
- Rejeitar expoente, hexadecimal, sufixo d/f, vírgula, sinal, unidades, valor
  vazio e decimal sem dígitos depois do ponto, como `1.`. Após o teste lexical,
  usar Double.parseDouble, exigir Double.isFinite e 0 < alpha ≤ 1; overflow
  não finito e underflow para zero são inválidos. Não arredondar/clamp nem
  aplicar o default 0.2 a um valor presente inválido.
- Erros de propriedades entram na ConfigurationException agregada com fonte e
  chave; criação direta do record também mantém finitude e domínio. A ausência
  da chave usa o default existente. Os casos D03/D04/D10/D12 de V-032 verificam
  fronteiras, gramática, agregação e construção direta quando forem executados.
- Impacto: esclarece a representação de uma propriedade nova; preserva valor
  default, papel, domínio de ADR-016, bytes v1, hard caps e perfis existentes.
  Sem substituição de ADR Aceite, dependência ou âmbito adicional; não requer
  ADR nova. A revisão das cinco ADR está em
  [adr-review](../memory-bank/bolts/019-overlay/adr-review.md).
- A aprovação abrange Design/gramática e autoriza somente a etapa ADR nesta
  continuação; não declara implementação, testes, revisão distinta ou integração.

## Q-C-04 — Coerência da instância e resposta única na consulta inicial

- Estado: resolvida; concretizações de Model aprovadas explicitamente pelo
  utilizador nesta sessão, com registo em 2026-11-04T10:50:52Z.
- Âmbito: IMP-003 / bolt 002-overlay / TASK-006, sem alterar o envelope v1.
- Decisões aprovadas: no REGISTER, senderId corresponde a Endpoint.nodeId e
  senderInstance corresponde a Endpoint.instanceId, não zero. Ambos descrevem
  a execução do emissor imediato; esta validação de contexto não cria registo
  vivo ou exclusividade entre pedidos de instâncias diferentes do mesmo nodeId.
- Uma decisão de resposta por conexão de consulta. Depois de escolhida a
  resposta, pedidos adicionais não iniciam outra operação/resposta nem renovam
  o prazo. Design deve especificar como preservar o envio completo já pendente.
- Fonte: pressupostos explícitos do [Model](../memory-bank/bolts/002-overlay/ddd-01-domain-model.md)
  e aprovação do utilizador; aplica ADR-013/014/015. Não acrescenta tipos,
  campos, ACK, lease, membership, hard caps, dependência ou âmbito.
- Clarificação pedida para Design: comparar hosts pela normalização lexical
  documentada (caixa/ponto final/IPv4 decimal), sem DNS nem inferência pelo IP
  remoto; os detalhes devem respeitar o loader e o contrato existente.
- Autorizado apenas Design: fila comum send/sendAndFlush, frame em escrita,
  conclusões fora de locks incompatíveis, prazos/saturação/shutdown e injeções
  de relógio/escrita com oráculos M01–M18 nos cinco ficheiros do IMP. Parar
  antes de ADR/Implement/Test. Esta aprovação não aceita código ou fecha TASK;
  a revisão final atribuída a Waheed e integração continuam exigidas.
- Sem divergência arquitetural identificada por estas concretizações; nenhuma
  ADR nova é criada neste registo.
- Continuação posterior: Design aprovado explicitamente pelo utilizador, com
  registo em 2026-11-04T11:25:40Z, incluindo Transport.requestClose() como início de
  shutdown sem espera, preservando o comportamento público anterior de close().
  Autorizada apenas a etapa ADR, com [revisão para aprovação](../memory-bank/bolts/002-overlay/adr-review.md).
  Esta aprovação posterior substitui o limite de avanço anterior para Design;
  Implement/Test, revisão final e integração continuam pendentes.
- Continuação Implement: revisão ADR aprovada em 2026-11-04T11:37:45Z; autorizado
  apenas Implement nos cinco ficheiros e documentação, com testes novos/red
  real primeiro e incrementais controlados/TCP. Prova no [walkthrough](../memory-bank/bolts/002-overlay/implementation-walkthrough.md).
  Sem decisão nova; parar antes da etapa Test ou fecho, mantendo revisão final
  atribuída a Waheed e integração pendentes.
- Continuação Test: Implement aprovado em 2026-11-04T12:18:01Z; autorizado apenas
  clean verify/JDK21/TCP e manual reproduzível, com comandos para repetição
  pessoal. [Relatório Test](../memory-bank/bolts/002-overlay/ddd-03-test-report.md)
  com 856 testes e 34 checks do agente, sem alteração Java. Manter aprovação
  de Test, repetição pessoal, revisão final e integração pendentes; sem fecho.

- Continuação após Test: aprovação explícita registada em 2026-11-04T14:05:14Z, incluindo
  856 testes e execução pessoal por Luis em 2026-11-04T13:58:36Z–13:58:38Z,
  34 CHECK_PASS/MANUAL_PASS/JAVA_EXIT=0, mesmo JAR. Log pessoal preservado e
  separado do agente. Autorizados preparação do fecho, commits e push de Denji;
  limite anterior sem commits/push substituído. Mantêm-se revisão final atribuída
  a Waheed e integração antes de DONE; nenhuma decisão arquitetural nova.

- Fecho posterior do IMP-003: o utilizador confirmou «fecha o bolt, a revisão esta feita»,
  com registo em 2026-11-04T14:18:23Z, concluindo a revisão final atribuída a Waheed.
  Versão revista 03345e9e1ab56ec04302676cca6fce32d168223d já integrada em main antes do fecho.
  Mecanismo specsmd executado em 2026-11-04T14:18:23Z: bolt/história complete, TASK-006 DONE;
  unidade in-progress. Esta confirmação supera as pendências dos checkpoints
  anteriores. Sem decisão arquitetural nova ou início de outro IMP.

## Q-C-05 — Receção de ERROR no IMP-004

- Registada em 2026-11-10T14:24:46Z, após pedido explícito de ajustes ao Model; IMP-004 /
  bolt 003-overlay / TASK-007. **Estado: resolvida; propostas da tabela aprovadas**.
  Aprovação explícita do utilizador registada em 2026-11-10T14:48:50Z, juntamente com o
  Model revisto. Autorizado apenas Design, sem Java/ADR/Implement/Test.
- Lacuna identificada na revisão humana: a secção 8 do Model referia tipos 7–16,
  sem explicitar ERROR (17). Correção no
  [Model, secção 8](../memory-bank/bolts/003-overlay/ddd-01-domain-model.md#8-autorização-error-17-e-entrega-ao-consumidor).
- Regras já determinadas: [contrato 07, secção 4](07-API-AND-INTERFACES.md#4-mensagens-de-controlo-v1)
  fixa ERROR por requestId, relatedType como octeto bruto e uso pelo routing;
  ADD 6.2/ADR-012/018/020/021 exigem identidade/contexto, falhas locais e recursos
  limitados. O utilizador instruiu expressamente não responder ERROR a ERROR
  e não descartar erros legítimos necessários aos consumidores futuros.
  Essas obrigações não são alternativas em votação.
- O que falta concretizar nas fontes: reação a ERROR inesperado antes de ACTIVE,
  rejeição remota de HELLO_OK ainda em confirmação local e classificação de retry
  após ERROR remoto. As concretizações abaixo foram **aprovadas explicitamente**
  pelo utilizador; não eram regras inferidas das fontes no registo inicial.

| Situação | Decisão aprovada | Razão/limite |
|---|---|---|
| Descoberta: ERROR da tentativa corrente (requestId REGISTER, relatedType=1, geração/connectionId/prazo certos e envelope válido) | Terminar a consulta e guardar a rejeição remota completa; TIMEOUT(10)/RESOURCE_LIMIT(11) permitem nova tentativa com backoff; restantes codes terminam a descoberta em FAILED com evidência para intervenção | Não confundir resposta negativa com NeighborList, não fazer retry imediato e não mascarar erro incompatível como sucesso; codes próprios de routing nesta fase têm diagnóstico de resposta inesperada |
| Handshake: ERROR do HELLO pendente (relatedType=5 e identidade do alvo) | Retirar só o candidato, informar a rejeição completa e voltar a DISCONNECTED; menor ID repete com backoff, maior espera por novo HELLO, para qualquer code válido | Um ID desejado continua desejado, incluindo DUPLICATE_ID transitório; sem nova consulta bootstrap, alteração de grafo ou Up/UDP |
| Recetor de HELLO: ERROR sobre HELLO_OK já enfileirado, ainda HANDSHAKING | Tratar como rejeição dessa tentativa apenas com o requestId do HELLO recebido, relatedType=6 e emissor/instância do HELLO validado | HELLO_OK tem payload vazio; não criar terceiro ACK nem espera adicional. Depois de ACTIVE, ERROR é entregue como mensagem da sessão, não reabre handshake concluído |
| ERROR não correlacionado num canal corrente de descoberta/handshake, fora de uma janela legítima de aplicação | Diagnóstico local com mensagem/sessão/fase e motivo; fechar só o canal ofensor, classificando falha local de contexto, sem atribuir o payload remoto ao pedido corrente | Descoberta com resposta inesperada vai a FAILED; handshake retoma DISCONNECTED/backoff. Nunca emitir ERROR de resposta ou afetar outro vínculo |
| ERROR antigo, de geração/connectionId retirados ou após prazo já terminado | Observar/contabilizar localmente sem reaplicar o efeito à tentativa nova ou mudar a causa terminal anterior | Sem history/cache de tamanho ilimitado e sem descartar erro legítimo de uma sessão corrente |

Na janela legítima de confirmação/flush, um ERROR de aplicação que não pertença
à operação de handshake fica sujeito à retenção limitada e barreira ACTIVE da
secção 6, tal como os restantes frames de aplicação. Não o consumir como rejeição
de HELLO nem o encaminhar antes da confirmação. Se a confirmação falhar, libertar
com diagnóstico, sem o transportar para outra sessão.

Em ACTIVE, encaminhar o ControlMessage/ErrorPayload e a sessão imutável
(nodeId, instanceId, connectionId) intactos ao consumidor. O manager não exige
pedido próprio pendente, não filtra code/relatedType e não fecha um canal saudável
apenas por NO_ROUTE/PATH_CHANGED/etc. O consumidor futuro correlaciona ou produz
diagnóstico local; não se implementa routing neste IMP. relatedType=3/17/desconhecido
continua octeto bruto e nunca dá origem a ERROR de resposta. Identidade inválida
não é uma mensagem legítima dessa sessão: isolar localmente, sem ERROR de resposta.

- Alternativa não adotada: manter a tentativa até ao deadline após ERROR não
  correlacionado antes de ACTIVE. O utilizador escolheu diagnóstico e fecho local
  do canal, fora da janela legítima de aplicação, sem ERROR de resposta.
- Impacto: só políticas de contexto/terminação e entrega de evento nos três
  ficheiros autorizados. Nenhum byte, código, payload, hard cap, dependência ou
  âmbito de routing novo. Não altera fundações nem cria ADR aceite por inferência.
- Oráculos planeados M02/M07/M11 sincronizados com esta decisão, sem execução.
  Model concluído em 2026-11-10T14:48:50Z; autorizada apenas a preparação de Design, com
  retenção/DNS/correlação de dial/executor partilhável concretos. Parar antes
  de ADR/Implement/Test. Revisão final e integração continuam exigidas para DONE.

## Q-C-06 — Prazo próprio de resolução e bind no IMP-004

- Estado: resolvida; concretização e Design aprovados explicitamente pelo
  utilizador, com registo em 2026-11-10T15:13:50Z. Âmbito: IMP-004 / 003-overlay / TASK-007.
- Origem: o [Design, secção 6](../memory-bank/bolts/003-overlay/ddd-02-technical-design.md#6-dns-e-trabalho-físico-limitado)
  propôs usar control.connectTimeout nas operações locais sem propriedade própria.
  Esta regra não era uma imposição do enunciado nem um novo campo wire.
- Decisão aprovada: cada operação de resolução ou bind tem prazo próprio igual
  ao control.connectTimeout efetivo. Capturar o início monotónico **antes da
  entrada na fila**; espera na fila e processamento do resultado não renovam o
  prazo. Uma conclusão que já chega fora do prazo não reativa a tentativa.
- Esse prazo é separado do timeout do dial TCP. Depois da resolução válida,
  Transport.connect continua com o seu próprio connectTimeout nas Options;
  não retirar tempo de DNS a esse timeout nem mudar a API do transporte.
- Aplicar o prazo ao waiter/tentativa lógica; não usar cancelamento, isCancelled
  ou future concluído como prova de terminação física. Job/reserva em execução
  permanece contabilizado até terminar fisicamente. Resultado/handle tardio é
  cercado pela geração e fechado/retirado quando necessário.
- Shutdown usa o budget global independente de control.shutdownTimeout e awaits
  dos recursos reais. Se o worker DNS não terminar no prazo, reportar timeout
  explícito com recurso pendente, sem alegar encerramento bem-sucedido.
- Preservados Q-C-05, defaults/chaves/papéis, bytes v1, hard caps e APIs existentes.
  Não se introduz propriedade, dependência ou ADR nova; reutilizar ADR-014/016/
  017/020/024 e confirmar formalmente na etapa ADR.
- Oráculos D12/D15/D17/D19/D20 concretizam esta decisão; D01–D22 mantidos e ainda
  não executados. Autorizada **apenas ADR** após Design: parar para revisão antes
  de Implement/Test, sem Java/build/testes, commits/push ou outro IMP.

## Q-C-08 — Validação global inclui exemplos de ferramentas preexistentes

- Estado: resolvida em 2026-11-10T16:41:30Z, após aplicação exclusiva do patch
  aprovado e execução real de V-ADD com saída 0/zero erros.
  As falhas/propostas abaixo são histórico anterior a esta resolução.
- A execução real de `python3 scripts/validate-planning.py` nesta continuação
  devolveu três erros fora dos ficheiros implementados: fence não fechado em
  `.specsmd/aidlc/skills/inception/bolt-plan.md` e
  `.specsmd/aidlc/skills/operations/deploy.md`; referência de exemplo inexistente
  `bolts/001-auth-service/adr-001-jwt-auth.md` em
  `.specsmd/aidlc/templates/construction/bolt-types/ddd-construction-bolt.md`.
- Estes ficheiros estavam presentes antes de Implement; o template já tinha
  alterações locais. Não foram modificados nesta execução.
- [Log real](../experiments/construction/003-overlay/implement-planning-validation.log).
  Não alegar V-ADD aprovado: o resultado global é falha, embora o relatório
  confirme a DAG e as contagens de arquitetura. A regressão Java é independente.
- Impacto/proposta: apresentar no checkpoint Implement; corrigir os exemplos
  de ferramentas separadamente se autorizado, ou definir explicitamente o
  âmbito aplicável do validador. Nenhuma exceção foi aprovada por inferência.
  Não altera ADR, wire ou código Java; não impede preparar a revisão autorizada.

### Continuação Test de Q-C-08

O utilizador autorizou apenas Test e determinou manter esta pendência explícita,
sem corrigir ferramentas ou reduzir alcance por inferência. Validador novamente
executado em Test: saída 1 e os mesmos três erros.
[Log](../experiments/construction/003-overlay/test-planning-validation.log).
Auditoria: 67 ficheiros de ferramentas preservados nesta etapa. O build clean
verify (903 testes) e o manual do agente (49 checks/Java 0) passaram, mas não
constituem aprovação de V-ADD ou resolução de Q-C-08.

### Q-C-08 — patch concreto para aprovação

Manual humano de Francisco conferido e aprovado pelo utilizador, com 49 checks
e Java 0 confirmado por ele; não aprova Test ou V-ADD.
[Proposta mínima](../experiments/construction/003-overlay/q-c-08-proposal.md):
três ficheiros, +5/−3 linhas contra o conteúdo local atual, com cópias e hashes
dos inputs. Ensaio isolado: três erros antes, zero depois, 3688 ligações/âncoras
em ambos; validador intacto. Patch ainda não aplicado no repositório.
Q-C-08 permanece por resolver até aprovação/aplicação e execução real de V-ADD.
Sem fecho, commits ou push; revisão humana final e integração pendentes.

### Q-C-08 — resolução autorizada e executada

O utilizador autorizou exclusivamente `q-c-08-proposed.patch` e nova execução
de V-ADD. Hashes de entrada conferidos; diff aplicado exatamente igual à proposta:
+5/−3 em três ficheiros de ferramentas, preservando o restante conteúdo local.
O validador mantém o mesmo SHA-256/alcance. Execução real no repositório:
`python3 scripts/validate-planning.py`, saída 0 e zero erros.
[Diff aplicado](../experiments/construction/003-overlay/q-c-08-applied.diff),
[numstat](../experiments/construction/003-overlay/q-c-08-applied.diff.numstat),
[log](../experiments/construction/003-overlay/q-c-08-v-add-applied.log) e
[auditoria](../experiments/construction/003-overlay/q-c-08-applied.json).
Q-C-08 resolvida; Test continua por aprovar. Manual humano de Francisco cumprido;
revisão humana final e integração pendentes. Sem fecho, commits ou push.

### Confirmação da resolução de Q-C-08 na aprovação de Test

Em 2026-11-10T16:44:29Z (registo), o utilizador aprovou Test incluindo V-ADD e
mandou manter Q-C-08 resolvida. Resolução técnica já suportada pelo patch
aplicado e logs com saída 0/zero erros. Revisão humana final e integração
continuam pendentes; não há autorização de fecho, commits ou push.

## Q-C-09 — NODE_LEAVE na composição do IMP-005

- Estado atual: decisão de âmbito resolvida por autorização explícita do utilizador;
  extensão ainda não implementada nem validada. Model aceite; checkpoint Plan por aprovar.
  O registo abaixo conserva a evidência e proposta originais. Não alterar Java nesta etapa.
- TASK-008, secção 5, exige notificar NODE_LEAVE aos vizinhos diretos quando
  possível, antes de fechar. ADD 8 limita o incremento a OttApplication,
  OverlayNode e OttApplicationTest.
- Evidência da base 2ea748e: NeighborManager.send(), linhas 177–185, rejeita tipo
  que não seja application; application(), linha 430, aceita apenas 7..17.
  NODE_LEAVE é 4. requestClose/close/disconnect não têm emissão de Leave; snapshots
  não expõem canais. O comportamento é igual no checkout atual.
- Impacto: não é legítimo prometer essa operação nos três ficheiros de composição
  sem uma porta pública adequada. Best effort não é autorização para eliminar
  silenciosamente uma operação prevista, criar outro socket ou contornar sessão.
- Proposta para decisão, não aplicada: fornecer uma operação lifecycle aditiva no
  manager, sob extensão de âmbito explicitamente aprovada, ou planear um incremento
  separado que a disponibilize. Preservar send de aplicação, identidade/sessão,
  bytes v1, caps e todos os testes de IMP-004. A confirmação local de escrita,
  o tempo restante e a rejeição de novos comandos devem ser definidos antes de código.
- Não foi provada uma ADR aceite inviável; não se cria ADR-033 por inferência.
  Se a solução exigir mudar política/decisão aceite, aplicar ADD 11 e obter a
  aprovação correspondente. Parar a parte afetada; nenhuma opção autorizada aqui.
- [Modelo](../memory-bank/bolts/020-overlay/ddd-01-domain-model.md). Sem nova
  execução Java/Maven/V-008 ou alteração das fundações.

### Decisão autorizada de Q-C-09 — Model aceite, Plan preparado

Registada em 2026-11-10T17:38:56Z. O utilizador aprovou a extensão mínima aditiva de lifecycle
em NeighborManager e testes próprios, preservando send() de aplicação e o fecho
histórico de IMP-004. A alternativa de incremento separado não foi adotada.
ADD/IMP-005 e contrato 07 passam a documentar essa exceção. Decisão de âmbito
resolvida; a capacidade permanece por implementar e provar com L01–L12/V-008.
Base operacional 90cded6; 2ea748e é referência histórica.
[Plan](../memory-bank/bolts/020-overlay/implementation-plan.md) define operação,
sessões diretas, confirmação local, bloqueio de trabalho/retries, orçamento e
fecho incondicional. Sem alteração Java, nova ADR por inferência, commits ou push.

## Q-C-10 — Reserva do budget de cleanup aprovada

Estado: decisão aprovada explicitamente pelo utilizador, registada em 2026-11-10T17:41:41Z.
A fase best effort de NODE_LEAVE usa no máximo metade do budget global restante
à entrada do primeiro pedido; a outra metade fica reservada para cleanup.
Pedidos repetidos não renovam o prazo; não há timeout completo por vizinho/recurso.
Concretização de Plan, não exigência textual do enunciado nem novo hard cap wire.
Prova futura L04/L06/L07/L11 e M10/M12; sem execução inferida pela aprovação.

## Q-C-11 — Gramática CLI aprovada

Estado: decisão aprovada explicitamente pelo utilizador, registada em 2026-11-10T17:41:41Z.
`--help` apenas sozinho; execução com `--role BOOTSTRAP|SERVER|RELAY|CLIENT` e
`--config <ficheiro>`, ordem livre e cada opção exatamente uma vez. Papéis
maiúsculos; sem aliases, equals ou posicionais. Ajuda combinada, duplicação,
opção desconhecida ou valor ausente: erro 2 antes de abrir sockets.
Escolha de interface do Plan, não transcrição do enunciado. M01/M02/M16 futuros.

## Q-C-12 — Limites locais de I/O aprovados

Estado: decisão aprovada explicitamente pelo utilizador, registada em 2026-11-10T17:41:41Z.
Linha CLI até 4096 caracteres antes de acumular mais; fila de comandos até
runtime.overlay.eventsCapacity, fila de saída até runtime.control.queueCapacity;
registo até 4096 caracteres com truncagem indicada. Excesso de linha tem erro
explícito e consumo limitado; saturação/falha de consumidor é observável e
solicita paragem sem bloquear o owner. São buffers locais, sem novas propriedades,
política wire ou alteração dos hard caps existentes; decisão do utilizador,
não atribuída ao enunciado. M13/M14 futuros, com terminação física a demonstrar.

### Evidência de Implement para Q-C-09–12

Registada em 2026-11-10T18:16:24Z, ainda sujeita à aprovação de Implement. As decisões aprovadas
foram implementadas nos cinco ficheiros, sem alterar send()/wire/caps ou reabrir
IMP-004. L01–L12/M01–M17 têm prova técnica na regressão atual de 979 testes; M18,
clean verify de Test, manual humano, revisão final Waheed e integração pendentes.
O scope Q-C-09 permanece resolvido; as três concretizações Q-C-10–12 continuam
atribuídas à aprovação do utilizador, não ao enunciado. Nenhuma ADR foi substituída.
[Walkthrough e limites](../memory-bank/bolts/020-overlay/implementation-walkthrough.md).

## Q-C-13 — Referência a template inexistente no V-ADD de IMP-005

O V-ADD do checkpoint Test devolveu saída 1 por uma ligação quebrada para
`adr-template.md` no template DDD de `.specsmd/`. As duas referências já
constavam da base operacional `90cded6`. O mesmo erro foi reproduzido no
estado de entrada. O [precedente Q-C-08](#q-c-08--validação-global-inclui-exemplos-de-ferramentas-preexistentes)
regista uma correção documental de ferramentas com validação no repositório.
[Relatório inicial](../experiments/construction/020-overlay/test-consolidation-validation.md).
[Reprodução no estado de entrada](../experiments/construction/020-overlay/test-vadd-entry-repro.log).

O utilizador aceitou a evidência de V-008 e do manual e autorizou a correção
das duas referências. A instrução aponta para o exemplo da etapa 3 e para o
formato de ADR da secção 5 do ADD. A ligação quebrada foi retirada do exemplo
de apresentação. Test permanece em revisão.

Q-C-13 resolvida na execução de 2026-11-10T22:18:21Z. O V-ADD passou no
repositório com saída 0, zero erros e 45 fixtures verificadas.
[Novo relatório V-ADD](../experiments/construction/020-overlay/q-c-13-v-add.log).

## Q-C-14 — Permissões da bancada Linux para V-009

O Plan do IMP-006 foi aprovado com a abordagem de captura no loopback e
corte seletivo de uma sessão TCP. No diagnóstico de 2026-11-10, `tcpdump`
não conseguiu abrir `lo` com a conta atual. Fora do sandbox, `sudo -n`
pediu autenticação. A sondagem de `ss -K` selecionou um único socket
descartável do próprio diagnóstico. O kernel recusou `SOCK_DESTROY`,
apesar do código de saída 0, e o socket continuou a transmitir dados.
[Diagnóstico no anfitrião](../experiments/milestone-1/preflight/permissions-host.json) ·
[Diagnóstico no sandbox](../experiments/milestone-1/preflight/permissions-sandbox.json).

Estado pendente. Para executar o roteiro aprovado é necessário um operador
ou bancada Linux com permissão de captura em `lo` e de corte do socket
selecionado. Uma mudança de abordagem fica sujeita a revisão desta dúvida.
O diagnóstico não abriu sessões da overlay. V-009 aguarda o ensaio e a
repetição por outro elemento.

### Q-C-14 — Permissões confirmadas na bancada local

Registo de 2026-11-10T23:09:30Z. A sondagem de Luis no anfitrião local, com a sua
sessão autenticada, registou `passed: true`. O PCAP contém um pacote do
par descartável e o seletor exato devolveu uma linha antes do corte e
zero depois. Q-C-14 fica resolvida para essa sessão autorizada.
A tentativa anterior do agente conserva o resultado de falha.
[Sondagem de Luis](../experiments/milestone-1/runs/20261110T230622Z-pax81tgv/permission-probe.json) ·
[PCAP da sondagem](../experiments/milestone-1/runs/20261110T230622Z-pax81tgv/probe.pcap) ·
[Sondagem do agente](../experiments/milestone-1/runs/20261110T230236Z-1oy34xz9/permission-probe.json).

## Q-C-15 — Evidência aceite no fecho de V-009

Registo de 2026-11-10T23:25:25Z. O utilizador aceitou o ensaio técnico validado
de V-009 como evidência única de execução e dispensou a repetição por
outro elemento para este fecho. O roteiro continua disponível e a ausência
de repetição independente é uma limitação registada. A tentativa incompleta
e as sondagens mantêm a sua classificação. A revisão final atribuída a
Fillmore foi dada como concluída por indicação do utilizador.
[Registo de Test](../memory-bank/bolts/004-overlay/test-walkthrough.md).

## Q-C-16 — Retoma de Inception para EXTRA-01

Registo de 2026-11-11T12:11:34Z. O utilizador pediu o extra antes de 005-rotas e
confirmou implementar agora a reconstrução da overlay, com vídeo após
routing/streaming. Aprovou o catálogo inicial de candidatos autorizados.

O grafo do exemplo é S–R1–C e S–R2–C, sem S–C inicial. A nova sessão deve
ser criada após a perda dos relays. ADR-019 admite hoje só vizinhos do
grafo inicial. [ADR-033](../add.md#adr-033) propõe a extensão. A política
de gatilho, iniciativa e admissão concorrente aguarda revisão de Model/Design,
antes de alterar Java. A fronteira de validação evita declarar vídeo
entregue quando só a conectividade foi reconstruída.
[Model](../memory-bank/bolts/034-overlay-extra/ddd-01-domain-model.md).

### EXTRA-01 — Cenário assimétrico acrescentado ao Model

O utilizador acrescentou S–R1–R2–C e S–R1–R3–C. A morte de R2/R3
isola C, enquanto R1 continua ligado a S. V-033 inclui a criação de R1–C
e a preservação de S–R1. A política de iniciativa/admissão deve permitir
essa reparação unilateral, dentro dos limites, sem esperar pela falha
do vizinho que R1 ainda conserva. Catálogo inicial e bootstrap apenas
na descoberta de arranque continuam como âmbito aprovado.

### Q-C-16 — Decisão posterior, descoberta por vizinhos

Registo de 2026-11-11T12:26:03Z. O utilizador mandou substituir o catálogo inicial
pela divulgação de vizinhos diretos e pela conservação limitada de
candidatos. O texto anterior conserva a escolha histórica entretanto
substituída. A decisão atual é a aprendizagem durante a execução.

A cache conserva candidatos aprendidos após a morte do anunciante até ao
prazo próprio. Listas divulgam apenas adjacências diretas confirmadas,
com frequência, tamanho e recursos limitados. A ausência de candidatos
aprendidos antes das falhas deve ficar explícita. A extensão de protocolo,
a confiança, o TTL e a admissão aguardam Design/ADR-033. O extra foi
dividido em IMP-034 (aprendizagem) e IMP-035 (reparação), antes de 005-rotas.

<a id="q-c-17--design-da-descoberta-extra-proposta"></a>
## Q-C-17 — Design da descoberta extra (aprovado em Design)

Proposta registada em 2026-11-11T12:49:29Z. **Estado: escolhas aprovadas
explicitamente em Design; aprovação registada em 2026-11-11T13:38:55Z.**
O utilizador declarou «Aprovo Design do IMP-034 e as escolhas de Q-C-17» e
autorizou apenas ADR. A aprovação do Model isoladamente não fixava as escolhas
seguintes; a aprovação posterior de Design inclui a tabela completa.
ADR-033 e contratos afetados aguardam o checkpoint formal G-EXTRA-ADR, antes
de Implement; não se infere autorização de código ou de fecho.
[Design completo](../memory-bank/bolts/034-overlay-extra/ddd-02-technical-design.md)
e [ADR-033 Proposta](../add.md#adr-033).

| Ponto material | Proposta concreta para revisão |
|---|---|
| Isolamento/localização | TCP separado na dataPort já anunciada; UDP mantém OTT1. Sem alteração do HELLO/control v1, sem fallback para essa porta de controlo. |
| Ativação | extra.discovery.enabled=false por default; só SERVER/RELAY/CLIENT. Modo ativo exige portas TCP distintas e C>=8; erro agregado antes de I/O local. |
| Confiança | Só sessão ACTIVE, identidades dos dois extremos, token requestId do HELLO e consulta/canal correntes. Laboratório sem criptografia; candidato continua não admitido. |
| Formato | OTD1 v1, QUERY=1/SNAPSHOT=2, corpo limitado a 32768 bytes, até 63 adjacências diretas, UTF-8 estrito e papéis com códigos explícitos. |
| Validade | generation positiva por sessão, estritamente crescente; TTL local 60 s desde início da consulta, sem renovar por callback/sessão/geração antigos. Morte da fonte conserva claims até ao prazo. |
| Cache/conflitos | 128 IDs × 4 claims; self ignorado; configuração local autoritativa; divergência de endpoint/papel ou colisão entre IDs torna candidato CONFLICT até desaparecer a divergência. |
| Ritmo/recursos | 5 s de elegibilidade por vizinho, 4 consultas/s globais, 1/s recebida por sessão, 30 s após falha; quatro sockets/dials extra sujeitos ao mesmo C<=64, filas 1+1, DNS físico partilhado/limitado. |
| Exceção futura de admissão | IMP-035 poderá criar par fora do grafo apenas com cache válida e contrato aprovado. Menor nodeId continua a iniciar controlo; intenção pode partir de qualquer extremo, permitindo reparação unilateral. |

Não se encontrou uma decisão aceite inviável que exija alterar código nesta
etapa. Estas escolhas foram aprovadas em Design e continuam sujeitas à formalização
ADR/contratos no gate, não a um [PRESSUPOSTO] usado para contornar aprovação. A porta TCP precisa de estar livre e o catálogo aprendido
não garante disponibilidade. Sem cache válida não se inventa reparação.
G-EXTRA-ADR exige ADR-033 e contratos afetados aprovados antes de Implement.
O contrato adicional de reparação pertence ao Design/ADR do IMP-035/V-034.
V-033 e os testes D01–D12 ainda não foram executados.

### Q-C-17 — Entrada na revisão ADR

Registo de 2026-11-11T13:44:19Z. A [revisão ADR](../memory-bank/bolts/034-overlay-extra/adr-review.md)
confirma o âmbito aprovado. Explicita em ADR-033 que extra.discovery.enabled
é a única chave adicional à lista de ADR-010/016, sem alteração das escolhas
aprovadas. Não abre nova decisão de política nem nova Q-C. G-EXTRA-ADR e
aprovação da revisão permanecem pendentes.

<a id="q-c-18--descoberta-no-canal-de-controlo"></a>
## Q-C-18 — Descoberta no canal de controlo

Mudança pedida pelo utilizador, registada em 2026-11-11T14:17:12Z. **Decidido:** parar
OTD1 separado e usar a ligação TCP persistente de controlo, com framing/codec
partilhados, preservando bytes/tipos/caps v1 e as políticas de aprendizagem.
**Ainda proposto:** o contrato concreto da [ADR-034](../add.md#adr-034) e do
[Design revisto](../memory-bank/bolts/034-overlay-extra/ddd-02-technical-design.md).

A proposta usa HELLO/HELLO_OK v2 para seleção de capacidade e tipos 18/19 só
em v2; mensagens normais continuam v1 no mesmo TCP. Incompatibilidade permite
um fallback de handshake para v1, sem upgrade numa sessão ACTIVE saudável.
A fila comum Q+inFlight admite descoberta sem fecho quando cheia e limita
quatro tickets reais de escrita; não existe fila paralela. Frame malformada
pode fechar o controlo, uma consequência nova que exige aprovação explícita.
Deixam de ser necessárias TCP/dataPort, portas distintas ou C>=8 para o extra.
Cache 128×4, TTL 60 s, fontes, gerações e isolamento de callbacks mantêm-se.

ADR-033 conserva as políticas residuais e a aprovação histórica; a escolha
OTD1 foi suspensa, com substituição parcial proposta por ADR-034. G-EXTRA-ADR
reaberto para IMP-034. O âmbito do ADD inclui os ficheiros comuns de protocolo
e testes necessários; IMP-035 mantém o checkpoint próprio, sem início.
[Arquivo preservado](../memory-bank/bolts/034-overlay-extra/closure-walkthrough.md#limpeza-autorizada).
Nenhum Java/teste/target foi alterado nesta revisão; a compilação anterior já
terminara, não é validação da nova proposta. Sem commits, push ou outro IMP.

### Q-C-18 — Refinamento de margem e falhas

> Histórico: a proposta de Q=1 com extra ativo degradar para base não foi
> aprovada. Aplica-se a decisão posterior de extra requerido abaixo.

Registo de 2026-11-11T14:51:37Z. O utilizador pediu margem de fila, comportamento explícito
com Q=1 e rejeição recuperável de conteúdo, mantendo framing/identidade terminais.
A [proposta revista](../memory-bank/bolts/034-overlay-extra/ddd-02-technical-design.md)
define M=1 e E(Q)=min(1,max(0,Q-1)), admissão com duas posições livres e quota
extra enfileirada de um (incluindo transferência take→inFlight). Quatro tickets
globais e Q+inFlight mantêm-se. Q=1 continua válido, mas não anuncia/seleciona
descoberta e usa modo base, sem bypass. Esta indisponibilidade é explícita.

Um anúncio extra completo/delimitado com identidades atuais pode produzir
rejeição tipada de conteúdo, sem fecho ou alteração de cache/watermark/TTL;
o owner confirma o handle e a identidade antes de a considerar recuperável.
Comprimentos inválidos, truncamento, tipo/versão inválidos e identidade
ilegível/incompatível mantêm-se terminais. Não absorver IOException genérica.
D07a–D07e e D08a–D08f cobrem fronteiras, continuidade v1 e corridas.
ADR-034 e contratos continuam Proposta/para revisão, G-EXTRA-ADR pendente;
nenhum código, build, teste Java ou outro IMP foi continuado.

### Q-C-18 — Decisão posterior: extra requerido no projeto

> Histórico: as exceções opcionais/base e eventual falha global foram
> substituídas pelas clarificações posteriores de obrigatoriedade e isolamento.

Registo de 2026-11-11T15:15:24Z. O utilizador **não aprovou** Q=1/incompatibilidade passarem
automaticamente a base. A execução normal exige extra ativo em todos os nós
overlay. As propostas anteriores de fallback e Q=1 em base com flag ativo ficam
rejeitadas, mantidas apenas como histórico nas evidências.

A [revisão](../memory-bank/bolts/034-overlay-extra/ddd-02-technical-design.md)
define enabled⇒Q>=2 validado com erros agregados antes de I/O, supported=required=1
e seleção obrigatória. Incompatibilidade confirmada de peer autorizado/corrente
é erro explícito RequiredDiscoveryIncompatible/FAILED; ausência de resposta é
falha transitória diagnosticada, com retry apenas v2. Nunca ACTIVE_BASE required.
Perfis/API base continuam flag false/default e Q=1 válidos. Bootstrap mantém
consulta inicial. O preflight normal loadProjectDeployment exige todos os perfis
overlay true; não é um catálogo runtime. A margem e os erros de conteúdo da
revisão anterior mantêm-se. ADR-034/contratos por aprovar, sem continuação Java.

### Q-C-18 — Mudança de requisito: nenhuma ativação opcional

Registo de 2026-11-11T15:35:59Z. O utilizador confirmou extra obrigatório em todos os nós
overlay e mandou retirar a ativação opcional/ACTIVE_BASE. Esta decisão substitui
as propostas anteriores de APIs/perfis base de nó, default false e validação
apenas quando enabled. Não existe caminho de construção/carregamento desligado.

A proposta atual deriva o requisito do papel: ausência da antiga chave já é
obrigatório; true é no máximo declaração redundante, false é erro. Todo overlay
exige Q>=2 antes de recursos, mesmo sem chave ou com false; bootstrap mantém
só lookup inicial. Load/loadDeployment e construtores aplicam a mesma relação,
sem loadProjectDeployment paralelo. Formats/transporte genérico v1 não são um
modo de nó base. Peer required=0/sem capacidade é rejeitado explicitamente.

[Justificação dos testes](../memory-bank/bolts/034-overlay-extra/test-contract-migration.md)
separa bytes v1/Q=1 genérico preservados das expectativas operacionais alteradas.
Fonte anterior e evidências mantidas; não houve alteração Java/testes/target.
ADR-034/contratos pendentes antes de Implement; IMP-034 aprende, IMP-035 repara.

## Q-C-18 — Clarificação operacional e isolamento por peer

Registo de 2026-11-11T17:22:59Z; instante de documentação, não atribuído à mensagem humana.
O utilizador fixa um único programa e a mesma versão do JAR em todos os nós.
Todos os overlay implementam/exigem descoberta; não desenvolver funcionamento
com versões antigas, modo base opcional ou fallback. Manter validação de versão,
identidade, endpoint e capacidade. Inputs incompatíveis são negativos do
protocolo; conservar os testes dos formatos v1 que continuam usados.

A consequência FAILED global/failure()/FATAL/saída da CLI proposta acima foi
rejeitada e substituída por rejeição **só da tentativa**, sem NeighborUp e sem
afetar sessões saudáveis (ADR-020). Estado por peer limitado a configurados,
uma tentativa/agendamento e backoff/jitter/deadlines/reservas existentes;
ausência temporária distingue-se de rejeição confirmada, sem trocar protocolo.
D02b–d/D11a exigem B inválido enquanto A permanece ACTIVE, CLI utilizável e
QUERY/SNAPSHOT válidas de A continuam a alimentar a cache.

false/Q=1 continuam erros agregados offline no overlay; não há desligamento
para acomodar recursos insuficientes. Cache/TTL/proveniência/callbacks e fila
comum mantêm-se. [Design](../memory-bank/bolts/034-overlay-extra/ddd-02-technical-design.md)
e [revisão ADR-034](../memory-bank/bolts/034-overlay-extra/adr-034-review.md)
apresentados para aprovação, sem continuar código. IMP-034 aprende; IMP-035
repara, com checkpoint próprio. Registos anteriores são históricos, não modos
operacionais alternativos.

### Q-C-18 — Decisão de controlo TCP uniforme v2

Registo de 2026-11-11T17:47:08Z. Decisão explícita: TCP exclusivamente v2 em bootstrap,
handshake, mensagens normais e descoberta; um contrato/codec, 18 tipos explícitos,
código 3 rejeitado, sem runtime v1/fallback. Arquivo v1 e fixtures v2 independentes
preparados; migração dos testes justificada com garantias preservadas. Bootstrap
continua só inicial, UDP OTT1 inalterado, descoberta obrigatória e isolamento por
peer/CLI saudável mantidos; cache/TTL/proveniência/shutdown conservados.
IMP-034 aprende, IMP-035 repara depois. Design/ADR-034/âmbito para aprovação;
Implement suspenso, sem execução Java, commits, push ou outro IMP.

## Aprovação e retoma de Implement — TCP v2

Registo de 2026-11-11T17:55:50Z; instante do registo, não data atribuída à mensagem humana.
O utilizador aprovou explicitamente Design revisto, ADR-034, âmbito dos 29
caminhos e migração justificada dos testes/recursos para TCP exclusivamente v2.
ADR-034 Aceite: substitui o contrato TCP v1 e as propostas OTD1/mista/ativação
opcional afetadas; v1/fixtures ficam arquivados, UDP OTT1 permanece inalterado.
G-EXTRA-ADR satisfeito para IMP-034; formalizada revisão ADR e retoma apenas
Implement. Um contrato/codec v2 no bootstrap e vizinhos, descoberta obrigatória,
com framing/caps/identidade/unicidade/FIFO/flush/isolamento/shutdown e cache/TTL/
proveniência preservados. Testes incrementais com logs reais autorizados.
Parar para revisão de Implement antes de Test/fecho; V-033, regressão atual,
manual, revisão humana e integração continuam exigidos. IMP-035 mantém checkpoint
próprio; sem commits/push ou início de outro IMP.

## Q-C-19 — Limpeza TCP v1 e fecho solicitado por Luis

Registo de 2026-11-11T19:39:07Z. Após a execução humana V-033 (53 checks, MANUAL_PASS e saída 0), Luis pediu revisão final, integração e fecho do IMP-034, retirando os arquivos/testes da versão TCP v1 e conservando a versão v2. Esta instrução substitui a obrigação documental anterior de conservar o arquivo TCP v1 na árvore entregue. A revisão técnica final é do agente validador, solicitada por Luis; não se atribui revisão a Fillmore ou Waheed. Luis é o operador humano e autor da autorização de fecho.

Conservam-se os negativos que rejeitam TCP v1, todos os testes operacionais TCP v2 e UDP OTT1 inalterado. UDP versão 1 é o formato de vídeo atual, não o codec TCP retirado. A limpeza não altera runtime, framing, caps ou garantias e não inicia IMP-035. O manifesto da limpeza lista paths/hashes retirados; execuções v2, manual humano, regressão e JAR final permanecem. Integração local e publicação remota são registadas separadamente.

## Q-C-20 — Gatilho da reparação do IMP-035

Registo de 2026-11-11T22:22:21Z. **Decidido explicitamente pelo utilizador:**
«Reparar quando fica isolado (recomendado)», em resposta à escolha entre zero
vizinhos ACTIVE e reparar após qualquer perda.

A necessidade autónoma nasce com zero sessões ACTIVE locais. Perder um relay
mantendo outro não inicia uma aresta extra. Um nó saudável pode atender a
intenção do isolado sem perder as suas sessões; não se exige isolamento nos
dois extremos. O menor nodeId conserva a iniciativa do TCP persistente.
Isolamento local não prova partição global, falha física ou ausência de rota.
Sem candidato válido ou recurso, mantém-se diagnóstico e tentativas limitadas.

O critério antigo «extra desativado» de IMP-035/TASK-034 foi alinhado com REQ-025
/ADR-034 já aprovados: todos os nós exigem descoberta/TCP v2, sem modo base
opcional ou fallback. Não há novo formato, alteração de cap ou ADR aceite.

[Model para revisão](../memory-bank/bolts/035-overlay-extra/ddd-01-domain-model.md).
O gatilho está decidido; Model ainda não aprovado. Design deverá concretizar
intenção, admissão e confiança unilaterais, incluindo cache não recíproca,
iniciador menor, limites e corridas. Os oito caminhos atuais do ADD não incluem
protocolo/transporte/cache: apresentar ampliação e eventual ADR-035 Proposta se
esses contratos forem afetados. G-EXTRA-ADR próprio de IMP-035 permanece pendente
antes de Implement. Esta decisão não autoriza Design/Java/Test/fecho/commits/push.

### Q-C-20 — Aprovação de Model e clarificação de atendimento

Registo de 2026-11-11T22:41:27Z. O utilizador aprovou Model e o avanço apenas para Design.
Clarificação: o destino pode estabelecer a ligação pedida pelo nó isolado,
conservando sessões existentes. Manter S–C e S–R1–C, candidatos aprendidos antes
das falhas e S–R1 preservada. Gate próprio/contratos/ADR continuam obrigatórios
antes de Implement. Não é aprovação da proposta técnica Q-C-21 abaixo.

## Q-C-21 — Proposta de intenção, admissão e retorno do IMP-035

**Histórico: proposta não aprovada, substituída pela revisão Q-C-22 a pedido do utilizador.**

Registo de 2026-11-11T22:41:27Z. **Proposto para revisão de Design; não aprovado.**
[Design](../memory-bank/bolts/035-overlay-extra/ddd-02-technical-design.md)
e [âmbito proposto](../memory-bank/bolts/035-overlay-extra/scope-change-proposal.md).

- Permissões opacas emitidas pelo destino aos vizinhos ACTIVE antes das falhas,
  divulgadas só junto de adjacências diretas e retidas para validação após Down.
  Registry256, até quatro por sessão, validade local120 s, renovação elegível30 s;
  geração crescente por sessão e janela30 s de divulgação no anunciante.
  Cache128x4/TTL60 s/proveniência não mudam. Permissão não é autenticação
  criptográfica; confiança em introdução de laboratório é explícita.
- Mesmo TCP/codec v2, quatro tipos20..23 (GRANT/INTENT/RESULT/BIND); 22 tipos ativos.
  SNAPSHOT19 ganha presença/prova por Endpoint, máximo21753 dentro do cap32768.
  HELLO/ACK mantêm formato e exigem máscaras3 (DISCOVERY|REPAIR); rejeitar
  só DISCOVERY sem fallback. Preservar bootstrap/restantes payloads e16UDP;
  migrar sete fixtures e
  preparar24 novas independentes, total alvo90. Sem runtime/fallback de JAR antigo.
- Canal provisório no listener de controlo: isolado menor promove o canal;
  isolado maior instala espera e ACK, destino menor fecha/aguarda terminação
  física e faz dial/BIND de retorno. Uma sessão persistente por par, sem dataPort
  ou listener auxiliar; sessões saudáveis preservadas. Resultado/flush não é ACK.
- Uma tentativa autónoma, duas admissões recebidas, dinâmica<=min(16,C), grau
  total<=min(63,C), orçamento total15 s/subfases2 s, sempre limitado por claim/
  permissão e restante global de shutdown. Backoff/jitter já configurados.
  Quotas/FIFO/Q>=2/tickets físicos mantidos, sem fila/pool/timer ilimitado.
- Connection.terminated() é proposta aditiva que observa fim físico dos workers
  e libertação da reserva, com conclusão fora dos locks, sem bloquear owner.
- Âmbito8→30 e minuta para futura ADR-035 exigem revisão explícita. Não inserir
  ainda tipos/records/fixtures no projeto, nem alterar ADR-034 Aceite por esta
  proposta. Os oito caminhos do ADD continuam o âmbito normativo atual.

G-EXTRA-ADR continua pendente para IMP-035. Este registo não antecipa a etapa ADR
nem autoriza Implement/Test, commits, push ou outro IMP. Todos os D01–D24/V-034
são oráculos planeados; codec Java/mortes reais/manual ainda não executados.

## Q-C-22 — Simplificação da reparação na mesma ligação

Registo de 2026-11-11T23:17:55Z. **Pedido explícito do utilizador:** apresentar proposta mais
simples; o isolado inicia e completa na mesma ligação mesmo tendo o maior ID,
sem dial de retorno. Rever ADR-019 e tentativas simultâneas; justificar o mínimo
de admissão unilateral no laboratório. Não avançar para código antes de contratos/ADR.

[Design revisto](../memory-bank/bolts/035-overlay-extra/ddd-02-technical-design.md),
[ADR-035 Proposta](../memory-bank/bolts/035-overlay-extra/adr-035-proposal.md)
e [âmbito8→21 proposto](../memory-bank/bolts/035-overlay-extra/scope-change-proposal.md).

**Proposta técnica para revisão, não aprovada:**

- Um tipo20 REPAIR_HELLO, payload Hello existente; resposta6 HELLO_OK no mesmo
  TCP. Erros17 existentes, sem códigos novos. Retirar GRANT/INTENT/RESULT/BIND,
  permissões/registry/provas, retorno e API Connection.terminated.
- Origem verifica/regista cache válida/proveniência/TTL. Destino admite o pedido
  unilateral após validação de identidade/endpoint/capacidade/colisões/limites,
  sem exigir cache recíproca. Não comprova a aprendizagem da origem. Esta é a
  confiança cooperativa proposta para o laboratório; não alegar autenticação
  ou rejeição de toda autoafirmação maliciosa com campos válidos.
- HELLO5 configurado conserva grafo e iniciador menor. Exceção20 permite qualquer
  isolado iniciar. Duas saídas pendentes elegem menor originatorId; entrada já
  escolhida bloqueia nova saída para o par; ACTIVE nunca substituída por menor
  ID tardio. Associação de dials/UNCLASSIFIED/B/R e cobrança física preservadas.
- Mesma versão/codec v2;19 tipos1/2/4..20, tipo3 retirado. Capacidades3
  DISCOVERY|REPAIR obrigatórias em HELLO5/20/ACK6, sem subconjunto/fallback.
  Quatro fixtures de máscara migradas e12 novas independentes, alvo78.
  Restantes46TCP/16UDP intactas, incluindo snapshots. Nenhuma fixture alterada agora.
- Cache128x4/TTL60s, C<=64, grau<=min(C,63), Q>=2/quotas da descoberta e owner/
  shutdown preservados. Uma tentativa autónoma, até duas admissões recebidas,
  dinâmica<=min(16,C), backoff existente e orçamento total10s proposto (não SLA).

Decidido pelo pedido: preparar Design direto sem retorno. Ainda propostos:
confiança de admissão, exceção/desempate detalhado, tipo20/máscaras/fixtures/
âmbito e ADR-035. G-EXTRA-ADR próprio permanece pendente. Só Model consta como
concluído; continuar em Design para revisão antes de ADR/Implement/Test.

### Q-C-22 — Aprovação de Design/política/âmbito e revisão ADR

Registo de 2026-11-11T23:28:20Z. O utilizador aprovou explicitamente Design revisto,
política cooperativa e21 caminhos. Aceitou que a origem valide cache/proveniência/
TTL e o destino handshake/limites sem comprovar a aprendizagem. Mantém mesma
ligação, desempate só entre pendentes e ACTIVE preservada. Autorizou apenas
revisão ADR: [ADR-035 Proposta](../add.md#adr-035) formaliza delta parcial019/033/034,
com [revisão antes de Implement](../memory-bank/bolts/035-overlay-extra/adr-review.md).
Não voltar a pedir confirmação da política ou âmbito já aprovados. G-EXTRA-ADR
aguarda aprovação formal desta revisão; não há autorização de Implement.
V-034, regressão, manual humano com mortes reais, revisão final e integração
continuam obrigatórios; sem commits/push/outro IMP.

### Q-C-22 — revisão ADR aprovada, Implement autorizado

Aprovação explícita registada em2026-11-11T23:39:43Z: ADR-035 Aceite, incluindo
substituição parcial019/033/034 e contratos/âmbito21. G-EXTRA-ADR satisfeito para
IMP-035. Só Implement autorizado; Test/V-034 completo/regressão/manual humano
com mortes reais/revisão final/integração pendentes. Sem commits/push/outro IMP.

## Q-C-23 — Composição do monitor na base v2

- Estado atual: opção 1 aprovada explicitamente pelo utilizador; decisão de âmbito resolvida.
  A evidência e opções seguintes preservam o registo original de Model, em 2026-11-12T14:25:37Z; base 3dedf007.
- ADD8 autoriza só NetworkMonitor.java, LinkMetrics.java e NetworkMonitorTest.java.
  Os dois main são placeholders; teste ainda não existe.
- Evidência: NeighborManager fornece Up/Down/Received/Diagnostic/RepairStarted,
  send(Session,...) para 7/8, disconnect(Session) e owner emprestado. OverlayNode
  cria owner/manager privados; APIs de snapshots/descoberta/reparação/lifecycle
  não permitem instalar o monitor com acesso às mesmas sessões/envio/owner.
  OttApplication apenas compõe o observer de logs; não há monitor instalado.
- Impacto: fakes podem provar componente embutível; não demonstram monitor a operar
  na CLI. Owner paralelo, reflexão ou novo transporte contornariam ADR-017/contratos.
- Opção 1: autorizar extensão mínima de composição em OverlayNode e respetivos
  testes, documentando exceção de âmbito e lifecycle antes de implementar.
- Opção 2: confirmar entrega embutível neste IMP, atribuindo explicitamente onde
  e quando a integração real será feita; não declarar monitorização da CLI pronta.
- Nenhuma opção aprovada nesta retoma. Preservar fechos IMP-005/034/035; não alterar
  ADD/contratos/Java por inferência. Não foi demonstrada ADR aceite inviável;
  eventual substituição exigirá próxima ADR livre e aprovação, não reutilizar033.
- [Model](../memory-bank/bolts/005-rotas/ddd-01-domain-model.md), secção8. Parar em Model.

## Q-C-24 — Origem temporal e reset da métrica

- Estado atual: concretizações aprovadas explicitamente pelo utilizador; decisão resolvida.
  O registo seguinte preserva as propostas de Model de 2026-11-12T14:25:37Z.
  Aprovações da retoma cancelada não contam. Não altera Java nem contrato aceite.
- Fontes exigem RTT no mesmo relógio monotónico e reset quando muda instanceId;
  send() existente só confirma enfileiramento. Não fixam um instante de escrita
  observável no manager nem a conservação da EWMA numa nova conexão da mesma instância.
- Proposta nova: guardar início na criação/admissão local da sonda, incluindo filas
  locais até tratamento do PONG. Não chamar RTT no fio a essa medição. Alternativa:
  timestamp de escrita capturado na infraestrutura exigiria porta/âmbito adicional
  e tratamento do PONG que chega antes da conclusão local; não supor flush exposto.
- Proposta nova: qualquer nova Session/connectionId inicia sem amostra, mesmo com
  mesma instanceId, evitando vender RTT de outro canal como atual. Alternativa:
  conservar histórico identificado, limitado e sem custo utilizável antes de nova
  medição; decidir explicitamente se tal histórico influencia ou não a nova EWMA.
- Preservar requestId no PONG já é exigido por docs/07 secção4, que manda respostas
  ecoarem requestId; não necessita nem herda a aprovação cancelada desse detalhe.
- Recomenda-se validar as duas propostas simples antes de Design; nenhuma está
  marcada como aprovada. Oráculos M01/M09/M10/M12/M14 tornam as decisões verificáveis.
- [Model](../memory-bank/bolts/005-rotas/ddd-01-domain-model.md), secções5–8.

### Aprovação de Model/Q-C-23/24 e autorização limitada de Design

Registo em 2026-11-12T14:36:45Z. O utilizador aprovou este Model e Q-C-23 opção1: documentar
extensão mínima de composição em OverlayNode e testes próprios, com allowlist
exata apresentada em Design. Usar mesmo owner/manager/sessões, preservar eventos
alheios e integrar shutdown no budget global; sem transporte ou comando CLI novo.
Aprovou Q-C-24: início na criação/admissão local incluindo filas até tratar PONG;
reset completo por nova Session/connectionId mesmo com mesma instanceId; primeira
sonda elegível no Up e cadência subordinada à conclusão, sem bursts. São decisões
desta retoma, não aprovação reaproveitada da retoma cancelada nem texto do PDF.
Aprovação resolve decisões de âmbito/semântica, não valida comportamento ainda
inexistente. Apenas Design autorizado, parar antes de ADR/Implement.
Sem Java/staging/commits/push; V-010/regressão/manual antes de aprovar Test, revisão
Fillmore e integração obrigatórios, sem gates externos adicionais.


## IMP-007 — Design aprovado; checkpoint ADR

Registo 2026-11-12T14:48:27Z: utilizador aprovou Design e allowlist exata dos cinco ficheiros.
Confirmou revisão de Fillmore do Design atual; não constitui revisão final do
código ainda não implementado. Q-C-23/24 preservadas. Análise ADR preparada para
aprovação, sem divergência/inviabilidade concreta identificada documentalmente;
reutiliza decisões aceites, sem ADR nova ou alteração de estado das existentes.
current_stage=adr; só Model/Design concluídos. Implement/Test não iniciados.
V-010, regressão atual, manual humano antes de aprovar Test, revisão final do
código e integração pendentes; sem gates externos adicionais. Sem Java, staging,
commits, push ou fecho. Relatório: memory-bank/bolts/005-rotas/adr-review.md.


## Q-C-25 — Leitura histórica de NODE_LEAVE face à primeira sonda aprovada

- **Estado:** RESOLVIDA após os dois patches autorizados e regressão04 aprovada tecnicamente (1176/0/0/0); aprovação de Implement/Test ainda pendente.
- **Registo:** 2026-11-12T15:44:13.032355+00:00; evidência real de regressão Implement, não aprovação de Test.
- **Fontes:** Q-C-24/Design aprovado (elegibilidade da primeira sonda no Up),
  preservação expressa de testes históricos e allowlist de cinco caminhos.
- **Evidência:** implement-regression-01.log:1176 testes/2falhas/0erros/0ignorados.
  Uma falha é do novo teste de identidade/ordem e foi corrigida no seu ficheiro
  autorizado (indexOf por igualdade encontrava um Up anterior igual; agora localiza
  a mesma referência). A outra, histórica, é OttApplicationTest.
  m06AndM08ActiveErrorIsObservedAndReconnectNeedsNoBootstrap:342:
  esperava NODE_LEAVE, recebeu PROBE_PING. Os originais/teste histórico estão intactos.
- **Causa:** após nova sessão HELLO5/6, o monitor envia a primeira sonda aprovada;
  o peer controlado histórico lê só um frame após quit e presume que será Leave.
  As mensagens Probe7/8 já são wire v2; esta alteração operacional é precisamente
  o IMP-007 autorizado. Não é uma falha de encode/identidade/flush demonstrada.
- **Impacto:** não se pode declarar regressão verde nem Implement aprovado. Não
  alterar este teste fora da allowlist, desligar monitor, atrasar artificialmente
  a sonda ou esconder/excluir a falha para obter verde. Test continua por iniciar.
- **Opção recomendada:** autorizar exclusivamente o patch de teste
  experiments/construction/005-rotas/q-c-25-proposed.patch, acrescentando o sexto
  caminho Projeto/src/test/java/pt/uminho/esr/ott/app/OttApplicationTest.java só para
  esta adaptação. O peer drena no máximo8 frames/2500ms, aceita apenas PING válido
  v2/identidade da nova sessão/IDs válidos, responde com PONG correlacionado, e
  continua a exigir NODE_LEAVE payload0 e saída0. As garantias históricas de ERROR,
  reconexão sem bootstrap, nova instância e shutdown permanecem; nada é apagado.
- **Alternativa:** manter o teste histórico literalmente intacto, documentando a
  incompatibilidade e a regressão reprovada; sem fecho ou promoção a Test aprovado.
- **ADR:** nenhuma decisão aceite se mostrou inviável; não se propõe ADR nova por
  inferência. O pedido é extensão explícita e localizada de âmbito de teste, não
  substituição de wire, caps, Q-C-23/24 ou política de sondagem aprovada.
- **Estado da proposta antes da resposta humana:** NÃO AUTORIZADA/NÃO APLICADA.


### Q-C-25 — autorização explícita e aplicação exclusiva

Registo 2026-11-12T15:48:58.371559+00:00. Resposta do utilizador: «Autorizar o patch e repetir a regressão
em Implement». Patch exato aplicado após git apply --check, sem staging; hashes
antes/depois registados em q-c-25-application.json. Nova execução focada e regressão
atuais a executar antes de resolver a questão. Sem outro teste histórico alterado,
Test, commits ou push; allowlist ampliada só para esta adaptação concreta.


### Q-C-25 — resultado real e complemento proposto

Registo 2026-11-12T15:51:21.802346+00:00. Teste focado do
patch inicial passou (1/0falhas/0erros/0ignorados). Regressão03:1176 testes,
1falha/0erros/0ignorados; 52monitoring+11integração novos passaram. A única falha
continua no mesmo peer histórico: esperava PROBE_PING durante a drenagem, recebeu
DISCOVERY_QUERY. Não se resolveu a questão só pelo sucesso focado.

Complemento concreto q-c-25-discovery-proposed.patch, NÃO APLICADO: mesmo caminho
e mesmo limite8frames/2500ms. Aceita apenas Query18 com helloRequestId/recipiente/
instanceId exatos da nova Session e devolve Snapshot19 vazio, requestId correlacionado
e geração local crescente. Todos os outros frames continuam a exigir Ping7 ou
Leave4, com identidade v2 correta; mantém Leave payload0 e saída0. Não altera
transporte, tipos, quotas, produção ou outro teste. Autorização inicial era só
o primeiro patch; requer aprovação explícita do complemento antes de aplicar.


### Q-C-25 — complemento aprovado e resolução com evidência

Registo 2026-11-12T15:55:04.977106+00:00. Utilizador respondeu
«Autorizar o complemento e repetir a regressão». Aplicado exclusivamente
q-c-25-discovery-proposed.patch após git apply --check; cadeia de hashes em
q-c-25-application.json e q-c-25-discovery-application.json. Regressão04 executada:
1176 testes,0falhas/0erros/0ignorados,exit0. XML/log preservados em experiments/
construction/005-rotas. Resolve-se a questão de adaptação do peer controlado;
não se promove Implement/Test, fecho, manual ou revisão final a aprovados.


## Q-C-26 — IMP-008: validade, épocas e limites do agregado

- **Registo:** 2026-11-13T16:04:28Z; estado **PROPOSTA/PENDENTE DE DECISÃO**, apenas Model autorizado.
- **Fontes:** ADD 6.1/6.3/IMP-008, ADR-004/017/018/024, docs06/07 e TASK-011.
- **Dúvida:** as fontes exigem validade, melhoria tardia, proteção contra épocas
  retiradas e recursos limitados, mas não fixam todas as regras de retenção da
  tabela. O limite4096 é da cache de flooding, não um orçamento aprovado de rotas.
- **Propostas para revisão do Model:**
  1. Dentro da mesma sessão/época e slot vizinho/stream, sequência mais recente
     substitui o anúncio anterior e inicia nova validade; duplicado ou sequência
     antiga não renovam TTL. Uma melhoria estrita da mesma geração é admitida,
     preservando o prazo dessa geração em vez de o prolongar. Uma mensagem
     obsoleta não retira um candidato válido. Separar estas operações da futura
     deduplicação/flooding de IMP-009; não prometer proteção de replay ilimitada
     depois de eliminado todo o histórico. O Design deve definir a retenção
     limitada necessária para a janela local e testar a fronteira da expiração.
  2. A mudança de época é um evento explícito validado pelo owner futuro, nunca
     uma comparação de UUIDs. Aplicá-la atomicamente a todas as streams daquela
     fonte; conservar épocas retiradas no horizonte existente de anúncios/cache,
     com prazo monotónico e orçamento finito. Se não houver espaço para a proteção
     necessária, rejeitar atomicamente a transição com resultado explícito, sem
     eliminar tombstones ainda válidos para abrir espaço.
  3. Definir em Design limites finitos explícitos para streams, candidatos,
     gerações retidas e épocas, respeitando os caps existentes e sem acrescentar
     parâmetros de configuração. A cache4096 não é reutilizada silenciosamente
     como limite de rotas. Validar capacidade antes de inserir e devolver
     saturação explícita, preservando sessões, alternativas e snapshots saudáveis.
     Os valores e as formas Java ainda não estão escolhidos neste Model.
- **Impacto/âmbito:** somente os seis caminhos de IMP-008; sem RoutingService,
  protocolo, novos timers, executores ou configuração. O transporte e a reparação
  concluídos não são reabertos. Estas concretizações não são ADR aceite.
- **Decisão humana:** não recebida. Se alguma proposta contrariar uma decisão
  aceite, interromper a parte afetada e apresentar ADR de substituição antes de código.
- **Oráculos propostos:** M09–M11/M15; V-011 ainda NÃO EXECUTADO.


### Q-C-26 — princípios aprovados; valores de Design para revisão

Registo 2026-11-13T16:19:45Z. O utilizador aprovou expressamente Model e os três princípios:
renovação só por sequência mais recente, melhoria na mesma geração sem extensão
do prazo; mudança de época explícita/atómica com proteção limitada; capacidades
finitas com saturação explícita, sem expulsar estado saudável. Apenas Design foi
autorizado. As menções anteriores a proposta não aprovada são histórico.

Proposta concreta no [Design](../memory-bank/bolts/021-rotas/ddd-02-technical-design.md),
ainda **PENDENTE DE APROVAÇÃO**:

- 64 origens ×256 streams=16384 linhas; N=min(control.max.connections,63)
  sessões/slots por stream, no máximo16384×N slots/candidatos/watermarks.
- Um watermark por slot corrente, retido durante routing.cache.ttl.ms (default16s)
  desde a admissão de sequência nova; candidato durante candidate.ttl (default8s).
  Nenhuma melhoria/duplicado/métrica renova. Slot logicamente expirado pode ser
  reutilizado atomicamente; proteção não é ilimitada depois do horizonte.
- Oito épocas retiradas por origem/512 totais, protegidas por cache.ttl desde a
  retirada; nona retirada ainda dentro do horizonte é recusada atomicamente,
  preservando época, candidatos e tombstones vivos. UUID nunca ordenado por tempo.
- Linhas UUID→origem persistem na execução e contam mesmo sem candidatos; não
  reutilizar routing.cache.capacity4096. Sem nova chave de configuração ou hard cap
  de deployment. Limits pequenos só para testes; produção64/256/N/8.

Estes números e horizonte não são decisões aceites por efeito da aprovação dos
princípios. Design requer revisão; ADR/Implement/Test não autorizados. D09–D13,
D17/D20/D21 cobrem fronteiras, saturação e retenção; nenhum teste Java executado.


### Q-C-26 — valores e horizontes aprovados integralmente

Registo 2026-11-13T16:41:04Z. Utilizador aprovou Design e valores/horizontes concretos:
64 origens,256 streams/origem, N=min(C,63) slots/stream, oito épocas retiradas por
origem; candidato por candidateTtl e históricos por cacheTtl. Exigiu alocação por
necessidade, sem prealocar máximos; saturação atómica sem expulsão protegida.
Q-C-26 fica **DECIDIDA/APROVADA**; as pendências anteriores são históricas.

A revisão ADR inspecionou as APIs reais: LinkMetrics.costMicros() já é OptionalLong
com ceil da EWMA em µs; encaminhar diretamente, preservando Session completa e
sem reinterpretar SUSPECT como ausência. RuntimeConfiguration valida Duration em
ms inteiros e cacheTtl≥candidateTtl. Nenhum Java alterado ou teste executado.

Só revisão ADR autorizada. A [análise](../memory-bank/bolts/021-rotas/adr-review.md)
está para aprovação; não há autorização de Implement, commits ou push. A futura
ponte de métricas/owner não existe na composição atual e terá de ser definida no
checkpoint respetivo, sem alargar os seis caminhos deste IMP por inferência.


## Q-C-28 — IMP-009: composição operacional fora dos quatro caminhos

- **Registo:** 2026-11-14T11:54:45Z; estado inicial PROPOSTA; **DECIDIDA/APROVADA — Opção1**, só Design agora autorizado.
- **Evidência documental:** [revisão ADR do IMP-008](../memory-bank/bolts/021-rotas/adr-review.md)
  documenta que OverlayNode publica monitoringSnapshot mas não encaminha
  Updated/Invalidated para routing nem expõe subscrição/owner público. Não é
  resultado de uma análise nova de Java em Model.
- **Lacuna:** ADD/IMP-009 só autoriza RoutingService.java, StreamInfo.java,
  StreamCatalog.java e RoutingServiceTest.java. Definir o serviço não o compõe
  automaticamente no programa; não há autorização de alterar OverlayNode.
- **Opção1 recomendada:** ampliar explicitamente o âmbito para seis caminhos,
  acrescentando Projeto/src/main/java/pt/uminho/esr/ott/overlay/OverlayNode.java e
  Projeto/src/test/java/pt/uminho/esr/ott/overlay/OverlayNodeRoutingTest.java.
  Compor início/eventos de vizinhança+métricas/portas de controlo/snapshots e
  shutdown/rollback no owner existente, preservando observadores e testes anteriores.
  CLI de catálogo/trace continua no IMP-010; sem antecipar vídeo ou tipos wire.
- **Opção2:** conservar quatro caminhos, declarar apenas núcleo com portas
  controladas, e planear/autorizar composição operacional noutra tarefa antes de
  alegar anúncios/catálogo na aplicação. Exige ajustar a entrega/rastreabilidade
  de forma explícita; não usar uma bancada isolada como prova do programa integrado.
- **Impacto:** Design precisa de verificar APIs/lifecycle reais na etapa própria.
  Se forem precisos outros ficheiros ou decisão aceite inviável, apresentar antes
  de editar. ADD/interfaces não foram alterados por esta proposta.
- **Oráculos:** M18/M19/M20/V-012; nenhum executado.
- **Decisão humana registada em 2026-11-14T12:31:20Z:** Opção1 expressamente aprovada; ADD/IMP-009 ampliado para seis caminhos. Compor routing no owner/lifecycle existentes, preservando APIs/observadores. Aprovação autoriza apenas Design, sem edição Java. As descrições acima da lacuna e das opções são histórico anterior à decisão.


## Q-C-29 — IMP-009: geração, retirada, publicidade e saturação

- **Registo:** 2026-11-14T11:54:45Z; estado inicial PROPOSTA; **DECIDIDA/APROVADA INTEGRALMENTE — limites e ordens incluídos**.
- **Fontes:** ADR-004/018, docs07 ANNOUNCE9/WITHDRAW10, TASK-012 e Q-C-26 aprovada.
  Root/table aceita só melhoria na mesma geração sem renovar prazo; retirada
  instala watermark que impede repor ANNOUNCE dessa geração no mesmo slot.
- **Propostas de concretização para revisão do Model:**
  1. A fonte gera a sequência por stream/epoch; relays conservam a geração.
     Publicidade usa path/custo selecionados e sequência desse candidato, sem
     copiar a seq de outra alternativa nem inventar uma seq superior no relay.
     Admissão de candidatos e decisão de reenvio são separadas; seen não elimina
     alternativa nem segunda chegada melhor.
  2. Se o anúncio que o relay publicou perdeu validade ou tem de ser substituído
     por informação pior na mesma geração, retirar essa publicidade com a sua
     correlação/seq. A reposição naquele peer aguarda geração mais recente da
     fonte, respeitando o watermark. As alternativas permanecem na tabela local;
     não se acrescenta exceção à Q-C-26, não se forja geração nem se ativa dados.
     Design deve provar este percurso também quando uma alternativa mais recente
     ainda não é a selecionada, sem emprestar a sua sequência ao path antigo.
  3. Cache de flooding cheia: remover só expirados e recusar reserva nova com
     diagnóstico limitado, preservando rotas/catálogo válidos. Rate limit pode
     coalescer uma publicidade corrente dentro de orçamento finito; sem reserva
     não enfileirar trabalho ilimitado, descartar a tentativa e registar o motivo.
     Geração nova pode voltar a tentar; não prometer convergência em overload ou
     criar retry imediato infinito. A fila física segue os contratos já aceites.
- **Decisões ainda de Design:** capacidade das pendências/tickets, horizonte de
  comparações/quotas por destinatário/sessão, consumo de quota e ordenação das
  transições/futures. Valores de configuração e hard caps existentes não mudam.
- **Oráculos:** M03/M04/M06/M09/M10/M12–M15. Estabilização de uma geração não é
  ausência de anúncios periódicos futuros. Nenhuma execução ou aprovação inferida.
- **ADR:** revisão antes de Implement; eventual divergência aplica ADD11.
- **Decisão humana registada em 2026-11-14T12:31:20Z:** princípios aprovados; concretizar limites e ordens em Design, sem forjar sequências ou renovar TTL indevidamente. Q-C-26 mantém-se aceite e inalterada.
- **Concretização pendente de revisão:** [Design secções5–8](../memory-bank/bolts/006-rotas/ddd-02-technical-design.md): ledger S×N, K chaves de flooding/H=cacheTtl, P=min(K,E) coalescers com W+ANN, B=min(E,2N) tickets físicos; quota F numa janela deslizante1s por stream/nodeId conservada após Down; timers2/turnos64/16. W pendente não é apagado por geração nova. Igual custo/saltos com troca de path também exige W+geração nova. ACCEPTED tardio da sessão corrente gera recibo limitado/retirada antiga sem restaurar Root/TTL; sessão antiga só liberta ticket. Nenhum destes valores é aprovado por inferência; D01–D32 planeados, não executados.


### Q-C-29 — aprovação integral posterior

Registo 2026-11-14T12:53:08Z. Utilizador aprovou o Design completo e os limites/ordens
concretos: K cache/H=cacheTtl, ledger S×N, P=min(K,E), B=min(E,2N), janela1s
por stream/nodeId conservada após Down, timers2/turnos64/16, W antes de ANN
novo quando há dívida, floor por peer e recibos antigos sem renovar TTL.
As pendências de aprovação acima são histórico. Só revisão ADR autorizada.


## Q-C-30 — IMP-009: referência de metadados e retenção após expiração

- **Registo:** 2026-11-14T12:42:45Z; estado **DECIDIDA/APROVADA INTEGRALMENTE**.
- **Motivo:** Model exige metadados coerentes por UUID/época e proíbe escolher o
  último anúncio contraditório; faltava decidir a referência e a sua retenção
  quando deixa de haver candidatos. Este pedido autoriza concretizar a proposta,
  não presume a sua aprovação nem passagem a ADR/Implement.
- **Proposta:** [Design secção3.1](../memory-bank/bolts/006-rotas/ddd-02-technical-design.md).
  Oferta local configurada ou primeiro ANNOUNCE remoto validado e efetivamente
  admitido como candidato vivo fixa title/codec/FPS para UUID/origem/época.
  Sem RTT também pode fixar; mensagem rejeitada ou mera reserva de binding não.
  Igualdade exata dos campos, sem normalização implícita do título. Contradição
  é rejeitada inteira antes de qualquer mutação, sem renovar TTL, consumir seq,
  retirar candidato saudável ou fechar sessão; apenas diagnóstico limitado.
- **Retenção/limite:** uma referência imutável por binding na época corrente,
  até256/origem×64=16384, lazy e sem TTL próprio. Persiste após expirarem todos os
  candidatos/cache/watermarks ou após Down/WITHDRAW; catálogo visível desaparece.
  Não guardar tuplos históricos nem reutilizar cache.capacity como este limite.
  Saturação recusa nova admissão sem expulsão ou candidato sem referência.
- **Mudança:** só confirmEpoch aceite elimina referências anteriores dessa fonte
  e permite estabelecer novo tuplo; rejeição preserva tudo. Reinício elimina o
  estado volátil. Sequência maior, reconexão ou expiração na mesma época não
  autorizam alteração. Proteção limitada das épocas retiradas segue Q-C-26,
  sem ampliar oito/cacheTtl ou inventar autenticação/consenso.
- **Oráculos:** D07 fixa M por primeira admissão, rejeita contradição em outro
  caminho e no sender saudável, preservando estado; anúncio coerente posterior
  pode usar a mesma seq rejeitada. D08 avança além dos prazos de candidato/cache/
  watermark, conserva referência com catálogo vazio, rejeita conflito tardio,
  aceita seq100 coerente e só muda tuplo após época nova confirmada. Inclui
  saturação e cardinalidade; permanecem32 oráculos, nenhum executado.
- **Estado da etapa:** só Design para revisão; restantes propostas preservadas.
  Sem gates externos adicionais. V-012, regressão atual, manual humano antes de
  aprovar Test, revisão final Denji e integração continuam obrigatórios.
  Nenhuma ADR nova aceite, Java, commit/push ou outro IMP.

### Q-C-30 — aprovação integral posterior

Registo 2026-11-14T12:53:08Z. Utilizador aprovou a política completa: referência pelo primeiro
candidato admitido/oferta local, igualdade exata, retenção sem TTL na época
corrente≤S, mudança só por confirmEpoch aceite/reinício, conflito rejeitado sem
consumir seq ou alterar estado saudável. D07/D08, incluindo conflito após
expiração, continuam planeados, não executados. Pendências anteriores de Design
são histórico; apenas revisão ADR autorizada, não Implement.

## Q-C-31 — IMP-009: semântica real de recusa de owner e OVERFLOW

- **Registo:** 2026-11-14T12:53:08Z; **DECIDIDA/APROVADA na revisão ADR**.
- **Evidência de fonte:** NeighborManager.Owner.offer chama fail quando a fila
  está cheia e devolve false; requestClose do owner inicia terminação. Em
  Connection.send, queue cheia executa markClosed(OUTPUT_OVERFLOW)/finishClose
  antes de devolver OVERFLOW. Não são recusas com promessa de retoma na mesma
  execução/ligação. [Revisão e assinaturas](../memory-bank/bolts/006-rotas/adr-review.md).
- **Ambiguidade:** Design6 menciona retomar por wake após recusa do owner e7
  pendência limitada após OVERFLOW; falta distinguir essas hipóteses da recusa
  local não terminal em cache/coalescer/quota. Não esconder a diferença nem
  alterar o comportamento real por inferência, depois de o Design ser aprovado.
- **Proposta recomendada:** preservar contratos atuais/ADR-017/020. Recusa de
  owner por fila cheia encaminha cleanup pelo hook de terminação; ticket guarda
  resultado até a conclusão física/callback/continuação terminarem, sem aguardar
  um wake que o owner já não admite. OVERFLOW encerra só a ligação afetada;
  diagnosticar, invalidar pendências correntes pela Session exata e acompanhar
  NeighborDown, sem retry nessa conexão. Recusa local de K/P/quota mantém as
  regras não terminais aprovadas em Q-C-29. Nenhum recurso é declarado terminado
  apenas por cancelamento lógico; outras sessões saudáveis são preservadas.
- **Impacto proposto:** clarificar redação de Design6/7 e expectativas D14/D15/D29
  ao aprovar esta revisão; não criar D33, aumentar âmbito ou editar owner/
  transporte. No momento só registo e revisão, sem aplicar alteração Java.
- **ADR:** não exige substituir decisão aceite se a proposta de preservação for
  aprovada; não foi provada inviabilidade da ADR-017/020. Sem ADR nova por inferência.
- **Estado:** decisão pendente,32 oráculos por executar; sem gate externo novo.
  Implement/Test, V-012/regressão/manual humano/revisão final Denji/integração
  continuam pendentes. A aprovação de Q-C-29/30 não aprova Q-C-31 automaticamente.


### Q-C-31 — aprovação explícita e aplicação documental

Registo 2026-11-14T12:58:05Z. Utilizador aprovou revisão ADR/Q-C-31. Design6/7 e D14/D15/D29
clarificados: recusa local recuperável, OVERFLOW terminal na ligação e saturação
do owner com cleanup pelos hooks sem depender de wake futuro. Só Implement
autorizado nos seis caminhos. Aprovações pendentes acima são histórico.


## Q-C-32 — IMP-010: porta de composição do trace fora dos três caminhos

- **Estado atual:** DECIDIDA/APROVADA, opção1 pelo utilizador; proposta original registada em Plan; registo 2026-11-14T16:16:15Z.
- **Base:**9144707, IMP-006/009/005 completos. ADD8/IMP-010 prevê só
  RoutingService.java, OttApplication.java e RouteTraceTest.java.
- **Evidência concreta:** OverlayNode guarda RoutingService privado, expõe
  routingSnapshot()/monitoringSnapshot(), mas não operação para iniciar trace.
  O construtor com Factory é package-private; OttApplication cria o nó público.
  Um snapshot não autoriza enviar nem oferece owner. Manager/send já suportam15–17.
- **Impacto:** impossível ligar CLI→serviço real só por acréscimo nos três
  caminhos sem contornar encapsulamento ou duplicar estado/transporte.
1. **Recomendada:** autorizar quarto caminho OverlayNode.java para uma delegação
   pública mínima requestTrace(UUID), com resposta limitada antes de start/após
   stop; operação e tipos no RoutingService. Testes próprios em RouteTraceTest.java
   e subprocessos CLI reais, sem alterar testes históricos. Reutilizar owner,
   manager/sessões, eventos e shutdown global; manter send() inalterado.
   Após aprovação documentar exceção no ADD/contratos/índice derivado aplicável;
   não reabrir IMP-009 nem criar ADR automaticamente.
2. **Manter três caminhos:** preparar motor e contratos internos, adiar ligação
   operacional da CLI até extensão explicitamente autorizada; entrega/V-013
   de CLI e fecho permanecem incompletos. Não usar reflexão, registry global,
   segundo serviço ou transporte como contorno.
- **Decisão solicitada:** opção1 ou manutenção explícita da integração pendente.
  Nenhuma extensão de código/ADD aplicada neste Plan.

## Q-C-33 — IMP-010: TTL, correlação, API e limites do diagnóstico

- **Estado atual:** DECIDIDA/APROVADA, opção1 pelo utilizador; concretizações de Plan, não prescrições do PDF;
  registo 2026-11-14T16:16:15Z. Fontes: ADD6/IMP-010/ADR-004/014/017/018/020/022,
  docs07(15/16/17), TASK-013 e API real. Não alterar wire/caps/Q-C-26–31.
- **Lacunas:** TTL é u8 mas não tem código TTL_EXCEEDED; não há configuração
  de prazo/cap de trace, nem operação pública. TRACE_RESULT não contém epoch
  ou custos. Futuro completo no owner pode executar callbacks do chamador.
1. **Recomendada:** aprovar conjuntamente o detalhe do
   [Plan](../memory-bank/bolts/022-rotas/implementation-plan.md): TTL inicial32
   como orçamento de nós incluindo iniciador, ttl0 falha antes de admitir nó;
   ERROR TIMEOUT10/relatedType15/detail TTL_EXHAUSTED distinto de timeout local;
   requestId=traceId preservado, prefixo/stream/epoch e ambas Sessions completas
   guardadas; época divergente PATH_CHANGED e nenhuma escolha arbitrária entre
   alternativas. Prazo local3000ms desde admissão antes da fila, sem renovação,
   retorno pela Session guardada. T=min(E,64) contextos,4 locais/4 por Session;
   S=min(E,64) sends físicos adicionais, no máximo2 por contexto, retidos até
   callback real; intenção limitada ao contexto, sem fila de erros ilimitada.
   Um alarme existente/até2 jobs físicos, wake coalescido e até16 ações/turno.
   TraceTicket com resultado imutável consultável/cancelamento, sem callback
   cliente no owner; até4 tickets CLI e1 cursor de listagem limitada. Custos só
   em logs/snapshots, não no wire. Owner cheio continua fatal(Q-C-31), shutdown
   no budget global, sem novo transporte/executor de estado/comando fora do pedido.
2. **Alternativa:** indicar valores/semântica/API diferentes para rever o Plan
   antes de Java; código de erro novo ou campos wire exigiriam revisão ADR
   explícita de compatibilidade, não uma propriedade de configuração.
- **Decisão solicitada:** aprovar ou ajustar os detalhes; nenhuma ADR aceite
  considerada inviável nesta inspeção, nenhuma decisão nova já aprovada.


### Q-C-32/33 — aprovação explícita e primeiro passo de Implement

Registo 2026-11-14T16:24:54Z. Plan e opções1 de Q-C-32/33 aprovados explicitamente pelo utilizador nesta sessão.
Extensão exclusivamente a OverlayNode.java para delegação mínima requestTrace(UUID).
TTL inicial32 incluindo iniciador; TTL_EXHAUSTED via TIMEOUT10/relatedType15;
prazo local3000ms; correlação/retorno por Sessions completas guardadas;
TraceTicket consultável, limites físicos/CLI do Plan aprovados. Concretizações
locais aprovadas, não imposições do enunciado nem alteração de wire/hard caps.
Apenas interfaces/tipos e testes inicialmente vermelhos autorizados, quatro
ficheiros. Comportamentos, Test, staging, commits/push e fecho não autorizados.
V-013/T01–T18 integral, regressão atual, manual humano, revisão final Fillmore
e integração continuam pendentes; sem gates externos adicionais.

## Q-C-34 — IMP-011: fronteira de cancelamento e validade com IMP-012

- **Estado:** DECIDIDA/APROVADA pelo utilizador em 2026-11-17T17:02:14Z,
  juntamente com o [Model](../memory-bank/bolts/007-arvores/ddd-01-domain-model.md).
- **Decisão:** IMP-011 inclui cancelamento/invalidação lógicos e validade mínima
  para que ACK tardio, cancelado ou expirado não autorize a árvore. Retirar uma
  intenção local identificada não remove a procura dos restantes consumidores.
  Confirmações expiradas não aparecem na projeção utilizável.
- **Fronteira:** CLI stop, renovação periódica, tratamento completo de
  DEACTIVATE e poda propagada continuam em IMP-012. Antes disso não se promete
  transmissão duradoura ou remoção imediata de ramos remotos já concedidos.
- **Design autorizado:** concretizar o lease dos filhos limitado pela
  confirmação remanescente a montante, os limites de tentativas/respostas/
  históricos e os casos de teste. Detalhes concretos de Design não ficam
  automaticamente aprovados por esta decisão de princípio.
- **Limites da autorização:** apenas Design; sem Java, Implement, commits ou
  push. M01–M14/V-014 por executar. Nenhum gate externo adicional.

## Q-C-35 — IMP-011: seleção divergente do ramo confirmado

- **Estado:** DECIDIDA/APROVADA pelo utilizador em 2026-11-17T17:02:14Z.
- **Decisão:** na primeira ativação, revalidar caminho/época antes de confirmar;
  para agregar uma adesão num ramo já ativo, exigir compatibilidade com os
  prefixos selecionado e efetivamente confirmado. Divergência devolve
  PATH_CHANGED sem trocar parent, cancelar filhos saudáveis ou remover a
  confirmação existente. Mudança apenas da métrica, sem mudar prefixo/época/
  sessão, não é divergência de caminho.
- **Consequência:** seleção continua distinta de confirmação. Recuperação e
  troca de árvore ficam nos IMP-013/014. O Design deve prever testes que
  comprovem a recusa de novas adesões e a preservação do ramo confirmado.
- **Pendência técnica:** preservar os logs anteriores de NeighborDown em
  evidência duradoura; investigar antes de aceitar Implement/Test. Sem
  atribuir causa por inferência ou alterar testes/fundações fora do âmbito.
  A aprovação destas decisões não dispensa resolver essa pendência técnica.

### Q-C-34/35 — concretização de Design no checkpoint anterior

O [Design de IMP-011](../memory-bank/bolts/007-arvores/ddd-02-technical-design.md)
concretiza o grant dos filhos pelo restante de montante, ancorado no início do
pedido no recetor, com floor de ms e sem renovar por duplicado. Propõe prazo
global T, até A tentativas, lineagem/maior revisão retida por Session/epoch e
tetos separados para contextos, filhos, históricos, respostas e envios físicos.
As variantes de seleção divergente verificam PATH_CHANGED e preservação de
parent/destinos/leases, sem ativar uma troca. São detalhes de Design ainda
propostos, não novas decisões já aceites ou gates externos adicionais.

Logs de NeighborDown preservados em 2026-11-17T17:03:23Z:
[README e manifesto SHA-256](../experiments/construction/007-arvores/neighbor-down-baseline/README.md).
Três cópias byte a byte, sem repetir testes ou estabelecer a causa. Os14
cenários M01–M14 continuam por executar; à data só Model estava concluído.

### Q-C-34/35 — Design completo aprovado; apenas revisão ADR

Registo 2026-11-17T17:30:07Z. O utilizador aprovou integralmente o Design,
incluindo ancoramento dos leases, prazo global T/até A tentativas, lineagens,
capacidades e quotas propostas. As menções a detalhes ainda por aprovar acima
descrevem o checkpoint anterior; não são o estado atual.

[Revisão ADR preparada](../memory-bank/bolts/007-arvores/adr-review.md) após
conferir APIs reais e integração das projeções/lifecycle. Construtor real de
Snapshot tem quatro argumentos; mantê-lo com forwarding vazio ao acrescentar
a projeção separada. Route/catalog mantêm invariantes de seleção. Desmultiplexar
ERROR11/15 no RoutingService e incluir envios físicos de ativação no seu fecho,
sem alterar componentes externos ou testes históricos. Estes são pontos de
integração nos quatro caminhos já previstos, não novas decisões de âmbito.

Não se identificou necessidade de nova ADR/substituição ou quinto caminho
pela análise estática. Revisão ADR ainda por aceitar, Implement não autorizado.
NeighborDown continua pendente; negativos preservados e investigação obrigatória
antes da aceitação de Implement/Test. Correção fora do âmbito exige apresentação
prévia. Os14 cenários por executar; sem Java, commits ou push.

## Q-C-36 — IMP-011: sincronização da observação de NeighborDown fora dos quatro caminhos

- **Estado:** AUTORIZADA e APLICADA exclusivamente como apresentada. Proposta
  original em 2026-11-17T18:36:18Z; autorização explícita do utilizador nesta retoma
  em 2026-11-17, sem aprovação de Implement ou transição de etapa.
- **Autorização atual:** os quatro caminhos de Implement mantêm-se, acrescidos
  apenas da exceção para OverlayNodeMonitoringTest.java. Outras correções fora
  desse âmbito continuam a exigir apresentação prévia, sem apagar/enfraquecer testes.
- **Evidência consolidada:** o teste histórico espera só pela ausência de N1 no
  snapshot e imediatamente exige NeighborDown na lista externa. OverlayNode
  publica o monitor antes de entregar ao observador. Um novo teste autorizado,
  com OverlayNode/TCP reais e barreira limitada, reproduz a janela e comprova
  a entrega posterior da mesma Session. [Investigação/logs/XML](../experiments/construction/007-arvores/neighbor-down-investigation/README.md).
  Não se reconstrói a interleaving exata dos negativos antigos a partir de logs
  que não a contêm. Os negativos mantêm hashes originais; antes de Q-C-36, o teste
  original passou isoladamente e nas regressões1322/1324, sem alteração.
- **Patch autorizado e aplicado:** somente
  [este patch](../experiments/construction/007-arvores/neighbor-down-investigation/proposed-test-synchronization.patch)
  a Projeto/src/test/java/pt/uminho/esr/ott/overlay/OverlayNodeMonitoringTest.java:
  o until aguarda conjuntamente snapshot sem N1 e NeighborDown da Session esperada.
  Conservar assertTrue, timeout20s, helper5s/poll5ms e restantes testes/fundações.
  Nenhum sleep novo, skip, prazo aumentado ou alteração de produção.
- **Impacto:** único quinto caminho, exclusivamente sincronização de teste.
  Patch aplicado sem mudanças adicionais; nenhum novo tipo/protocolo/ADR/contrato de runtime.
  Decisão técnica/de âmbito, não um gate externo novo.
- **Resultados desta retoma:** [logs/XML/manifestos novos](../experiments/construction/007-arvores/q-c-36/README.md),
  separados dos negativos e do diagnóstico anteriores, preservados sem alterações.
- **Estado do IMP:** Implement reapresentado; NeighborDown focado 1/0/0/0.
  Duas regressões atuais 1324/1/0/0, apenas D11a em OttApplicationTest.java:562;
  D11a isolado 1/0/0/0. NeighborDown/diagnóstico controlado passaram; causa de
  D11a não estabelecida, sem correção adicional. Aceitação pendente. Test/fecho/outro IMP não iniciados,
  sem commits/push. V-014 integral, regressão aprovada, manual humano,
  revisão final Waheed e integração continuam exigidos para fecho.

## Q-C-37 — IMP-011: D11a, erro capturado preterido por continuação de escrita

- **Estado:** INVESTIGAÇÃO CONSOLIDADA; patch AUTORIZADO E APLICADO exclusivamente
  como apresentado, por instrução explícita do utilizador nesta retoma de
  2026-11-17. Implement continua pendente de aceitação; nenhuma etapa promovida.
- **Preservação:** os dois negativos completos 1324/1/0/0 e o sucesso isolado
  1/0/0/0 de Q-C-36 mantêm hashes originais, tal como os negativos/diagnóstico
  de NeighborDown. Os deployments dos dois negativos foram copiados de target.
- **Evidência correlacionada:** uma execução fixa da classe original, com strace
  e sem mudanças Java, passou 48/0/0/0. HELLO e HELLO_OK/selectedMask0 têm o mesmo
  requestId em N0 e N1; o peer escreve os 46 bytes e fecha, o nó lê todos os bytes
  e emite REQUIRED_DISCOVERY_MISSING na conexão correspondente. Session vazia
  durante a negociação, sem fabricar identidade de uma ligação ACTIVE.
- **Defeito comprovado em ensaio controlado:** a continuação de escrita de HELLO
  pode estar antes do protocolError na fila do owner, mas correr depois do fecho
  físico pelo reader. `write` retira então o contexto como TRANSPORT; o handler
  do erro capturado encontra-o ausente e perde a rejeição. Com as classes intactas,
  três ordens fixas dão TRANSPORT/REQUIRED_DISCOVERY_MISSING/REQUIRED_DISCOVERY_MISSING.
  Não se avançou o relógio nem se alteraram prazos.
- **Limite da atribuição:** isto demonstra um mecanismo que produz o sintoma;
  os negativos antigos não permitem reconstruir os requestId negativos ou a
  ordem interna exata de cada execução. Não se toma a execução instrumentada
  verde como correção ou aprovação da regressão.
- **Patch autorizado e aplicado:** [patch de dois caminhos](../experiments/construction/007-arvores/d11a-investigation/proposed-hello-continuation.patch).
  Em `NeighborManager.java`, apenas HELLO inicial de saída, não ACTIVE e canal
  fechado: deixar a decisão ao protocolError/Closed ordenados ou ao prazo atual.
  Em `NeighborManagerTest.java`, acrescentar teste das três ordens com correlação
  e rejeição confirmada. Não remover/alterar testes ou asserções existentes,
  nem aumentar prazos. A autorização específica acrescenta apenas estes dois
  caminhos aos cinco anteriores; nenhuma outra correção fica autorizada.
  `git apply --check` passou e o patch foi aplicado sem ajustes.
- **Prova e comandos:** [relatório/trace/logs/ensaio](../experiments/construction/007-arvores/d11a-investigation/README.md).
  A investigação anterior conserva os seus logs e estados históricos; resultados
  desta aplicação separados em `experiments/construction/007-arvores/q-c-37/`.
  [Resultados desta aplicação](../experiments/construction/007-arvores/q-c-37/README.md):
  D11b/três ordens 1/0/0/0; D11a original 1/0/0/0; handshake/lifecycle 202/0/0/0;
  regressão incremental completa 1325/0/0/0. Nenhuma repetição da suite até verde.
- **Sem resposta:** dois ensaios controlados comprovam terminação por Closed ou
  prazo HELLO existente, com contexto/tentativa/timer antigos libertados e só retry
  limitado existente. TCP real comprova fecho/EOF e prazo de 3 s, zero reservas
  nativas e awaitTermination no shutdown configurado de 1,5 s. Nenhum prazo mudou.
  O primeiro lançamento do instrumento parou por cwd incorreto antes da parte TCP;
  log preservado, corrigido apenas o lançamento. A prova efetiva está separada.
- **Estado:** apenas a exceção Java expressamente autorizada, sem avanço a Test, fecho,
  commits, push, outro IMP ou gates externos adicionais. V-014 consolidado,
  regressão aprovada, manual humano, revisão final Waheed e integração pendentes.


## Q-C-38 — IMP-011: bloqueio de compilação preexistente fora dos sete caminhos

Estado: DECIDIDA/APROVADA pelo utilizador; patch mínimo aplicado exclusivamente como proposto.
Retoma M07 em main9c5ad094, árvore limpa à entrada. A primeira tentativa Maven
parou na compilação de OttApplication.java:878, antes de executar M07. O
construtor Console usa this::read, mas o único método é read(InputStream).
O ficheiro coincide com HEAD e não foi alterado nesta retoma. Isto não é
reprodução negativa do defeito de cancelamento, nem resultado de regressão.

[Log preservado](../experiments/construction/007-arvores/m07-cancellation-01/red/maven.log)
e [patch proposto de uma linha](../experiments/construction/007-arvores/m07-cancellation-01/q-c-38-proposed.patch).

1. Recomendada: autorizar exclusivamente a lambda () -> read(input) nesta linha
   de OttApplication.java, oitavo caminho limitado a repor a compilação. Mantém
   reader virtual, input e comportamento pretendido; sem handshake/transporte,
   wire, dependências ou prazos novos. Só aplicar após autorização explícita.
2. Manter os sete caminhos: M07 pode ser investigado por compilação focada e
   isolada do core, sem CLI e sem alterar esta fonte; o build/regressão integral
   continuam bloqueados e não podem ser declarados aprovados.

Implement continua pendente, Test não autorizado; nenhum commit/push/fecho.


### Q-C-38 — aprovação explícita e aplicação exata

Registo 2026-11-17T22:15:01.350853+00:00. O utilizador autorizou
«Autorizar o patch mínimo e a regressão completa». Acrescenta OttApplication.java
apenas para a lambda () -> read(input); patch aplicado sem ajustes. Não aprova
Implement/Test/fecho nem permite outras alterações de CLI. M07 já reproduzido
num core fresco isolado, com1 falha funcional esperada; não é regressão integral.

## Q-C-39 — V-ADD: whitespace preexistente em CODESTYLE

Aberta, sem correção aplicada. A validação documental desta retoma encontra um
único erro: trailing whitespace em docs/style/CODESTYLE.md. O ficheiro é idêntico
a HEAD/entrada e alheio ao âmbito autorizado.
[Relatório](../experiments/construction/007-arvores/m07-cancellation-01/v-add.json) e
[proveniência/linhas/hash](../experiments/construction/007-arvores/m07-cancellation-01/v-add-limitation.json).
Opções: autorizar patch exclusivamente de whitespace nessas linhas; ou preservar
o ficheiro e manter V-ADD pendente. Não alterar validador, código ou prazos.
Implement permanece pendente; esta descoberta não invalida os 1328 testes Java
executados nem autoriza Test/fecho.

### Q-C-39 — correção autorizada aplicada

O utilizador aceitou tecnicamente M07 e autorizou exclusivamente remover espaços
finais nas linhas 26, 28, 91, 105, 138 e 178 de CODESTYLE.md. Aplicado sem outras
alterações nesse ficheiro; código Java e validador preservados.
[Patch e prova](../experiments/construction/007-arvores/q-c-39/README.md).
Implement continua pendente de aprovação; Test não autorizado.

Q-C-39 RESOLVIDA: V-ADD executado após o patch autorizado, zero erros.
Relatório preservado na evidência Q-C-39; nenhuma alteração ao validador.

## Q-C-40 — IMP-012: correlação e revisão da renovação

Estado: DECIDIDA/APROVADA pelo utilizador nesta etapa Model, registo 2026-11-18T15:45:34Z.
Evidência estática: RoutingService.ActivationEngine.Line retém a maior revisão,
requestId canónico e fingerprint; incoming rejeita requestId diferente na mesma
revisão (REVISION_BOUND). ACTIVATE e RENEW usam o mesmo payload Activation;
ACTIVATE_ACK12 não transporta um tipo de operação próprio.

Opções apresentadas: (1) mesmo subscriptionId, revisão crescente e requestId novo
por renovação; (2) mesma revisão e ledger próprio de ciclos de renovação, exigindo
proteção adicional contra replay. O utilizador escolheu **opção1**.
A correlação inclui Session completa/stream/epoch/ID/revisão/requestId e a espécie
local da operação; o ACK12 de renovação não confirma ativação ou renovação antiga.
O Design ainda deve concretizar o cancelamento durante renovação admitida/em voo,
a revisão transportada por DEACTIVATE e a preservação do grant anterior até
substituição válida. Long.MAX_VALUE não permite wrap; não se muda wire.
Nenhuma implementação/teste executado, nova ADR ou aprovação de Model inferida.

## Q-C-41 — IMP-012: RENEW com seleção divergente da confirmação

Estado: DECIDIDA/APROVADA pelo utilizador nesta etapa Model, registo 2026-11-18T15:45:34Z.
Q-C-35 rege novas adesões; o contrato14 revalida prefixo/epoch, mas não esclarecia
se renovação de ramo confirmado poderia dispensar a seleção atual.

Opções apresentadas: (1) recusar RENEW divergente com PATH_CHANGED e preservar
o grant atual; (2) renovar pelo ramo confirmado, com política distinta para
adesões novas. O utilizador escolheu **opção1**.
Recusa preserva parent, filhos/consumidores e prazos ainda válidos; não prolonga
lease nem troca parent. Sem renovação válida, a autorização expira no prazo
anterior. Recuperação/troca ficam em IMP-013/014, não implementadas por inferência.
Q-C-35 e o fecho histórico de IMP-011 preservados. Nenhuma mudança de bytes/caps.

## Q-C-42 — IMP-012: fronteira de CLI stop e âmbito de três ficheiros

Estado: DECIDIDA/APROVADA pelo utilizador nesta etapa Model, registo 2026-11-18T15:45:34Z.
Evidência: OttApplication reconhece play como NOT_IMPLEMENTED e não tem comando
stop; OverlayNode só delega requestTrace, não requestSubscription. Q-C-34 menciona
CLI stop em IMP-012, enquanto o ADD/âmbito autorizado limita a três caminhos.
TASK-015 lista NeighborManager, mas essa lista legada não alarga o ADD.

Opções apresentadas: (1) manter os três ficheiros e esclarecer a fronteira CLI;
(2) preparar exceção mínima de composição fora deles. O utilizador escolheu
**opção1**: IMP-012 fornece renovação/poda e cancelamento pela SubscriptionTicket
existente/DEACTIVATE de rede. A ligação à CLI fica para a composição posterior
de cliente/aplicação, sem a declarar entregue neste IMP. Esta concretização
clarifica a frase de Q-C-34, sem apagar o seu histórico ou reabrir IMP-011.
Nenhuma extensão a OverlayNode/OttApplication/NeighborManager, transporte,
comando CLI, runtime ou dependência. Model apenas; Design não autorizado.

### Q-C-40–42 — Model aprovado; Design concretizado, por aprovar

Registo 2026-11-18T16:04:20Z. O utilizador aprovou Model e reconfirmou as três opções1,
autorizando apenas Design. [Design proposto](../memory-bank/bolts/023-arvores/ddd-02-technical-design.md)
concretiza a revisão a podar (maior submetida da geração retirada), match exato
remoto, expiração como fallback quando a renovação não foi admitida, P constante
por grant e prazo cortado pelo restante, intenções únicas/limites partilhados e
shutdown sem fase adicional. ACK/ACCEPTED tardios não afetam substitutas, nem
libertam reserva antes de callback e continuação acabarem.
Esses detalhes novos aguardam aprovação do Design; não são novas decisões já
aceites, ADR, alteração de âmbito ou execução de testes. Sem dúvidas novas que
exijam substituir uma ADR aceite; não se criou outro Q-C por inferência.

### Q-C-40–42 — Design aprovado; revisão ADR preparada

Registo 2026-11-18T16:15:43Z: utilizador aprovou Design, matriz RENEW/DEACTIVATE, revisão
submetida/match exato/lease fallback, cadência fixa, prazos restantes e limites.
Apenas revisão ADR autorizada. [Revisão estática](../memory-bank/bolts/023-arvores/adr-review.md)
reutiliza decisões aceites, sem divergência arquitetural concreta ou inviabilidade
identificada. F01–F07 são adaptações futuras do código dentro dos três ficheiros;
grant anterior, terminais M07 e finally/contabilização físicos preservados.
Nenhuma ADR nova/substituta/estado aceite alterado, nenhuma Q-C nova por inferência.
Revisão ADR por aprovar; sem Implement/Java/testes Java/staging/commits/push.

### Q-C-40–42 — ADR aprovada; primeiro passo de Implement

Registo 2026-11-18T16:51:40Z. Utilizador aprovou revisão ADR/reutilização, autorizando
somente interfaces/tipos e testes vermelhos nos três ficheiros.
[Checkpoint](../memory-bank/bolts/023-arvores/implementation-walkthrough.md):
4 tipos internos, nenhum comportamento do engine alterado.22 testes novos,
20 falhas de asserção/0 erros/0 ignorados;30 históricos selecionados verdes,
6 M07 incluídos. Negativos preservados; restantes comportamentos/V-015/
regressão integral pendentes. Nenhuma Q-C nova ou ADR inferida; limites mantidos.

### Q-C-40–42 — Implement aprovado; Test autorizado

Decisões inalteradas: revisão crescente, grant saudável preservado perante
RENEW divergente e três ficheiros/sem CLI. [Test](../memory-bank/bolts/023-arvores/ddd-03-test-report.md)
consolida clean verify1379/0/0/0,19 XML,TCP real e callbacks/limites/shutdown.
Sem dúvida/ADR nova, alteração wire/caps/validador ou inferência de aprovação.
Manual humano e aprovação Test pendentes; revisão final Denji e integração depois.

### Q-C-40–42 — Test aprovado, revisão final/integração pendentes

Utilizador aprovou Test com1379/0/0/0,19 XML,V-ADD e manual Francisco30.
[Resumo para Denji](../memory-bank/bolts/023-arvores/final-review-summary.md):
decisões inalteradas, código/JAR e negativos preservados; sem nova ADR/âmbito.
Revisão final Denji não confirmada e integração pendente. Sem fecho/staging/commits/push.

### Q-C-40–42 — revisão final Denji confirmada

Aprovação final da mesma implementação confirmada explicitamente pelo utilizador,
sem alterações pendentes. [Versão e plano](../memory-bank/bolts/023-arvores/integration-plan.md),
hashes e simulação atualizados; decisões40–42 inalteradas,sem nova ADR/âmbito.
Integração por autorizar/executar; sem staging/commits/push/fecho.

### Q-C-40–42 — fecho documental após integração

Decisões preservadas sem reabertura: IMP-012/TASK-015 DONE após integração4d18d1d,
Test1379/0/0/0,19 XML,Francisco30 e revisão Denji. [Fecho](../memory-bank/bolts/023-arvores/closure-walkthrough.md).
Sem nova ADR/Java/âmbito,validador intacto,negativos preservados. Unidade/fase em
progresso,sem push ou outro IMP.

## Q-C-43 — IMP-013: intenção local e interesse descendente após perda de upstream

- **Estado:** APROVADA explicitamente pelo utilizador em 2026-11-20T11:07:54Z.
  Proposta inicial preservada em model-01/design-01; Model/Design/ADR aprovados, Implement autorizado e por aceitar.
- **Base:** ADR-005/020 preservam intenção de consumo, não subscrição de conexão
  morta; Q-C-35/41 preservam grant saudável antes da perda efetiva.
- **Questão:** como tratar o filho cuja Session continua viva quando o parent do
  relay falha, sem prolongar lease ou autorizar path diferente implicitamente.
- **Decisão aprovada:** intenção local conserva-se até cancelamento; interesse
  do filho conserva-se só enquanto Session/época e prazo original são admissíveis.
  Autoridade dependente fica suspensa após perda upstream. Interesse limitado pode
  justificar recuperação agregada; prefixo/época novos exigem pedido fresco
  correlacionado e confirmação antes de conceder autoridade novamente ao filho.
  Session morta, expiração ou cancelamento retiram interesse remoto; uma conexão
  nova não o herda. A espera de recuperação não renova o lease.
- **Alternativa:** eliminar todo o interesse dos filhos imediatamente e aguardar
  pedidos novos, com possível atraso de recomposição. Alternativa não adotada na aprovação.
- **Modelo/limites:** [secção5](../memory-bank/bolts/008-arvores/ddd-01-domain-model.md).
  Sem nova mensagem/enum, persistência, CLI ou caminho Java adicional aprovado.

## Q-C-44 — IMP-013: ronda finita e rearme após indisponibilidade

- **Estado:** APROVADA explicitamente pelo utilizador em 2026-11-20T11:07:54Z.
  Proposta inicial preservada em model-01/design-01; Model/Design/ADR aprovados, Implement autorizado e por aceitar.
- **Questão:** intenção pode sobreviver a partição, mas cada operação deve terminar;
  duplicados/adesões/callbacks não podem reiniciar orçamento de recuperação.
- **Decisão aprovada:** uma ronda coalescida por árvore/incidente com prazo
  total/tentativas limitadas. Sem alternativa ou limites esgotados, termina em
  UNAVAILABLE; intenção ainda admissível pode ser reavaliada perante novidade
  útil de candidato/Session/época, sem reinício humano, sem spin da mesma visão e
  sem trocar parent que continua saudável apenas por melhoria de RTT.
- **Design futuro:** concretizar novidade útil/rearme, correlação e limites dentro
  dos tetos existentes. Recusa física pode ser reavaliada na ronda ainda válida;
  libertação de callback antigo não reabre ronda terminal. Sem parâmetro/recurso novo aprovado.
- **Clarificação explícita aprovada pelo utilizador em 2026-11-20T11:34:53Z:** após
  RESOURCE_LIMIT temporário de admissão, libertar callback/capacidade por si só
  não reabre ronda terminal. Um ANN validado recebido depois da falha, com G
  estritamente superior ao watermark bloqueado/consumido, pode fornecer um
  crédito coalescido para reavaliar admissão mesmo com Session/época/path iguais.
  Preservar capacidade, T/A, cadência e validade da intenção/candidato; sem novo
  pedido humano, extensão de prazo antigo ou aprovação global de Design.
  Ao terminal por saturação, bloquear a prova já observada mesmo sem envio,
  para que crédito anterior não sobreviva como retry por timer. Se ainda não há
  capacidade, nenhum envio indevido; novo terminal atualiza o watermark.
  Duplicados/ANN anteriores à falha/callbacks não rearmam. Erros permanentes,
  revisão esgotada, cancelamento e shutdown não ganham este tratamento.
- **R13 acrescentado, não executado:** saturação temporária → UNAVAILABLE →
  capacidade libertada sem retry espontâneo → ANN novo válido posterior à falha
  → recuperação automática limitada, sem novo pedido humano; duplicados não rearmam.
- **Modelo/limites:** [secção6](../memory-bank/bolts/008-arvores/ddd-01-domain-model.md).
  Não promete recuperação em partição permanente ou perda exclusiva UDP;
  sem ADR nova, alteração Java, Implement/Test ou gate externo adicional.

## IMP-013 — checkpoint Model

Apenas Model autorizado pela seleção explícita do utilizador.
[Proposta de domínio](../memory-bank/bolts/008-arvores/ddd-01-domain-model.md) e
Q-C-43/44 aguardam aprovação; V-016/R01–R18 planeados/não executados.
Sem fontes lidas/analisadas/alteradas, Maven, Design/ADR/Implement/Test, commits
ou push. Fechos, negativos e evidências anteriores preservados.


## IMP-013 — Model/Q-C-43/44 aprovados; apenas Design

Registo 2026-11-20T11:07:54Z: aprovação explícita do utilizador. Design deve concretizar
novidade útil/rearme, limites das rondas e renegociação automática dos filhos,
sem intervenção humana ou extensão de prazos antigos. Três caminhos do ADD
preservados; qualquer ampliação será apresentada antes de alterar código.
V-016/R01–R18 não executados; sem Implement, commits ou push. Fecho: testes,
regressão JDK21, manual humano, Fillmore e integração; sem gates externos novos.

## Q-C-43/44 — concretização proposta em Design em 2026-11-20T11:21:05Z

Model/Q-C-43/44 aprovados; apenas Design autorizado. [Design proposto](../memory-bank/bolts/008-arvores/ddd-02-technical-design.md):

- F estrutural=(stream/origem/época/Session completa/path); G=announceSeq. RTT,
  custo, snapshot/tick e mesmo F/G não são novidade. G novo observado depois
  de PATH_CHANGED/NO_ROUTE/SOURCE_UNAVAILABLE/TIMEOUT pode fornecer um crédito
  limitado; não comprova grant remoto. Watermark bloqueia provas já observadas
  à falha; uma prova coalescida, sem lista de eventos ou rondas.
- T=activateTimeout/A=activateAttempts existentes, defaults3000ms/3. Prazo global
  desde admissão, até A envios admitidos; novas adesões/erros não renovam T/A.
  Uma ronda automática por T por stream; timer só pode gastar crédito útil já
  obtido, não o cria. Novidade durante ronda usa orçamento restante.
- Filho preserva grant saudável só até ao prazo original; seleção divergente/
  ERROR14 não o revogam por inferência. Após perda efetiva, reativa automaticamente
  com11, mesma lineagem na Session/época e revisão maior/requestId novo. Sem
  RENEW14 para recriar grant expirado ou ACK espontâneo do parent. Interesse
  suspenso só vive até ao seu prazo; filhos com intenção persistente reconstroem
  os saltos por pedidos frescos, sem comando humano ou lease antigo estendido.
- Propostas de valores/projeção locais em Route e Snapshot com construtores4/5
  preservados, dentro dos três caminhos. Compatibilidade real por conferir em ADR;
  necessidade de ampliação será apresentada antes de código.

Os detalhes técnicos acima aguardam aprovação de Design; não são Implement ou
alteração de ADR. V-016/R01–R18 não executados; sem fontes lidas/analisadas/
alteradas, Maven, commits ou push. Testes, regressão JDK21, manual humano,
revisão final Fillmore e integração continuam exigidos para fecho, sem gates novos.


## IMP-013 — Design reapresentado após clarificação de RESOURCE_LIMIT em 2026-11-20T11:34:53Z

Alterada exclusivamente a política de rearme após pressão temporária de admissão,
na secção4 e R13 do [Design](../memory-bank/bolts/008-arvores/ddd-02-technical-design.md).
A clarificação em Q-C-44 está autorizada; Design completo continua por aprovar.
T/A, cadência, capacidades, watermark, três caminhos, renegociação dos filhos e
restantes políticas preservados. Sem ADR/Implement, fontes lidas/alteradas,
Maven, commits ou push. V-016/R01–R18 não executados. Fecho exige testes,
regressão JDK21, manual humano, revisão Fillmore e integração; nenhum gate novo.

## IMP-013 — Design revisto aprovado; revisão ADR preparada

Registo 2026-11-20T11:45:38Z. Design revisto e clarificação de Q-C-44 aprovados
pelo utilizador em2026-11-20T11:41:00Z; apenas revisão ADR autorizada.
APIs reais conferidas estaticamente: announceSeq/Outcome disponíveis, watermark
interno privado sem necessidade de API nova; intenção distinta de resultado do
ticket, mudança de época, ACTIVATE/revisões, construtores4/5/projeções e lifecycle.
Revisão para aprovação, sem impedimento de âmbito identificado ou nova ADR.
A01–A08 são trabalho futuro nos mesmos três caminhos; nenhuma correção aplicada.
V-016/R01–R18 não executados; fontes só consultadas, sem Java alterado, Maven,
Implement/Test, fecho, staging, commits, push ou outro IMP. Negativos/provas
anteriores preservados. Fecho exige testes, regressão JDK21, manual humano,
revisão final Fillmore e integração, sem gates externos adicionais.
[Revisão completa](../memory-bank/bolts/008-arvores/adr-review.md).

## IMP-013 — Implement reapresentado, sem aceitação/Test

Registo 2026-11-20T12:27:18Z. Utilizador aprovou ADR e autorizou apenas Implement A01–A08
nos três caminhos do ADD, com CODESTYLE, históricos/correlações/construtores e
reservas físicas preservados. Implement preparado para revisão: regressão JDK21
incremental final1414/0/0/0,20 XML,35 testes novos e1379 históricos byte intactos.
Duas integrações TCP reais com métricas controladas passaram; negativos guardados
separadamente, incluindo R13, prazo de fila, R18/fixture, R17 inicial sem causa
estabelecida e alternativa consumida R10. Remoções/substituições justificadas no
walkthrough; sem teste/asserção/prazo histórico retirado ou fundação alterada.
Só Model/Design/ADR em stages_completed; current_stage=implement, completed=null.
Implement ainda por aceitar; sem etapa Test, fecho, commits/push ou outro IMP.
V-016 consolidado, regressão da etapa Test, manual humano antes de aprovar Test,
revisão final Fillmore e integração continuam obrigatórios; sem gates novos.
[Walkthrough e prova](../memory-bank/bolts/008-arvores/implementation-walkthrough.md).

## IMP-013 — R10 corrigido; Implement permanece pendente

Registo 2026-11-20T15:44:31Z. Implement continua pendente. Reprodução exata com G2,
Long.MAX_VALUE-1000, métrica10→2000→10 após PATH_CHANGED/T3s: negativo preservado
esperado1/observado2 ACTIVATEs. A transição previous==null agora confere blocked
antes de conceder crédito; métrica isolada não reutiliza a prova bloqueada.
Primeira medição válida, anúncio novo posterior e T/A/cadência preservados.
11 testes R10 focados passaram; regressão JDK21 atual1419/0/0/0,20 XML,
40 RecoveryTest (35 anteriores intactos+5 novos),1379 históricos intactos.
Delta Java só em RoutingService e RecoveryTest; Route/fundações inalterados.
R17 inicial mantém causa não estabelecida. Sem aceitação de Implement, Test,
fecho, commits ou push. V-016 consolidado, manual humano, Fillmore e integração
pendentes; sem gates externos adicionais.
[Walkthrough atualizado](../memory-bank/bolts/008-arvores/implementation-walkthrough.md).

## IMP-013 — Test técnico, aguardar manual humano

Registo 2026-11-20T16:07:46Z. Implement/R10 aprovados; apenas Test autorizado.
Clean verify JDK21 novo1419/0/0/0,20 XML e JAR504997bytes/SHA256
81779be388778fd7dfacba5957e74ccffe5da45e86a403ea1ec5626f52c8f49d.
V-016/R01–R18 consolidado tecnicamente; fontes/históricos/evidências intactos.
Manual humano preparado:7 etapas/28 checks. Ensaio kind=agent passou no JAR
congelado, hashes/origem/JVM conferidos; não satisfaz obrigação humana.
Aguardar repetição pessoal antes de pedir aprovação Test. Test não aprovado;
R17 inicial sem causa estabelecida, integração com métricas controladas não
prova a causa. Nova correção exige reprodução/âmbito apresentados.
Sem fecho/staging/commits/push/outro IMP; Fillmore/integração pendentes,
sem gates externos adicionais.
[Relatório Test](../memory-bank/bolts/008-arvores/ddd-03-test-report.md).

## Fecho após integração comprovada

Registo 2026-11-20T16:23:16Z: Test/manual Luis7/28 e revisão Fillmore aprovados;
integração main 447ae4bf68bf96329bd1a0c7e16ed20df06bc55b comprovada.
Bolt/história complete,implemented=true,TASK-016 DONE; unidade/fase em progresso.
Negativos e limitação R17 preservados,sem causa estabelecida. Nenhum outro IMP
iniciado;024 apenas desimpedido. Commit/push autorizados,sem Java/build/manual novo.
[Fecho](../memory-bank/bolts/008-arvores/closure-walkthrough.md).

## Q-C-45 — IMP-014: melhoria, observações e permanência

- **Estado:** APROVADA explicitamente pelo utilizador; registo 2026-11-21T14:21:52Z.
  Proposta original de2026-11-21T14:13:30Z preservada abaixo; apenas Design autorizado.
- **Questão:** 20%/três observações/cinco segundos estão no ADD; importa definir
  comparação, consecutividade e âncora sem contar duplicados como estabilidade.
- **Proposta:** comparar custo contemporâneo do caminho confirmado com a
  alternativa válida: N<C e100×(C−N)≥P×C, sem overflow/arredondamento. Ausência
  não é zero; hops só desempata. Contar entradas reais distintas de métrica ou
  ANN de geração nova, uma vez por evento; valores iguais de medições distintas
  podem contar. Snapshot/tick/callback/ANN duplicado não contam.
- **Sequência:** mesmo F=(stream/origem/época/Session completa/path), contador
  saturado em O; invalidade, falta de melhoria ou mudança de alternativa/F
  reinicia. Primeira comparação válida conta uma vez; retorno de elegibilidade
  não ressuscita uma prova bloqueada. G novo do mesmo F pode continuar sequência.
- **Permanência proposta:** primeira confirmação e cada troca confirmada
  ancoram D; renovação do mesmo ramo, tentativa falhada ou seleção não reancoram.
  Qualificação pode acumular antes de D, mas tem de continuar válida ao admitir
  troca. Timer não inventa observação. Falha real ignora P/O/D.
- **Limites:** defaults e domínios centrais preservados; sem parâmetro, wire,
  histórico ilimitado ou gate externo novo. Conferência de APIs reais apenas
  na etapa apropriada, sem leitura de fontes neste Model.
- **Modelo/oráculos:** [Model](../memory-bank/bolts/024-arvores/ddd-01-domain-model.md),
  V-017/S01–S08 planeados, não executados. Aprovar ou ajustar antes de Design.

## Q-C-46 — IMP-014: troca limitada, backoff e continuidade

- **Estado:** APROVADA explicitamente pelo utilizador; registo 2026-11-21T14:21:52Z.
  Proposta original de2026-11-21T14:13:30Z preservada abaixo; apenas Design autorizado.
- **Questão:** coordenar melhoria e recuperação preservando o parent saudável,
  a intenção e as reservas, sem repetir uma ativação falhada com a mesma prova.
- **Proposta:** uma troca pendente por árvore, com T/A e reservas físicas
  partilhadas já existentes; manter grant antigo enquanto válido até confirmação
  nova compatível e barreira de envio. Publicar uma confirmação atómica, depois
  podar apenas a revisão antiga capturada. Não copiar grants para prefixo novo;
  filhos renegociam automaticamente pela intenção admitida, sem alargar prazos.
- **Backoff proposto:** terminal de qualidade reinicia qualificação e bloqueia
  F/G; aguardar T existente desde esse terminal. Nova troca requer prova útil
  posterior (F novo válido ou ANN validado com G superior ao watermark) e nova
  sequência de O observações, além de D/capacidade/cadência. Não propor outro
  parâmetro. Timer, capacidade libertada ou métrica inválida que volta a válida
  não desbloqueiam prova. O ANN novo pode contar como primeira observação.
- **Falha real:** não espera histerese/backoff de qualidade; usar recuperação
  IMP-013, sem prorrogar tentativa pendente, duplicar orçamento ou apagar os
  bloqueios/créditos Q-C-44/R10. Cancelamento/timeout lógico não liberta reservas
  físicas; shutdown continua a aguardá-las no lifecycle existente.
- **Âmbito:** os três caminhos do ADD/IMP-014; NetworkMonitor legado não autoriza
  mudança adicional. Qualquer impedimento/ampliação será apresentado previamente.
- **Modelo/oráculos:** [Model](../memory-bank/bolts/024-arvores/ddd-01-domain-model.md),
  V-017/S09–S18 planeados, não executados. Sem Design/ADR/Implement/Test.

## IMP-014 — checkpoint Model, apenas documentação

024-arvores iniciado por opção1 em2026-11-21T14:10:07Z. Model/Q-C-45/46
propostos para revisão, não aprovados. V-017/S01–S18 não executados.
Sem fontes Java lidas/analisadas/alteradas, Maven, commits, push ou outro IMP.
R17 inicial de IMP-013 permanece sem causa estabelecida; integração com métricas
controladas não demonstra a causa. Evidência e hashes anteriores preservados.
Revisão final Waheed, testes/regressão JDK21, manual humano e integração continuam
obrigatórios para fecho futuro; sem gates externos adicionais.

## IMP-014 — Model/Q-C-45/46 aprovados; apenas Design

Registo 2026-11-21T14:21:52Z: aprovação explícita do utilizador. Concretizar identidade
das observações, cálculo exato, permanência/revalidação, confirmação atómica,
poda antiga, renegociação dos filhos e coordenação com renovação/recuperação.
T/A e reservas físicas partilhados; falha efetiva não espera histerese/backoff
de qualidade. Três caminhos do ADD e testes históricos preservados.
V-017/S01–S18 não executados; sem Implement, commits ou push. Manual humano
antes de aprovar Test, regressão JDK21, Waheed e integração obrigatórios; sem
gates externos adicionais. Limitação histórica de R17 preservada.

## Q-C-45/46 — concretização proposta em Design

Registo 2026-11-21T14:29:02Z: Model/Q-C-45/46 aprovados; apenas Design.
[Design para revisão](../memory-bank/bolts/024-arvores/ddd-02-technical-design.md):

- M=(Session completa,sampleCount,sampleCountSaturated,lastSampleAtNanos);
  contagem crescente ou, após saturação, instante monotónico que avança.
  A=(F,G) após validação/aplicação, G novo; APPLIED com G igual não basta.
  Uma entrada conta uma vez por Tree; coalescência pode subcontar, nunca
  multiplicar. Primeira comparação conta uma vez, não por recriação de cursor.
- Melhoria exacta: q=C/100,r=C%100; redução mínima=q×P+(r×P+99)/100.
  Exigir N<C e C−N≥mínimo; sem overflow/double. D na primeira confirmação
  e mudança efectiva de ramo, não em14/tentativa falhada. Revalidar antes
  de enviar e antes do commit; timer não cria observação.
- Ramo antigo congelado antes da nova11, incluindo maior11/14 submetida.
  Confirmar novo apenas com ACK12 actual+ACCEPTED, lease ancorado no início
  da tentativa; publicar atomicamente e depois podar a revisão antiga exacta.
  Fallback é lease remoto, nunca poda aproximada que remova revisão nova.
- Filhos incompatíveis ficam sem forwarding pelo novo prefixo; interesse
  conserva deadline antigo. Renegociação automática por ACTIVATE fresco,
  sem ACK espontâneo/novo play humano/extensão de lease antigo.
- Uma operação upstream lógica:14 pendente mantém prazo original;11 por
  qualidade/recuperação partilha cursor T/A e reservas físicas canónicas.
  Falha efectiva retira autoridade e ignora P/O/D/backoff de qualidade;
  tentativa útil continua sem reiniciar T/A. Callback/timeout lógico não
  liberta físico. Shutdown usa o primeiro budget existente.

Três caminhos do ADD e testes históricos preservados. Viabilidade nas APIs
reais ainda por conferir na futura revisão ADR autorizada, sem leitura de
fontes nesta etapa. V-017/S01–S18 por executar. Manual humano antes de aprovar
Test, regressão JDK21, Waheed e integração obrigatórios; sem gate externo novo.
R17 histórico sem causa estabelecida, não explicado pela integração controlada.
Sem Implement, commits/push ou outro IMP. Design não aprovado por este registo.

## Q-C-47 — IMP-014: observabilidade real e contrato de entrega

- **Estado:** APROVADA alternativa B e revisão ADR pelo utilizador; registo de aprovação 2026-11-21T15:03:15Z.
  Proposta original preservada abaixo. Registo 2026-11-21T14:54:50Z. Model/Design
  aprovados; apenas revisão ADR autorizada, sem Implement ou ampliação de âmbito.
- **Impedimento sustentado:** RoutingService.Event só tem Reason/fatal
  (RoutingService136), note conta falhas (884–887), e o adaptador de routing
  em OverlayNode135–140 ignora eventos não fatais. Diagnostics não transporta
  stream/custos/motivo/duração da troca. O `recovery` da aplicação é o estado
  de descoberta OverlayRecovery, não a recuperação de árvores. Os mecanismos
  existentes não satisfazem os logs de troca previstos em TASK-017/Design.
- **Prova e adaptações A01–A08:** [revisão ADR](../memory-bank/bolts/024-arvores/adr-review.md).
  Nenhum ficheiro Java foi alterado ou patch aplicado para contornar a lacuna.

### Proposta A — conservar os três caminhos, alterar explicitamente a observabilidade

Acrescentar em RoutingService o valor aninhado imutável SwitchDiagnostics e
um mapa `Snapshot.switches`, no máximo uma entrada por Tree/slot C. Propõe-se
sétimo componente no record Snapshot e overload de seis argumentos com esse
mapa vazio; preservar os overloads4/5 e o construtor6 actualmente canónico,
bem como accessors e semântica de catálogo/routes/forwarding/recoveries.
A compatibilidade proposta é de chamadas Java; o formato completo de
record/toString/equals passa a incluir o novo mapa e não é declarado inalterado.

| Grupo de dados | Contrato proposto, limitado por Tree |
|---|---|
| Contexto | stream/origem/época, operação opcional, fase interna e motivo local; não reutilizar ErrorCode/failure para sucesso |
| Ramos | Session completa/path antigo e alvo, até32 IDs cada; revisão antiga submetida e revisão alvo, opcionais quando não aplicáveis |
| Política/prova | custos opcionais actuais, P/O/D, contagem≤O, G observado/bloqueado e indicação de prova suficiente; ausente não é zero |
| Tempo | capturado no mesmo turno; restante de D/backoff/operação e duração decorrida, sem renovar prazos pela leitura |
| Totais | inícios/sucessos/falhas saturados e flag de saturação; um último estado, sem lista de incidentes/amostras |

Publicar defensivamente no mesmo owner, dentro de C, sem tocar em Route.java,
CLI, logger, dependências, threads, wire ou reservas. Dados de qualidade não
autorizam forwarding nem mudam a projecção de recuperação de IMP-013. Remover
com o estado lógico correspondente; sem segundo ledger/TTL ou histórico global.
Usar RouteSwitchTest para valores/copias/limites e construtores4/5/6/7, sem
alterar testes históricos. A evidência/manual futuro poderá consultar a API
por harness; o CLI actual **não** passa a mostrar o mapa automaticamente.

**Alteração que precisa de aprovação:** substituir a promessa de custos/motivos
logados automaticamente por diagnóstico consultável nesta entrega e aceitar
a extensão do Snapshot. Isto ajusta o Design/TASK-017 expressamente; não
considerar equivalência implícita nem adiar a obrigação sem decisão humana.
Nenhuma alteração normativa dessas foi aplicada. Os três caminhos mantêm-se.

### Alternativa B — manter logs automáticos, com excepção prévia de âmbito

Preservar Snapshot4/5/6. Acrescentar payload imutável de troca ao RoutingService.Event,
com overload2 compatível para todos os emissores anteriores, e emitir apenas
transições de início/fim/falha (sem log por observação ou nota de falha falsa).
Em OverlayNode, adicionar sink de routing explícito por factory nomeada,
preservando construtores/factories anteriores e tratamento fatal. Em
OttApplication, ligar esse sink à fila limitada existente `console.log`.
Sem logger/worker/fila nova, I/O no owner, mensagem fictícia ou alteração dos
eventos sealed de NeighborManager. Confirmar a publicação nova antes do evento
de sucesso e da poda; falha/overflow de saída mantém shutdown existente.

Esta alternativa exige autorização de **dois caminhos adicionais** de produção:

- `Projeto/src/main/java/pt/uminho/esr/ott/overlay/OverlayNode.java`;
- `Projeto/src/main/java/pt/uminho/esr/ott/app/OttApplication.java`.

A prova futura pode ficar em RouteSwitchTest (sink controlado e integração TCP/
console pertinente), preservando os testes históricos. Não acrescentar qualquer
outro caminho por inferência; se esse teste revelar impedimento, apresentar
antes. Contrato Observer continua funcional; o payload e o sink são extensões
locais propostas, não APIs já implementadas. Esta opção **não está autorizada**,
não integra a allowlist nem foi aplicada; o ADD mantém os três caminhos.

### Estado e decisão requerida

Escolher A, B ou indicar outra política antes de alterar contrato/âmbito/código.
A revisão ADR fica pendente desta decisão e de aprovação humana, sem Implement.
Não é gate externo novo: é a apresentação prévia de impedimento exigida pelo
utilizador e ADR-024. V-017/S01–S18 continuam por executar; regressão JDK21,
manual humano antes de aprovar Test, Waheed e integração continuam obrigatórios.
R17 inicial de IMP-013 sem causa estabelecida; integração com métricas controladas
não demonstra essa causa. Negativos e hashes anteriores preservados.

## Q-C-47-B — aplicação autorizada apenas em Implement

Registo2026-11-21T15:03:15Z: ADD, Design e contratos actualizados antes de código.
Cinco caminhos, Snapshot/construtores/factories/fatal preservados; payload e
sink usam exclusivamente console.log limitado. Sem Test/fecho/commit/push.

## IMP-014 — Implement e negativo de transferência

[Walkthrough](../memory-bank/bolts/024-arvores/implementation-walkthrough.md), registo2026-11-21T15:36:31Z.
Regressão incremental actual1449/0/0/0 JDK21.0.13.1,21 XML:1419 históricos
intactos+30 novos. Q-C-47-B/ADR aprovadas; Implement em cinco caminhos para revisão,
sem avanço a Test, fecho, commits/push ou outro IMP. Snapshot/construtores/factories
preservados; payload/sink e fila limitada verificados até à saída real. Negativo
S13-transfer4vs5 reproduzido/corrigido no âmbito e preservado; R17 histórico sem
causa estabelecida, não explicada pela integração controlada. V-017 formal,
clean verify/JAR de entrega, regressão aprovada, manual humano antes de aprovar
Test, Waheed e integração pendentes; sem gate externo adicional.

S13-transfer: lossCredit ficava vivo depois de transferir a ronda, permitindo
uma quinta ACTIVATE sem ANN novo. Crédito agora consumido só quando existe
ronda ainda válida e prova elegível; perda após prazo conserva incidente fresco.
Negativo/fonte anterior, teste dos dois lados da fronteira e regressão preservados.
Nenhuma decisão de contrato/âmbito por inferência nesta correcção interna.
