package pt.uminho.esr.ott.routing;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.function.LongSupplier;
import pt.uminho.esr.ott.config.*;
import pt.uminho.esr.ott.overlay.*;
import pt.uminho.esr.ott.monitoring.*;
import pt.uminho.esr.ott.protocol.*;
import pt.uminho.esr.ott.streaming.StreamCatalog;
import pt.uminho.esr.ott.streaming.StreamInfo;
import pt.uminho.esr.ott.transport.Connection;

/** Bounded path-vector dissemination on the node's borrowed serial owner. */
public final class RoutingService implements AutoCloseable {
    public interface ControlPort { CompletionStage<Connection.SendResult> send(Neighbor.Session session, ControlMessage message); }
    public interface Observer { void onEvent(Event event); }
    public interface Factory { RoutingService create(NodeConfiguration config, UUID instanceId, NeighborManager.SerialOwner owner, ControlPort port, Observer observer); }
    public interface Ticket { void cancel(); }
    public interface Scheduler {
        Ticket schedule(Runnable task, long delayNanos);
        void requestClose(); boolean awaitTermination(Duration budget); int physicalJobs();
    }
    /** Approved local diagnostic contract; not a wire enum. */
    public enum TraceState { SUCCESS, ERROR, TIMEOUT, CANCELLED, CLOSED, RESOURCE_LIMIT, NOT_RUNNING }
    public static final int TRACE_INITIAL_TTL = 32;
    public static final Duration TRACE_TIMEOUT = Duration.ofMillis(3000);
    /** Polling never invokes caller continuations on the node owner. */
    public interface TraceTicket {
        UUID traceId();
        Optional<TraceOutcome> result();
        void cancel();
    }
    public record TraceOutcome(UUID streamId, UUID traceId, Optional<UUID> serverEpoch,
            TraceState state, Optional<ErrorCode> errorCode, String detail,
            List<String> visited, long elapsedNanos) {
        public TraceOutcome {
            Objects.requireNonNull(streamId); Objects.requireNonNull(traceId);
            Objects.requireNonNull(serverEpoch); Objects.requireNonNull(state);
            Objects.requireNonNull(errorCode); Objects.requireNonNull(detail);
            Objects.requireNonNull(visited);
            if (!tracePath(visited, true) || !traceText(detail, 256) || elapsedNanos < 0)
                throw new IllegalArgumentException("Trace outcome bounds");
            visited = List.copyOf(visited);
        }
    }
    /** Admission is bounded before publishing to the borrowed owner. No user continuations. */
    public TraceTicket requestTrace(UUID streamId) {
        Objects.requireNonNull(streamId);
        if (stopping.get() || view.diagnostics().phase() != Phase.RUNNING) return unavailableTrace(streamId);
        long began = clock.getAsLong();
        var ticket = new LocalTrace(streamId, UUID.randomUUID(), began);
        synchronized (resources) {
            if (stopping.get()) return unavailableTrace(streamId);
            if (traceReservations >= traceLimit || localTraces.size() >= 4) {
                ticket.outcome = traceValue(ticket, null, TraceState.RESOURCE_LIMIT, ErrorCode.RESOURCE_LIMIT,
                        "TRACE_CAPACITY", List.of(), began); return ticket;
            }
            traceReservations++; localTraces.add(ticket);
        }
        if (!owner.offer(() -> {
            try { admitTrace(ticket); }
            catch (RuntimeException failure) { note(Reason.CLOCK_ERROR,true); }
        })) {
            // The real owner rejects by initiating stop; its hook also resolves queued tickets.
            synchronized (resources) {
                if (localTraces.remove(ticket)) traceReservations--;
                if (ticket.outcome == null) ticket.outcome = traceValue(ticket, null, TraceState.CLOSED,
                        null, "OWNER_REJECTED", List.of(), began);
            }
        }
        return ticket;
    }
    public static TraceTicket unavailableTrace(UUID streamId) {
        Objects.requireNonNull(streamId);
        UUID id = UUID.randomUUID();
        var value = new TraceOutcome(streamId,id,Optional.empty(),TraceState.NOT_RUNNING,
                Optional.empty(),"NOT_RUNNING",List.of(),0);
        return new TraceTicket() {
            public UUID traceId() { return id; }
            public Optional<TraceOutcome> result() { return Optional.of(value); }
            public void cancel() { }
        };
    }
    public enum SubscriptionState { SUCCESS, ERROR, TIMEOUT, CANCELLED, CLOSED, RESOURCE_LIMIT, NOT_RUNNING }
    public record SubscriptionOutcome(UUID streamId, UUID consumerToken, UUID operationId,
            SubscriptionState state, Optional<ErrorCode> errorCode, String detail) {
        public SubscriptionOutcome {
            Objects.requireNonNull(streamId);Objects.requireNonNull(consumerToken);Objects.requireNonNull(operationId);
            Objects.requireNonNull(state);Objects.requireNonNull(errorCode);Objects.requireNonNull(detail);
        }
    }
    public interface SubscriptionTicket {
        UUID operationId(); Optional<SubscriptionOutcome> result(); void cancel();
    }
    public SubscriptionTicket requestSubscription(UUID streamId,UUID consumerToken) {
        return activation.request(streamId,consumerToken,false);
    }
    /** Explicit new operation; a duplicate requestSubscription never restarts a round. */
    public SubscriptionTicket retrySubscription(UUID streamId,UUID consumerToken) {
        return activation.request(streamId,consumerToken,true);
    }
    void cancelPendingChild(Neighbor.Session session,UUID streamId,UUID subscriptionId,long revision) {
        requireOwner();activation.cancelChild(session,streamId,subscriptionId,revision);drive();
    }
    record ActivationLoad(int trees,int children,int locals,int histories,int sends,int unbound,
            int responseIntents,int pendingChildren) { }
    ActivationLoad activationLoad(){requireOwner();return activation.load();}

    // Captured operation inputs; no public API or wire change.
    record RenewalRequest(Subscription.Identity identity, UUID requestId,
            Subscription.Lease previousGrant, long beganNanos, long budgetNanos) {
        RenewalRequest {
            Objects.requireNonNull(identity); Objects.requireNonNull(requestId);
            Objects.requireNonNull(previousGrant);
            if(budgetNanos<1 || budgetNanos>previousGrant.durationNanos())
                throw new IllegalArgumentException("Invalid renewal budget");
        }
    }

    /** A retired identity is captured once; a later branch must never retarget this request. */
    record PruneRequest(Subscription.Identity identity, UUID requestId,
            long beganNanos, long budgetNanos) {
        PruneRequest {
            Objects.requireNonNull(identity); Objects.requireNonNull(requestId);
            if(budgetNanos<1) throw new IllegalArgumentException("Invalid prune budget");
        }
    }
    // End IMP-012 types.

    public enum Phase { NEW, RUNNING, STOPPED }
    public enum Reason { NONE, INVALID_INPUT, METADATA_CONFLICT, CAPACITY, CLOSED, OUTPUT_OVERFLOW,
        INVALID_LOCAL_MESSAGE, OWNER_REJECTED, CLOCK_ERROR, SEQUENCE_EXHAUSTED, STOPPED }
    public enum SwitchPhase
    {
        STARTED, SUCCESS, FAILURE
    }

    public record SwitchEvent(UUID streamId, String serverId, UUID serverEpoch, UUID operationId,
            SwitchPhase phase, Neighbor.Session previous, Neighbor.Session replacement,
            List<String> previousPath, List<String> replacementPath, long previousRevision,
            long replacementRevision, long previousCostMicros, long replacementCostMicros,
            String reason, long elapsedNanos)
    {
        public SwitchEvent
        {
            Objects.requireNonNull(streamId);
            RoutingTable.nodeId(serverId);
            Objects.requireNonNull(serverEpoch);
            Objects.requireNonNull(operationId);
            Objects.requireNonNull(phase);
            Objects.requireNonNull(previous);
            Objects.requireNonNull(replacement);
            Objects.requireNonNull(reason);
            if(previousPath == null || replacementPath == null || previousPath.size() > 32
                    || replacementPath.size() > 32 || previousPath.size() < 2 || replacementPath.size() < 2
                    || previousRevision < 0 || replacementRevision < -1 || previousCostMicros < 1
                    || replacementCostMicros < 1 || reason.length() > 256 || elapsedNanos < 0)
                throw new IllegalArgumentException("Invalid switch event");

            previousPath = List.copyOf(previousPath);
            replacementPath = List.copyOf(replacementPath);
        }
    }

    public record Event(Reason reason, boolean fatal, Optional<SwitchEvent> routeSwitch)
    {
        public Event
        {
            Objects.requireNonNull(reason);
            Objects.requireNonNull(routeSwitch);
        }


        public Event(Reason reason, boolean fatal)
        {
            this(reason, fatal, Optional.empty());
        }
    }
    public record Diagnostics(Phase phase, int sessions, int bindings, int references, int cacheEntries,
            int ledgers, int pendingCells, int pendingIntents, int quotas, int sendTickets, int timers,
            long failures, boolean countersSaturated, Reason lastReason) { }
    public record Snapshot(long capturedAtNanos, StreamCatalog.Snapshot catalog,
            Map<UUID,Route> routes, Diagnostics diagnostics, Map<UUID,Route.Confirmation> forwarding,
            Map<UUID,Route.Recovery> recoveries)
    {
        //* === Construtores === *

        public Snapshot
        {
            Objects.requireNonNull(catalog);
            Objects.requireNonNull(diagnostics);
            routes = Map.copyOf(routes);
            forwarding = Map.copyOf(forwarding);
            recoveries = Map.copyOf(recoveries);
        }


        public Snapshot(long capturedAtNanos, StreamCatalog.Snapshot catalog,
                Map<UUID,Route> routes, Diagnostics diagnostics,
                Map<UUID,Route.Confirmation> forwarding)
        {
            this(capturedAtNanos, catalog, routes, diagnostics, forwarding, Map.of());
        }


        public Snapshot(long capturedAtNanos, StreamCatalog.Snapshot catalog,
                Map<UUID,Route> routes, Diagnostics diagnostics)
        {
            this(capturedAtNanos, catalog, routes, diagnostics, Map.of(), Map.of());
        }
    }
    private static final long WINDOW=1_000_000_000L;
    private final NodeConfiguration config;
    private final UUID instance;
    private final NeighborManager.SerialOwner owner;
    private final ControlPort control;
    private final Observer observer;
    private final LongSupplier clock;
    private final Scheduler scheduler;
    private final RoutingTable root;
    private final RoutingTable.Limits limits;
    private final StreamCatalog catalog;
    private final ActivationEngine activation;
    private final int maxCache,maxPending,maxTickets,flood;
    private final long period,history,shutdownNanos;
    private final LinkedHashMap<UUID,Row> rows=new LinkedHashMap<>();
    private final List<UUID> streamIndex=new ArrayList<>();
    private final Map<String,Integer> originCounts=new HashMap<>();
    private final Map<String,UUID> epochs=new HashMap<>();
    private final LinkedHashMap<String,Neighbor.Session> sessions=new LinkedHashMap<>();
    private final List<Neighbor.Session> peerIndex=new ArrayList<>();
    private final Map<String,OptionalLong> costs=new HashMap<>();
    private final Map<Neighbor.Session,MetricStamp> metricStamps = new HashMap<>();

    private record MetricStamp(long count, boolean saturated, long sampledAt)
    {
    }
    private final Map<Key,Ledger> ledgers=new HashMap<>();
    private final Map<Generation,CacheEntry> cache=new HashMap<>();
    private final Map<QuotaKey,ArrayDeque<Long>> quotas=new HashMap<>();
    private final ArrayDeque<QuotaKey> quotaSweep=new ArrayDeque<>();
    // These locks/flags cover physical work only; all routing state above belongs to owner.
    private final Object resources=new Object();
    private final Set<Admission> admissions=new HashSet<>();
    // Physical reservations/command cancellation may be touched off owner, routing contexts may not.
    private final Set<LocalTrace> localTraces = new HashSet<>();
    private final Set<TraceSend> traceSends = new HashSet<>();
    private final Map<UUID,TraceContext> traces = new HashMap<>();
    private final ArrayDeque<TraceContext> traceOrder = new ArrayDeque<>();
    private final int traceLimit;
    private int traceReservations, traceSweep;

    private final AtomicBoolean stopping=new AtomicBoolean(),wakeQueued=new AtomicBoolean();
    private final AtomicReference<Long> firstStop=new AtomicReference<>();
    private final CompletableFuture<Void> cleaned=new CompletableFuture<>();
    private NeighborManager.Registration registration;
    private volatile Snapshot view;
    private Phase phase=Phase.NEW;
    private Ticket alarm;
    private long alarmAt,lastNow,failures;
    private boolean observed,driving,countersSaturated;
    private Reason lastReason=Reason.NONE;
    private int scanRemaining,streamCursor,peerCursor,pending;

    private static final class Row {
        final UUID id;final String origin;
        StreamInfo info;Route route;long version,sequence,nextAt;boolean local,offered;
        Row(UUID id,String origin){this.id=id;this.origin=origin;}
    }
    private record Key(UUID stream,Neighbor.Session session) { }
    private record QuotaKey(UUID stream,String nodeId) { }
    private record Generation(UUID stream,UUID epoch,long sequence) { }
    private static final class CacheEntry {
        final long began;long cost;int hops;
        CacheEntry(long t,Publication p){began=t;cost=p.cost;hops=p.path.size();}
        void improve(Publication p){if(p.cost<cost||p.cost==cost&&p.path.size()<hops){cost=p.cost;hops=p.path.size();}}
    }
    private record Publication(StreamInfo info,long sequence,long cost,List<String> path) {
        Publication { path=List.copyOf(path); }
        Generation generation(){return new Generation(info.streamId(),info.serverEpoch(),sequence);}
        boolean betterThan(Publication p){return cost<p.cost||cost==p.cost&&path.size()<p.path.size();}
    }
    private static final class Ledger {
        final Key key;UUID epoch;long maximum=-1,floor=-1,seenVersion=-1;
        Publication receipt,debt,want;boolean cell,review;
        Ledger(Key key){this.key=key;}
    }
    private final class Admission {
        final Key key;final Publication publication;final boolean withdrawal;
        Connection.SendResult result;Throwable error;boolean ready,callbackDone,continuationDone;
        Admission(Key key,Publication p,boolean w){this.key=key;publication=p;withdrawal=w;}
        void complete(Connection.SendResult value,Throwable failure){
            synchronized(resources){result=value;error=failure;ready=true;}
            try { if(!stopping.get())wake(); }
            finally {
                boolean freed;synchronized(resources){callbackDone=true;freed=release(this);}
                if(freed&&!stopping.get())wake();
            }
        }
    }

    public RoutingService(NodeConfiguration c,UUID id,NeighborManager.SerialOwner o,ControlPort p,Observer v){
        this(c,id,o,p,v,System::nanoTime,null,RoutingTable.Limits.forNode(c.runtime().control().maxConnections()));
    }
    public RoutingService(NodeConfiguration c,UUID id,NeighborManager.SerialOwner o,ControlPort p,Observer v,
            LongSupplier clock,Scheduler scheduler){
        this(c,id,o,p,v,clock,scheduler,RoutingTable.Limits.forNode(c.runtime().control().maxConnections()));
    }
    RoutingService(NodeConfiguration c,UUID id,NeighborManager.SerialOwner o,ControlPort p,Observer v,
            LongSupplier clock,Scheduler scheduler,RoutingTable.Limits limits){
        config=Objects.requireNonNull(c);instance=Objects.requireNonNull(id);owner=Objects.requireNonNull(o);
        control=Objects.requireNonNull(p);observer=Objects.requireNonNull(v);this.clock=Objects.requireNonNull(clock);
        this.limits=Objects.requireNonNull(limits);
        // Reuse full offline endpoint/role validation without opening a socket/starting a manager.
        new NeighborManager(c,id,o,e->{});
        if(id.equals(new UUID(0,0)))throw new IllegalArgumentException("Nonzero instance required");
        validateConfiguration(c,id);
        if(c.streams().size()>limits.streamsPerOrigin())throw new IllegalArgumentException("Source capacity");
        var r=c.runtime().routing();period=r.announceInterval().toNanos();history=r.cacheTtl().toNanos();
        traceLimit=Math.min(o.capacity(),64);
        maxCache=r.cacheCapacity();maxPending=Math.min(maxCache,o.capacity());maxTickets=Math.min(o.capacity(),2*limits.neighbors());
        flood=r.floodMaxPerSecond();shutdownNanos=c.runtime().control().shutdownTimeout().toNanos();
        root=new RoutingTable(c.nodeId(),limits,r.candidateTtl().toMillis(),r.cacheTtl().toMillis(),clock);
        catalog=new StreamCatalog(limits.streamCapacity());
        activation=new ActivationEngine();
        long initialTime=clock.getAsLong(); // fail before allocating a helper/registering cleanup
        this.scheduler=scheduler==null?new Timers():scheduler;
        try { registration=owner.onStop(this::ownerStopped);publish(initialTime); }
        catch(RuntimeException e){
            if(registration!=null)registration.remove();
            this.scheduler.requestClose();throw e;
        }
    }
    /** Validates new source metadata without creating an owner, helper or socket. */
    public static void validateConfiguration(NodeConfiguration c,UUID id){
        Objects.requireNonNull(c);Objects.requireNonNull(id);
        if(id.equals(new UUID(0,0)))throw new IllegalArgumentException("Nonzero instance required");
        var ids=new HashSet<UUID>();
        for(var stream:c.streams()){
            if(c.role()!=NodeRole.SERVER||!stream.serverId().equals(c.nodeId())||!ids.add(stream.streamId())||ids.size()>256)
                throw new IllegalArgumentException("Invalid configured source");
            new StreamInfo(stream.streamId(),stream.serverId(),stream.title(),1,stream.fps(),id);
        }
    }
    public static Snapshot emptySnapshot(){
        return new Snapshot(0,new StreamCatalog.Snapshot(0,Map.of()),Map.of(),new Diagnostics(Phase.NEW,0,0,0,0,0,0,0,0,0,0,0,false,Reason.NONE));
    }
    private void requireOwner(){if(!owner.isOwnerThread())throw new IllegalStateException("Routing requires node owner");}
    private long now(){long t=clock.getAsLong();if(observed&&t-lastNow<0)throw new IllegalStateException("Clock regressed");observed=true;lastNow=t;return t;}
    private static RoutingTable.SessionKey key(Neighbor.Session s){return new RoutingTable.SessionKey(s.nodeId(),s.instanceId(),s.connectionId());}
    private boolean current(Neighbor.Session s){return s.equals(sessions.get(s.nodeId()));}
    private boolean applied(RoutingTable.Outcome o){
        if(o.status()==RoutingTable.Status.REJECTED){note(o.reason()==RoutingTable.Reason.CAPACITY_EXCEEDED?Reason.CAPACITY:Reason.INVALID_INPUT,false);return false;}
        for(UUID id:o.changedStreams())refresh(rows.get(id));
        return o.status()==RoutingTable.Status.APPLIED;
    }
    private void refresh(Row row){if(row==null)return;var route=root.snapshot(row.id).orElseThrow();if(!route.equals(row.route)){row.route=route;row.version=Math.incrementExact(row.version);dirty();}}
    private void dirty(){scanRemaining=Math.multiplyExact(rows.size(),sessions.size());}
    private Row bind(UUID id,String origin){
        var old=rows.get(id);if(old!=null)return old.origin.equals(origin)?old:null;
        if(rows.size()==limits.streamCapacity()||!originCounts.containsKey(origin)&&originCounts.size()==limits.origins()
                ||originCounts.getOrDefault(origin,0)==limits.streamsPerOrigin()){note(Reason.CAPACITY,false);return null;}
        var outcome=root.bindStream(id,origin);if(outcome.status()!=RoutingTable.Status.APPLIED){note(Reason.CAPACITY,false);return null;}
        var row=new Row(id,origin);rows.put(id,row);streamIndex.add(id);originCounts.merge(origin,1,Integer::sum);refresh(row);dirty();return row;
    }
    private boolean epoch(String origin,UUID replacement){
        UUID old=epochs.get(origin);if(replacement.equals(old))return true;
        var outcome=root.confirmEpoch(origin,Optional.ofNullable(old),replacement);
        if(outcome.status()!=RoutingTable.Status.APPLIED){note(outcome.reason()==RoutingTable.Reason.CAPACITY_EXCEEDED?Reason.CAPACITY:Reason.INVALID_INPUT,false);return false;}
        epochs.put(origin,replacement);
        activation.epochChanged(origin,replacement);
        for(var row:rows.values())if(row.origin.equals(origin)){row.info=null;refresh(row);}
        dirty();return true;
    }
    public void start(){
        requireOwner();if(phase!=Phase.NEW||stopping.get())return;phase=Phase.RUNNING;
        try{
            long t=now();
            for(var s:config.streams()){
                var row=bind(s.streamId(),s.serverId());if(row==null)throw new IllegalStateException("Configured source capacity");
                if(!epoch(s.serverId(),instance))throw new IllegalStateException("Configured source epoch");
                row.info=new StreamInfo(s.streamId(),s.serverId(),s.title(),1,s.fps(),instance);row.local=true;row.offered=true;row.nextAt=t+period;
                applied(root.offerLocal(row.id,instance));
            }
            drive();
        }catch(RuntimeException e){note(Reason.INVALID_LOCAL_MESSAGE,true);}
    }
    public void onNeighborEvent(NeighborManager.Event event){
        requireOwner();Objects.requireNonNull(event);if(phase!=Phase.RUNNING||stopping.get())return;
        try{
            activation.kick();
            traceSweep=traceOrder.size();
            if(event instanceof NeighborManager.NeighborUp e){
                var s=e.session();var old=sessions.get(s.nodeId());
                if(!s.equals(old)){
                    if(old==null&&sessions.size()==limits.neighbors()){note(Reason.CAPACITY,false);return;}
                    if(!applied(root.replaceSession(Optional.ofNullable(old).map(RoutingService::key),key(s))))return;
                    if(old!=null)retire(old);sessions.put(s.nodeId(),s);costs.put(s.nodeId(),OptionalLong.empty());peersChanged();
                }
            }else if(event instanceof NeighborManager.NeighborDown e){if(current(e.session()))remove(e.session());}
            else if(event instanceof NeighborManager.Received e){
                var m=e.message();if(!current(e.session()))return;
                if (m.type()==MessageType.ACTIVATE || m.type()==MessageType.ACTIVATE_ACK
                        || m.type()==MessageType.SUBSCRIPTION_RENEW || m.type()==MessageType.DEACTIVATE
                        || m.type()==MessageType.ERROR && m.payload() instanceof ControlMessage.ErrorPayload p && (p.relatedType()==11||p.relatedType()==13||p.relatedType()==14)) {
                    if(m.version()==2 && m.requestId()!=null && e.session().nodeId().equals(m.senderId())
                            && e.session().instanceId().equals(m.senderInstance())) activation.receive(e.session(),m);
                    drive();return;
                }
                if (m.type()==MessageType.ROUTE_TRACE || m.type()==MessageType.TRACE_RESULT || m.type()==MessageType.ERROR) {
                    if (m.version()==2 && m.requestId()!=null && e.session().nodeId().equals(m.senderId())
                            && e.session().instanceId().equals(m.senderInstance())) onTrace(e.session(),m);
                    drive(); return;
                }
                if(m.type()!=MessageType.STREAM_ANNOUNCE&&m.type()!=MessageType.STREAM_WITHDRAW)return;
                if(m.version()!=2||m.requestId()==null||!e.session().nodeId().equals(m.senderId())||!e.session().instanceId().equals(m.senderInstance())){note(Reason.INVALID_INPUT,false);return;}
                if(m.type()==MessageType.STREAM_ANNOUNCE&&m.payload() instanceof ControlMessage.Announcement a)announce(e.session(),a);
                else if(m.type()==MessageType.STREAM_WITHDRAW&&m.payload() instanceof ControlMessage.Withdrawal w){
                    if(w.streamId()==null||w.serverEpoch()==null||w.announceSeq()<0){note(Reason.INVALID_INPUT,false);return;}
                    applied(root.withdraw(w.streamId(),w.serverEpoch(),key(e.session()),w.announceSeq()));
                }else{note(Reason.INVALID_INPUT,false);return;}
            }else return;
            drive();
        }catch(IllegalArgumentException|NullPointerException e){note(Reason.INVALID_INPUT,false);}
        catch(RuntimeException e){note(Reason.CLOCK_ERROR,true);}
    }
    private void announce(Neighbor.Session session,ControlMessage.Announcement a){
        var info=StreamInfo.fromWire(a.stream());var path=a.path();
        if(a.announceSeq()<0||a.costMicros()<0||path.isEmpty()||path.size()>31||!path.getFirst().equals(info.serverId())
                ||!path.getLast().equals(session.nodeId())||path.contains(config.nodeId())||new HashSet<>(path).size()!=path.size()
                ||path.stream().anyMatch(s->s==null||!s.matches("[A-Za-z0-9_-]{1,32}"))||(a.costMicros()==0)!=(path.size()==1)){
            note(Reason.INVALID_INPUT,false);return;
        }
        var cost=costs.get(session.nodeId());if(cost!=null&&cost.isPresent())try{Math.addExact(a.costMicros(),cost.orElseThrow());}catch(ArithmeticException e){note(Reason.INVALID_INPUT,false);return;}
        var existing=rows.get(info.streamId());
        if(existing!=null&&(!existing.origin.equals(info.serverId())||existing.info!=null&&existing.info.serverEpoch().equals(info.serverEpoch())&&!existing.info.sameMetadata(info))){note(Reason.METADATA_CONFLICT,false);return;}
        // Validate capacity before a source-wide epoch transition: rejection must preserve healthy rows.
        if(existing==null&&(rows.size()==limits.streamCapacity()
                ||!originCounts.containsKey(info.serverId())&&originCounts.size()==limits.origins()
                ||originCounts.getOrDefault(info.serverId(),0)==limits.streamsPerOrigin())){
            note(Reason.CAPACITY,false);return;
        }
        // A rejected epoch must not consume a new binding for an already known source.
        if(originCounts.containsKey(info.serverId())&&!epoch(info.serverId(),info.serverEpoch()))return;
        var row=existing==null?bind(info.streamId(),info.serverId()):existing;if(row==null)return;
        if(!epoch(info.serverId(),info.serverEpoch()))return;
        long previousSequence = row.route.candidates().stream()
                .filter(c -> c.upstream().equals(key(session))).mapToLong(RouteCandidate::announceSeq).max().orElse(-1);
        var outcome=root.announce(new RoutingTable.Advertisement(info.streamId(),info.serverId(),info.serverEpoch(),key(session),a.announceSeq(),a.costMicros(),path));
        if(applied(outcome)){
            if(row.info==null)row.info=info;
            activation.observeAnnouncement(session, a, now(), a.announceSeq() > previousSequence);
            // Catalog must be published with the newly established canonical metadata.
            dirty();
        }
    }
    public void onMetrics(NetworkMonitor.Event event){
        requireOwner();Objects.requireNonNull(event);if(phase!=Phase.RUNNING||stopping.get())return;
        try{
            activation.kick();
            Neighbor.Session session;OptionalLong cost;boolean distinct = false;
            if(event instanceof NetworkMonitor.Updated e)
            {
                session = e.metrics().session();
                cost = e.metrics().costMicros();
                if(!current(session))
                    return;
                var m = e.metrics();
                if(m.lastSampleAtNanos().isPresent())
                {
                    var previous = metricStamps.get(session);
                    long sampledAt = m.lastSampleAtNanos().orElseThrow();
                    distinct = previous == null || m.sampleCount() > previous.count()
                            || m.sampleCount() == Long.MAX_VALUE && previous.count() == Long.MAX_VALUE
                                && m.sampleCountSaturated() && sampledAt - previous.sampledAt() > 0;
                    if(distinct)
                        metricStamps.put(session, new MetricStamp(m.sampleCount(), m.sampleCountSaturated(), sampledAt));
                }
            }
            else if(event instanceof NetworkMonitor.Invalidated e){session=e.session();cost=OptionalLong.empty();}
            else return;
            if(!current(session))return;traceSweep=traceOrder.size();costs.put(session.nodeId(),cost);applied(root.setLinkCost(key(session),cost));activation.observeMetric(session, distinct);drive();
        }catch(RuntimeException e){note(Reason.CLOCK_ERROR,true);}
    }
    public void setLocalAvailable(UUID id,boolean available){
        requireOwner();if(stopping.get())return;var row=rows.get(Objects.requireNonNull(id));
        if(row==null||!row.local)throw new IllegalArgumentException("Configured local stream required");
        if(row.offered==available)return;row.offered=available;
        try{
            activation.kick();
            if(available){row.sequence=Math.incrementExact(row.sequence);row.nextAt=now()+period;applied(root.offerLocal(id,instance));}
            else applied(root.removeLocalOffer(id,instance));
            row.version=Math.incrementExact(row.version);dirty();drive();
        }catch(ArithmeticException e){note(Reason.SEQUENCE_EXHAUSTED,true);}
    }
    private void peersChanged(){peerIndex.clear();peerIndex.addAll(sessions.values());peerCursor=0;dirty();}
    private void retire(Neighbor.Session s){
        metricStamps.remove(s);
        activation.sessionDown(s);
        var iterator=ledgers.entrySet().iterator();while(iterator.hasNext()){
            var entry=iterator.next();if(entry.getKey().session.equals(s)){if(entry.getValue().cell)pending--;iterator.remove();}
        }
    }
    private void remove(Neighbor.Session s){
        if(!current(s))return;applied(root.removeSession(key(s)));sessions.remove(s.nodeId());costs.remove(s.nodeId());retire(s);peersChanged();
    }
    private Publication selected(Row row,Neighbor.Session recipient){
        if(row.info==null||row.route==null)return null;
        if(row.offered)return new Publication(row.info,row.sequence,0,List.of(config.nodeId()));
        var candidate=row.route.selectedCandidate();if(candidate.isEmpty())return null;
        var c=candidate.orElseThrow();if(c.path().contains(recipient.nodeId()))return null;
        return new Publication(row.info,c.announceSeq(),c.metric().orElseThrow().costMicros(),c.path());
    }
    private void reconsider(Ledger ledger,Row row){
        var epoch=row.route.serverEpoch().orElse(null);
        if(!Objects.equals(epoch,ledger.epoch)){ledger.epoch=epoch;ledger.maximum=-1;ledger.floor=-1;}
        Publication desired=selected(row,ledger.key.session);
        var old=ledger.receipt;
        if(old!=null){
            boolean invalid=desired==null||!old.info.serverEpoch().equals(desired.info.serverEpoch())
                ||desired.sequence<ledger.maximum
                ||desired.sequence==old.sequence&&!desired.equals(old)&&!desired.betterThan(old);
            if(invalid&&ledger.debt==null)ledger.debt=old;
        }
        if(desired!=null){
            if(desired.info.serverEpoch().equals(ledger.epoch)&&(desired.sequence<=ledger.floor||desired.sequence<ledger.maximum))desired=null;
            else if(ledger.debt!=null&&desired.info.serverEpoch().equals(ledger.debt.info.serverEpoch())&&desired.sequence<=ledger.debt.sequence)desired=null;
            else if(ledger.debt==null&&desired.equals(old))desired=null;
        }
        ledger.want=null;
        if(ledger.debt==null&&desired==null){freeCell(ledger);return;}
        if(!ledger.cell){if(pending==maxPending){note(Reason.CAPACITY,false);return;}ledger.cell=true;pending++;}
        if(desired!=null){
            var generation=desired.generation();var cached=cache.get(generation);
            if(cached==null){if(cache.size()==maxCache){note(Reason.CAPACITY,false);if(ledger.debt==null)freeCell(ledger);return;}cached=new CacheEntry(lastNow,desired);cache.put(generation,cached);}
            else cached.improve(desired);
            ledger.want=desired;
        }
    }
    private void freeCell(Ledger ledger){if(ledger.cell){pending--;ledger.cell=false;}ledger.want=null;}
    private boolean busy(Neighbor.Session session){synchronized(resources){return admissions.stream().anyMatch(t->t.key.session.equals(session)&&!t.continuationDone);}}
    private boolean release(Admission ticket){
        if(ticket.callbackDone&&ticket.continuationDone&&admissions.remove(ticket)){resources.notifyAll();return true;}
        return false;
    }
    private void completions(){
        List<Admission> ready;
        synchronized(resources){ready=admissions.stream().filter(t->t.ready&&!t.continuationDone).toList();}
        for(var ticket:ready){
            try{
                if(stopping.get()||!current(ticket.key.session))continue;
                var ledger=ledgers.get(ticket.key);if(ledger==null)continue;
                if(ticket.error!=null){note(Reason.INVALID_LOCAL_MESSAGE,true);continue;}
                if(ticket.result==Connection.SendResult.ACCEPTED){
                    if(ticket.withdrawal){
                        if(ticket.publication.equals(ledger.debt))ledger.debt=null;
                        if(ticket.publication.equals(ledger.receipt))ledger.receipt=null;
                        if(ticket.publication.info.serverEpoch().equals(ledger.epoch))ledger.floor=Math.max(ledger.floor,ticket.publication.sequence);
                    }else{
                        ledger.receipt=ticket.publication;
                        if(ticket.publication.info.serverEpoch().equals(ledger.epoch))ledger.maximum=Math.max(ledger.maximum,ticket.publication.sequence);
                    }
                    ledger.review=true;dirty();
                }else if(ticket.result==Connection.SendResult.CLOSED||ticket.result==Connection.SendResult.OVERFLOW){
                    note(ticket.result==Connection.SendResult.CLOSED?Reason.CLOSED:Reason.OUTPUT_OVERFLOW,false);remove(ticket.key.session);
                }else note(Reason.INVALID_LOCAL_MESSAGE,true);
            }finally{
                boolean freed;synchronized(resources){ticket.continuationDone=true;freed=release(ticket);}
                if(freed&&!stopping.get())wake();
            }
        }
    }
    private void purgeQuota(ArrayDeque<Long> q,long t){while(!q.isEmpty()&&t-q.getFirst()>=WINDOW)q.removeFirst();}
    private int sweepQuotas(long t){int n=Math.min(16,quotaSweep.size());for(int i=0;i<n;i++){
        var key=quotaSweep.removeFirst();var q=quotas.get(key);purgeQuota(q,t);
        if(q.isEmpty()&&!sessions.containsKey(key.nodeId))quotas.remove(key);else quotaSweep.addLast(key);
    }return n;}
    private boolean quota(Ledger l,long t){
        var key=new QuotaKey(l.key.stream,l.key.session.nodeId());var q=quotas.get(key);
        if(q==null){if(quotas.size()==limits.slotCapacity()){note(Reason.CAPACITY,false);return false;}q=new ArrayDeque<>();quotas.put(key,q);quotaSweep.addLast(key);}
        purgeQuota(q,t);if(q.size()==flood)return false;q.addLast(t);return true;
    }
    private boolean currentAnnouncement(Ledger ledger,Publication publication,long at){
        if(stopping.get()||!current(ledger.key.session))return false;
        var row=rows.get(ledger.key.stream);
        if(row==null||!publication.equals(selected(row,ledger.key.session)))return false;
        if(row.offered)return true;
        var candidate=row.route.selectedCandidate().orElseThrow();
        long age=at-candidate.generationStartedAtNanos();
        return age>=0&&age<candidate.candidateTtlNanos();
    }
    private boolean attempt(Ledger l){
        if(stopping.get()||!current(l.key.session)||!l.cell||busy(l.key.session))return false;
        if(l.debt==null&&l.want!=null){
            // Previous sends in this same turn may have consumed the remaining TTL.
            // Refresh selection/expiry without renewing a generation or manufacturing seq.
            long at=now();applied(root.expire());
            var row=rows.get(l.key.stream);
            if(l.seenVersion!=row.version||l.review){
                l.seenVersion=row.version;l.review=false;reconsider(l,row);
            }
            publish(at);
        }
        Publication p=l.debt!=null?l.debt:l.want;boolean withdrawal=l.debt!=null;
        if(stopping.get()||p==null)return false;
        ControlMessage message=new ControlMessage(withdrawal?MessageType.STREAM_WITHDRAW:MessageType.STREAM_ANNOUNCE,UUID.randomUUID(),config.nodeId(),instance,
            withdrawal?new ControlMessage.Withdrawal(p.info.streamId(),p.info.serverEpoch(),p.sequence):new ControlMessage.Announcement(p.info.toWire(),p.sequence,p.cost,p.path));
        // Check at the port boundary, after message preparation; do not reuse turn time.
        long attemptAt=now();
        if(!withdrawal&&!currentAnnouncement(l,p,attemptAt)){
            applied(root.expire());var row=rows.get(l.key.stream);
            l.seenVersion=row.version;l.review=false;reconsider(l,row);publish(attemptAt);
            return false; // no physical ticket or rate token was consumed by this stale intent
        }
        Admission ticket;
        synchronized(resources){if(admissions.size()==maxTickets)return false;ticket=new Admission(l.key,p,withdrawal);admissions.add(ticket);}
        if(!quota(l,attemptAt)){discardUnsent(ticket);return false;}
        try {
            // Physical/quota reservation can take time too. This is the last clock
            // check before the port call; an already charged attempt is not refunded.
            long dispatchAt=now();
            if(!withdrawal&&!currentAnnouncement(l,p,dispatchAt)){
                discardUnsent(ticket);applied(root.expire());
                var row=rows.get(l.key.stream);l.seenVersion=row.version;l.review=false;
                reconsider(l,row);publish(dispatchAt);return false;
            }
        } catch(RuntimeException e){discardUnsent(ticket);throw e;}
        if(!withdrawal){l.want=null;if(l.debt==null)freeCell(l);}
        try{Objects.requireNonNull(control.send(l.key.session,message)).whenComplete(ticket::complete);}
        catch(RuntimeException e){ticket.complete(null,e);}
        return true;
    }
    private void discardUnsent(Admission ticket){
        // No port call/future/callback exists yet, so this reservation has no
        // outstanding physical work. In-flight admissions still use release().
        synchronized(resources){admissions.remove(ticket);resources.notifyAll();}
    }
    private void scan(int budget){
        int sends=0;
        while(scanRemaining>0&&budget-->0&&!stopping.get()){
            if(streamIndex.isEmpty()||peerIndex.isEmpty()){scanRemaining=0;break;}
            if(streamCursor>=streamIndex.size())streamCursor=0;
            if(peerCursor>=peerIndex.size())peerCursor=0;
            var row=rows.get(streamIndex.get(streamCursor));var peer=peerIndex.get(peerCursor);
            if(++peerCursor==peerIndex.size()){peerCursor=0;streamCursor=(streamCursor+1)%streamIndex.size();}
            scanRemaining--;
            var key=new Key(row.id,peer);var ledger=ledgers.get(key);
            if(ledger==null){if(selected(row,peer)==null)continue;ledger=new Ledger(key);ledgers.put(key,ledger);}
            if(ledger.seenVersion!=row.version||ledger.review||ledger.debt!=null&&!ledger.cell){
                ledger.seenVersion=row.version;ledger.review=false;reconsider(ledger,row);
            }
            if(sends<16&&attempt(ledger))sends++;
        }
    }
    private void drive(){
        requireOwner();if(driving||stopping.get()||phase!=Phase.RUNNING)return;driving=true;
        try{
            long t=now();completions();if(stopping.get())return;
            applied(root.expire());cache.entrySet().removeIf(e->t-e.getValue().began>=history);
            for(var row:rows.values())if(row.offered&&t-row.nextAt>=0){
                try{row.sequence=Math.incrementExact(row.sequence);row.version=Math.incrementExact(row.version);}
                catch(ArithmeticException e){note(Reason.SEQUENCE_EXHAUSTED,true);return;}
                row.nextAt=t+period;dirty();
            }
            // All owner projections precede the resulting send attempts.
            publish(t); traceDrive(); activation.drive(); int swept=sweepQuotas(t);scan(64-swept);
            // A slow/control-port callback may also advance time during this turn.
            long finished=now();applied(root.expire());publish(finished);
            if(scanRemaining>0)wake();
            schedule(finished);
        }catch(RuntimeException e){note(Reason.CLOCK_ERROR,true);}
        finally{driving=false;}
    }
    private void schedule(long t){
        if(stopping.get())return;
        long delay=Long.MAX_VALUE;
        delay=Math.min(delay,activation.nextDelay(t));
        for (var context : traces.values()) delay=Math.min(delay,Math.max(1,TRACE_TIMEOUT.toNanos()-(t-context.began)));
        for(var row:rows.values()){
            if(row.offered)delay=Math.min(delay,Math.max(1,row.nextAt-t));
            if(row.route!=null)for(var c:row.route.candidates())delay=Math.min(delay,Math.max(1,c.candidateTtlNanos()-(t-c.generationStartedAtNanos())));
        }
        for(var c:cache.values())delay=Math.min(delay,Math.max(1,history-(t-c.began)));
        // One finite alarm also expires quota histories, including disconnected node IDs.
        for(var q:quotas.values())if(!q.isEmpty())delay=Math.min(delay,Math.max(1,WINDOW-(t-q.getFirst())));
        if(delay==Long.MAX_VALUE){if(alarm!=null)alarm.cancel();alarm=null;return;}
        long at=t+delay;if(alarm!=null&&alarmAt==at)return;
        if(alarm!=null)alarm.cancel();alarm=null;
        alarmAt=at;alarm=scheduler.schedule(()->{activation.changed.set(true);wake();},delay);
    }
    private void wake(){
        if(stopping.get()||!wakeQueued.compareAndSet(false,true))return;
        if(!owner.offer(()->{wakeQueued.set(false);if(stopping.get())return;
            // A timer wake starts another bounded fair pass, never an unbounded retry loop.
            if (traceSweep==0) traceSweep=traceOrder.size();
            if(scanRemaining==0)dirty();drive();
        })){
            wakeQueued.set(false);stopping.set(true);firstStop.compareAndSet(null,System.nanoTime());scheduler.requestClose();
            // The real owner's rejected offer initiates stop. Its hook owns logical cleanup.
        }
    }
    private void publish(long t){
        var routes=new LinkedHashMap<UUID,Route>();var entries=new LinkedHashMap<UUID,StreamCatalog.Entry>();int refs=0,intents=0;
        for(var row:rows.values()){
            if(row.route!=null)routes.put(row.id,row.route);if(row.info==null)continue;refs++;
            if(row.offered)entries.put(row.id,new StreamCatalog.Entry(row.info,row.route.state(),row.route.selectedMetric(),row.route.knownUpstream(),true,OptionalLong.empty()));
            else{
                long remaining=0;for(var c:row.route.candidates())remaining=Math.max(remaining,c.candidateTtlNanos()-(t-c.generationStartedAtNanos()));
                if(remaining>0)entries.put(row.id,new StreamCatalog.Entry(row.info,row.route.state(),row.route.selectedMetric(),row.route.knownUpstream(),false,OptionalLong.of(remaining)));
            }
        }
        for(var l:ledgers.values())if(l.cell){if(l.debt!=null)intents++;if(l.want!=null)intents++;}
        var projection=new StreamCatalog.Snapshot(t,entries);catalog.replace(projection);
        int physical;synchronized(resources){physical=admissions.size();}
        view=new Snapshot(t,projection,routes,new Diagnostics(phase,sessions.size(),rows.size(),refs,cache.size(),ledgers.size(),pending,intents,quotas.size(),physical,scheduler.physicalJobs(),failures,countersSaturated,lastReason),activation.forwarding(t),activation.recoveries(t));
    }
    private static boolean traceText(String text,int maximum) {
        if (text==null || text.length()>maximum) return false;
        int bytes=0;
        for (int i=0;i<text.length();i++) {
            char c=text.charAt(i); if(c==0)return false;
            if (Character.isHighSurrogate(c)) {
                if(++i==text.length() || !Character.isLowSurrogate(text.charAt(i)))return false;
                bytes+=4;
            } else if(Character.isLowSurrogate(c))return false;
            else bytes+=c<128?1:c<2048?2:3;
            if(bytes>maximum)return false;
        } return true;
    }
    private static boolean tracePath(List<String> path,boolean empty) { return tracePath(path,empty,true); }
    private static boolean tracePath(List<String> path,boolean empty,boolean unique) {
        if(path==null || path.size()>32 || !empty && path.isEmpty())return false;
        for(int i=0;i<path.size();i++) {
            String id=path.get(i);
            if(id==null || id.length()<1 || id.length()>32)return false;
            for(int j=0;j<id.length();j++) {
                char c=id.charAt(j); if(!(c>='A'&&c<='Z'||c>='a'&&c<='z'||c>='0'&&c<='9'||c=='_'||c=='-'))return false;
            }
            if(unique)for(int j=0;j<i;j++)if(id.equals(path.get(j)))return false;
        } return true;
    }
    private final class LocalTrace implements TraceTicket {
        final UUID stream,id; final long began;
        final AtomicBoolean cancelled=new AtomicBoolean(); volatile TraceOutcome outcome;
        LocalTrace(UUID stream,UUID id,long began){this.stream=stream;this.id=id;this.began=began;}
        public UUID traceId(){return id;}
        public Optional<TraceOutcome> result(){return Optional.ofNullable(outcome);}
        public void cancel(){if(outcome==null && cancelled.compareAndSet(false,true))wake();}
    }
    private static final class TraceContext {
        final UUID id,stream; final long began; final Neighbor.Session incoming;
        final LocalTrace local; final List<String> prefix;
        UUID epoch; String origin; Neighbor.Session upstream;
        boolean terminal; ControlMessage response;
        TraceContext(UUID id,UUID stream,long began,Neighbor.Session incoming,LocalTrace local,List<String> prefix) {
            this.id=id;this.stream=stream;this.began=began;this.incoming=incoming;this.local=local;this.prefix=prefix;
        }
    }
    private TraceOutcome traceValue(LocalTrace ticket,UUID epoch,TraceState state,ErrorCode code,
            String detail,List<String> path,long at) {
        return new TraceOutcome(ticket.stream,ticket.id,Optional.ofNullable(epoch),state,
                Optional.ofNullable(code),detail,path,Math.max(0,at-ticket.began));
    }
    private void admitTrace(LocalTrace ticket) {
        requireOwner();
        if(stopping.get())return; // onStop/cleanup owns every reserved local ticket
        var c=new TraceContext(ticket.id,ticket.stream,ticket.began,null,ticket,List.of(config.nodeId()));
        traces.put(c.id,c);traceOrder.add(c);traceSweep=traceOrder.size();
        long at=now();
        if(ticket.cancelled.get())finishTrace(c,TraceState.CANCELLED,null,"CANCELLED",c.prefix,at);
        else if(at-c.began>=TRACE_TIMEOUT.toNanos())finishTrace(c,TraceState.TIMEOUT,ErrorCode.TIMEOUT,"TIMEOUT",c.prefix,at);
        else forwardTrace(c,TRACE_INITIAL_TTL-1);
        drive();
    }
    private void finishTrace(TraceContext c,TraceState state,ErrorCode code,String detail,List<String> path,long at) {
        if(c.terminal)return;c.terminal=true;
        if(c.local!=null)c.local.outcome=traceValue(c.local,c.epoch,state,code,detail,path,at);
        else if(c.incoming!=null && current(c.incoming) && at-c.began<TRACE_TIMEOUT.toNanos()) {
            c.response=new ControlMessage(state==TraceState.SUCCESS?MessageType.TRACE_RESULT:MessageType.ERROR,
                    c.id,config.nodeId(),instance,state==TraceState.SUCCESS?
                    new ControlMessage.TraceResult(c.stream,c.id,path):
                    new ControlMessage.ErrorPayload(code==null?ErrorCode.NO_ROUTE:code,15,detail));
        }
        traceSweep=traceOrder.size();
    }
    private void forwardTrace(TraceContext c,int remaining) {
        long at=now();applied(root.expire());
        if(at-c.began>=TRACE_TIMEOUT.toNanos()){finishTrace(c,TraceState.TIMEOUT,ErrorCode.TIMEOUT,"TIMEOUT",c.prefix,at);return;}
        var row=rows.get(c.stream);
        if(row==null){finishTrace(c,TraceState.ERROR,ErrorCode.UNKNOWN_STREAM,"UNKNOWN_STREAM",c.prefix,at);return;}
        refresh(row);var route=row.route;
        if(c.epoch!=null && !route.serverEpoch().equals(Optional.of(c.epoch))) {
            finishTrace(c,TraceState.ERROR,ErrorCode.PATH_CHANGED,"PATH_CHANGED",c.prefix,at);return;
        }
        c.epoch=route.serverEpoch().orElse(null);c.origin=route.serverId();
        if(route.localSource()){finishTrace(c,TraceState.SUCCESS,null,"",c.prefix,at);return;}
        if(route.selectedCandidate().isEmpty()){finishTrace(c,TraceState.ERROR,ErrorCode.NO_ROUTE,"NO_ROUTE",c.prefix,at);return;}
        if(remaining==0){finishTrace(c,TraceState.ERROR,ErrorCode.TIMEOUT,"TTL_EXHAUSTED",c.prefix,at);return;}
        var selected=route.selectedCandidate().orElseThrow();
        var session=sessions.get(selected.upstream().nodeId());
        if(session==null || !key(session).equals(selected.upstream())){finishTrace(c,TraceState.ERROR,ErrorCode.NO_ROUTE,"NO_ROUTE",c.prefix,at);return;}
        if(c.prefix.contains(session.nodeId())){finishTrace(c,TraceState.ERROR,ErrorCode.LOOP_DETECTED,"LOOP_DETECTED",c.prefix,at);return;}
        c.upstream=session;
        var request=new ControlMessage(MessageType.ROUTE_TRACE,c.id,config.nodeId(),instance,
                new ControlMessage.Trace(c.stream,c.epoch,c.id,remaining,c.prefix));
        if(!sendTrace(c,session,request,true)) {
            long failedAt=now();
            if(failedAt-c.began>=TRACE_TIMEOUT.toNanos())finishTrace(c,TraceState.TIMEOUT,ErrorCode.TIMEOUT,"TIMEOUT",c.prefix,failedAt);
            else finishTrace(c,TraceState.RESOURCE_LIMIT,ErrorCode.RESOURCE_LIMIT,"TRACE_SEND_CAPACITY",c.prefix,failedAt);
        }
    }
    private void onTrace(Neighbor.Session session,ControlMessage message) {
        requireOwner();long at=now();
        if(message.type()==MessageType.ROUTE_TRACE && message.payload() instanceof ControlMessage.Trace p) {
            // Bound before copying, allocating a context, or responding from unsafe content.
            if(p.streamId()==null || p.serverEpoch()==null || p.traceId()==null || !p.traceId().equals(message.requestId())
                    || p.ttl()<0 || p.ttl()>255 || !tracePath(p.visited(),false,false)
                    || !p.visited().getLast().equals(session.nodeId()))return;
            var duplicate=traces.get(p.traceId());
            if(duplicate!=null)return; // includes protected terminal contexts; never refresh deadline
            if(p.ttl()==0){traceError(session,p.traceId(),ErrorCode.TIMEOUT,"TTL_EXHAUSTED");return;}
            if(!tracePath(p.visited(),false) || p.visited().contains(config.nodeId())){traceError(session,p.traceId(),ErrorCode.LOOP_DETECTED,"LOOP_DETECTED");return;}
            if(p.visited().size()==32){traceError(session,p.traceId(),ErrorCode.RESOURCE_LIMIT,"TRACE_PATH_LIMIT");return;}
            synchronized(resources) {
                long peer=traces.values().stream().filter(c->session.equals(c.incoming)).count();
                if(traceReservations>=traceLimit || peer>=4){traceError(session,p.traceId(),ErrorCode.RESOURCE_LIMIT,"TRACE_CAPACITY");return;}
                traceReservations++;
            }
            var prefix=new ArrayList<String>(p.visited().size()+1);prefix.addAll(p.visited());prefix.add(config.nodeId());
            var c=new TraceContext(p.traceId(),p.streamId(),at,session,null,List.copyOf(prefix));c.epoch=p.serverEpoch();
            traces.put(c.id,c);traceOrder.add(c);traceSweep=traceOrder.size();forwardTrace(c,p.ttl()-1);
        } else {
            var c=traces.get(message.requestId());
            if(c==null || c.terminal || c.upstream==null || !c.upstream.equals(session))return;
            if(at-c.began>=TRACE_TIMEOUT.toNanos()){finishTrace(c,TraceState.TIMEOUT,ErrorCode.TIMEOUT,"TIMEOUT",c.prefix,at);return;}
            if(message.payload() instanceof ControlMessage.TraceResult p && message.type()==MessageType.TRACE_RESULT) {
                if(!c.id.equals(p.traceId()) || !c.stream.equals(p.streamId()) || !tracePath(p.visited(),false)
                        || p.visited().size()<=c.prefix.size() || !p.visited().subList(0,c.prefix.size()).equals(c.prefix)
                        || !p.visited().get(c.prefix.size()).equals(c.upstream.nodeId())
                        || !p.visited().getLast().equals(c.origin))return;
                var row=rows.get(c.stream);
                if(row==null || !row.route.serverEpoch().equals(Optional.ofNullable(c.epoch)))
                    finishTrace(c,TraceState.ERROR,ErrorCode.PATH_CHANGED,"PATH_CHANGED",c.prefix,at);
                else finishTrace(c,TraceState.SUCCESS,null,"",p.visited(),at);
            } else if(message.type()==MessageType.ERROR && message.payload() instanceof ControlMessage.ErrorPayload p
                    && p.relatedType()==15 && p.code()!=null && traceText(p.detail(),256))
                finishTrace(c,p.code()==ErrorCode.TIMEOUT?TraceState.TIMEOUT:TraceState.ERROR,p.code(),p.detail(),c.prefix,at);
        }
    }
    private final class TraceSend {
        final TraceContext context; final Neighbor.Session session; final boolean request;
        Connection.SendResult result;Throwable error;boolean ready,callbackDone,continuationDone;
        TraceSend(TraceContext c,Neighbor.Session s,boolean request){context=c;session=s;this.request=request;}
        void complete(Connection.SendResult value,Throwable error) {
            synchronized(resources){this.result=value;this.error=error;ready=true;}
            try{if(!stopping.get())wake();}
            finally{boolean freed;synchronized(resources){callbackDone=true;freed=releaseTraceSend(this);}if(freed&&!stopping.get())wake();}
        }
    }
    private boolean releaseTraceSend(TraceSend send) {
        if(send.callbackDone && send.continuationDone && traceSends.remove(send)){resources.notifyAll();return true;}return false;
    }
    private boolean sendTrace(TraceContext c,Neighbor.Session session,ControlMessage message,boolean request) {
        requireOwner();
        if(stopping.get() || !current(session) || c!=null && now()-c.began>=TRACE_TIMEOUT.toNanos())return false;
        final TraceSend send;
        synchronized(resources) {
            if(traceSends.size()>=traceLimit || c!=null && traceSends.stream().filter(t->t.context==c).count()>=2)return false;
            send=new TraceSend(c,session,request);traceSends.add(send);
        }
        boolean submitted=false;
        try {
            // Reservation/validation can consume time; failures before the port own no callback.
            long at=now();
            boolean valid=!stopping.get() && current(session) && (c==null || at-c.began<TRACE_TIMEOUT.toNanos());
            if(valid && request) {
                applied(root.expire());var row=rows.get(c.stream);
                valid=row!=null && row.route.serverEpoch().equals(Optional.ofNullable(c.epoch))
                        && row.route.knownUpstream().equals(Optional.of(key(session)));
                if(!valid)finishTrace(c,TraceState.ERROR,ErrorCode.PATH_CHANGED,"PATH_CHANGED",c.prefix,at);
            }
            if(!valid)return false;
            submitted=true;
            try{Objects.requireNonNull(control.send(session,message)).whenComplete(send::complete);}
            catch(RuntimeException failure){send.complete(null,failure);}
            return true;
        } finally {
            if(!submitted)synchronized(resources){traceSends.remove(send);resources.notifyAll();}
        }
    }
    private void traceError(Neighbor.Session s,UUID id,ErrorCode error,String detail) {
        sendTrace(null,s,new ControlMessage(MessageType.ERROR,id,config.nodeId(),instance,
                new ControlMessage.ErrorPayload(error,15,detail)),false);
    }
    private void traceDrive() {
        requireOwner();
        List<TraceSend> completed;
        synchronized(resources){completed=traceSends.stream().filter(t->t.ready&&!t.continuationDone).limit(16).toList();}
        for(var send:completed) {
            try {
                var c=send.context;
                if(c!=null && !c.terminal && send.request && traces.get(c.id)==c
                        && (send.error!=null || send.result!=Connection.SendResult.ACCEPTED))
                {
                    long at=now();
                    if(at-c.began>=TRACE_TIMEOUT.toNanos())finishTrace(c,TraceState.TIMEOUT,ErrorCode.TIMEOUT,"TIMEOUT",c.prefix,at);
                    else finishTrace(c,TraceState.ERROR,ErrorCode.NO_ROUTE,"SEND_"+(send.result==null?"FAILED":send.result),c.prefix,at);
                }
            }finally{synchronized(resources){send.continuationDone=true;releaseTraceSend(send);}}
        }
        synchronized(resources){if(traceSends.stream().anyMatch(t->t.ready&&!t.continuationDone))wake();}
        int count=Math.min(16-completed.size(),traceSweep);
        while(count-->0 && !traceOrder.isEmpty()) {
            var c=traceOrder.removeFirst();traceSweep--;
            long at=now();
            if(!c.terminal) {
                if(c.local!=null && c.local.cancelled.get())finishTrace(c,TraceState.CANCELLED,null,"CANCELLED",c.prefix,at);
                else if(at-c.began>=TRACE_TIMEOUT.toNanos())finishTrace(c,TraceState.TIMEOUT,ErrorCode.TIMEOUT,"TIMEOUT",c.prefix,at);
                else if(c.upstream!=null && !current(c.upstream))finishTrace(c,TraceState.ERROR,ErrorCode.NO_ROUTE,"SESSION_CLOSED",c.prefix,at);
                else if(c.incoming!=null && !current(c.incoming))finishTrace(c,TraceState.CLOSED,null,"SESSION_CLOSED",c.prefix,at);
                else if(c.epoch!=null && rows.containsKey(c.stream) && !rows.get(c.stream).route.serverEpoch().equals(Optional.of(c.epoch)))
                    finishTrace(c,TraceState.ERROR,ErrorCode.PATH_CHANGED,"PATH_CHANGED",c.prefix,at);
            }
            if(c.response!=null) {
                if(!current(c.incoming) || at-c.began>=TRACE_TIMEOUT.toNanos())c.response=null;
                else if(sendTrace(c,c.incoming,c.response,false))c.response=null;
            }
            if(at-c.began>=TRACE_TIMEOUT.toNanos()) {
                traces.remove(c.id);
                synchronized(resources){traceReservations--;if(c.local!=null)localTraces.remove(c.local);}
            }else traceOrder.addLast(c);
        }
        if(traceSweep>0)wake();
    }
    record TraceLoad(int contexts,int reservations,int locals,int sends,int responseIntents,int timers) { }
    TraceLoad traceLoad() {
        requireOwner();
        synchronized(resources) { return new TraceLoad(traces.size(),traceReservations,localTraces.size(),traceSends.size(),
                (int)traces.values().stream().filter(c->c.response!=null).count(),scheduler.physicalJobs()); }
    }
    private void closeTraces() {
        long at=clock.getAsLong();
        for(var c:traces.values())if(!c.terminal)finishTrace(c,TraceState.CLOSED,null,"CLOSED",c.prefix,at);
        traces.clear();traceOrder.clear();traceSweep=0;
        synchronized(resources) {
            for(var ticket:localTraces)if(ticket.outcome==null)ticket.outcome=traceValue(ticket,null,TraceState.CLOSED,null,"CLOSED",List.of(),at);
            localTraces.clear();traceReservations=0;
            for(var send:List.copyOf(traceSends)){send.continuationDone=true;releaseTraceSend(send);}
        }
    }
    private void note(Reason reason,boolean fatal){
        lastReason=reason;if(failures==Long.MAX_VALUE)countersSaturated=true;else failures++;
        if(fatal)requestClose();
        try{observer.onEvent(new Event(reason,fatal));}catch(RuntimeException e){requestClose();}
    }
    public Snapshot snapshot(){return view;}
    private void ownerStopped(){firstStop.compareAndSet(null,System.nanoTime());stopping.set(true);scheduler.requestClose();lastReason=Reason.OWNER_REJECTED;cleanup();}
    public CompletionStage<Void> requestClose(){
        firstStop.compareAndSet(null,System.nanoTime());if(stopping.compareAndSet(false,true)){
            scheduler.requestClose();if(owner.isOwnerThread())cleanup();else owner.offer(this::cleanup);
        }return cleaned.minimalCompletionStage();
    }
    private void cleanup(){
        requireOwner();if(cleaned.isDone())return;stopping.set(true);scheduler.requestClose();if(alarm!=null)alarm.cancel();alarm=null;
        closeTraces();
        activation.close();
        rows.clear();streamIndex.clear();originCounts.clear();epochs.clear();sessions.clear();peerIndex.clear();costs.clear();metricStamps.clear();ledgers.clear();cache.clear();quotas.clear();quotaSweep.clear();pending=0;scanRemaining=0;phase=Phase.STOPPED;
        synchronized(resources){for(var a:List.copyOf(admissions)){a.continuationDone=true;release(a);}}
        publish(clock.getAsLong());cleaned.complete(null);
        if(registration!=null){registration.remove();registration=null;}
    }
    private static long nanos(Duration d){Objects.requireNonNull(d);if(d.isNegative())throw new IllegalArgumentException("Negative budget");try{return d.toNanos();}catch(ArithmeticException e){throw new IllegalArgumentException("Budget overflow",e);}}
    private static long left(long budget,long began){return Math.max(0,budget-(System.nanoTime()-began));}
    public boolean awaitTermination(Duration timeout){
        long budget=nanos(timeout),began=System.nanoTime();if(owner.isOwnerThread()||!stopping.get())return false;
        budget=Math.min(budget,left(shutdownNanos,firstStop.get()));
        try{cleaned.get(left(budget,began),TimeUnit.NANOSECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();return false;}catch(ExecutionException|TimeoutException e){return false;}
        if(!scheduler.awaitTermination(Duration.ofNanos(left(budget,began))))return false;
        synchronized(resources){while(!admissions.isEmpty() || !traceSends.isEmpty() || !activation.sends.isEmpty()){
            long rest=left(budget,began);if(rest==0)return false;
            try{TimeUnit.NANOSECONDS.timedWait(resources,rest);}catch(InterruptedException e){Thread.currentThread().interrupt();return false;}
        }}return true;
    }
    public void close(){requestClose();if(!owner.isOwnerThread()&&!awaitTermination(Duration.ofNanos(left(shutdownNanos,firstStop.get()))))throw new IllegalStateException("Routing physical shutdown deadline");}

    /** Activation owns only bounded logical state; the existing owner, alarm and port are borrowed. */
    private final class ActivationEngine {
        final int treeLimit=Math.min(owner.capacity(),256), childLimit=Math.min(owner.capacity(),256),
                localLimit=Math.min(owner.capacity(),64), historyLimit=Math.min(owner.capacity(),1024),
                sendLimit=Math.min(owner.capacity(),64), errorLimit=Math.min(owner.capacity(),16);
        final long timeout=config.runtime().routing().activateTimeout().toNanos();
        final long leaseMs=config.runtime().subscription().lease().toMillis();
        final int attempts=config.runtime().routing().activateAttempts();
        final Map<UUID,Tree> trees=new LinkedHashMap<>();
        final ArrayDeque<Tree> treeOrder=new ArrayDeque<>();
        final ArrayDeque<Child> childOrder=new ArrayDeque<>();
        final Map<LineKey,Line> lines=new HashMap<>();
        final Map<LocalKey,Local> localTickets=new HashMap<>(); // guarded by resources, including admission
        final ArrayDeque<Local> localOrder=new ArrayDeque<>();
        final Set<ActSend> sends=new HashSet<>(); // guarded by resources until callback AND continuation end
        final Map<Neighbor.Session,ResponseQuota> responseQuotas=new HashMap<>();
        final AtomicBoolean changed=new AtomicBoolean();
        int treeSweep,childSweep,localSweep;
        record LocalKey(UUID stream,UUID token) { }
        record LineKey(boolean outgoing,UUID stream,UUID epoch,Neighbor.Session session) { }
        final class Local implements SubscriptionTicket {
            final LocalKey key;final UUID operation=UUID.randomUUID();final long began;
            final AtomicBoolean cancelled=new AtomicBoolean();volatile SubscriptionOutcome outcome;
            Local(LocalKey key,long began){this.key=key;this.began=began;}
            public UUID operationId(){return operation;}
            public Optional<SubscriptionOutcome> result(){return Optional.ofNullable(outcome);}
            public void cancel(){if(cancelled.compareAndSet(false,true)){changed.set(true);wake();}}
        }
        final class Tree
        {
            //* === Atributos e Variáveis === *
            final UUID id;
            UUID epoch;
            final String origin;
            final Map<UUID,Local> locals = new LinkedHashMap<>();
            final Map<Neighbor.Session,Child> children = new LinkedHashMap<>();
            final Set<UUID> confirmedLocals = new HashSet<>();

            Confirmed confirmed;
            Round round;
            Prune prune;
            Line upstream;
            long submittedRevision = -1;
            long renewBegan, renewPeriod, version;
            ErrorCode failure;
            String detail = "";

            Proof view, used, blocked, credit, renewalBlocked;
            long failedAt, renewalFailedAt, lastRoundStart, generation;
            boolean roundStarted, lossCredit, sourceAvailable, permanent;
            int issued;
            final Quality quality = new Quality();



            //* === Construtores === *

            Tree(Row row)
            {
                id = row.id;
                epoch = row.route.serverEpoch().orElseThrow();
                origin = row.origin;
            }
        }


        record Confirmed(boolean source,UUID epoch,Neighbor.Session parent,List<String> path,Subscription.Lease lease) {
            Confirmed { path=List.copyOf(path); }
        }
        final class Line
        {
            //* === Atributos e Variáveis === *
            final LineKey key;
            final UUID id;
            long revision = -1;
            UUID request;
            long observedSequence = -1, blockedSequence = -1;
            ControlMessage.Activation fingerprint;
            boolean renew;
            ErrorCode terminal;
            String detail = "";
            Child child;



            //* === Construtores === *

            Line(LineKey key, UUID id)
            {
                this.key = key;
                this.id = id;
            }
        }


        final class Child
        {
            //* === Atributos e Variáveis === *
            final Tree tree;
            final Line line;
            final UUID request;
            final ControlMessage.Activation payload;
            final long began;
            long budget = timeout;
            boolean renew, ackWanted, errorWanted, detached, replay;
            boolean pending = true;
            ErrorCode error;
            String detail = "";
            Subscription active;
            Subscription.Lease suspended;



            //* === Construtores === *

            Child(Tree tree, Line line, UUID request, ControlMessage.Activation payload, long began)
            {
                this.tree = tree;
                this.line = line;
                this.request = request;
                this.payload = payload;
                this.began = began;
            }
        }


        final class Round
        {
            //* === Atributos e Variáveis === *
            final long began;
            long budget = timeout;
            boolean renew;
            int issued;
            Attempt attempt;
            Proof rejected;
            boolean capacityBlocked;
            QualitySwitch switching;



            //* === Construtores === *

            Round(long began)
            {
                this.began = began;
            }
        }


        final class Attempt {
            final Tree tree;final Round round;final Line line;final UUID request=UUID.randomUUID();
            final List<String> path;final long began;final long revision;final RenewalRequest renewal;
            boolean submitted,accepted;ControlMessage.ActivationAck early;
            Attempt(Tree tree,Round round,Line line,List<String> path,long began,long revision){
                this.tree=tree;this.round=round;this.line=line;this.path=List.copyOf(path);this.began=began;this.revision=revision;
                renewal=round.renew?new RenewalRequest(new Subscription.Identity(line.key.session,tree.id,tree.epoch,
                        line.id,revision,tree.version),request,tree.confirmed.lease,began,round.budget):null;
            }
        }
        final class ResponseQuota { long began;int used;ResponseQuota(long began){this.began=began;} }
        final class Prune {
            final PruneRequest request;final Line line;final boolean retired;
            Prune(PruneRequest request,Line line){this(request,line,false);}
            Prune(PruneRequest request,Line line,boolean retired){this.request=request;this.line=line;this.retired=retired;}
        }
        enum SendKind { REQUEST, PRUNE, ACK, ERROR, UNBOUND }
        final class ActSend {
            final Object context;final Neighbor.Session session;final SendKind kind;
            final Attempt attempt;final Child child;Subscription grant;
            Connection.SendResult result;Throwable error;boolean ready,callbackDone,continuationDone;
            ActSend(Object context,Neighbor.Session session,SendKind kind,Attempt attempt,Child child,Subscription grant){
                this.context=context;this.session=session;this.kind=kind;this.attempt=attempt;this.child=child;this.grant=grant;
            }
            void complete(Connection.SendResult value,Throwable error){
                synchronized(resources){result=value;this.error=error;ready=true;}
                try{if(!stopping.get()){changed.set(true);wake();}}
                finally{boolean freed;synchronized(resources){callbackDone=true;freed=release(this);}
                    if(freed&&!stopping.get()){changed.set(true);wake();}}
            }
        }


        //* === Troca por Qualidade === *

        final class Quality
        {
            //* === Atributos e Variáveis === *
            Proof target, blocked, anchor;
            int observations;
            long confirmedAt, failedAt;
            boolean anchored, observed, initial, failed, rearm, permanent;
        }


        final class QualitySwitch
        {
            //* === Atributos e Variáveis === *
            final UUID operation = UUID.randomUUID();
            final Confirmed previous;
            final Line line;
            final long revision, version, previousCost, replacementCost;
            final Proof target;
            long targetRevision = -1;
            boolean started, terminal, promoted;



            //* === Construtores === *

            QualitySwitch(Tree tree, Proof target, long previousCost, long replacementCost)
            {
                previous = tree.confirmed;
                line = tree.upstream;
                revision = tree.submittedRevision;
                version = tree.version;
                this.target = target;
                this.previousCost = previousCost;
                this.replacementCost = replacementCost;
            }
        }


        void observeMetric(Neighbor.Session session, boolean distinct)
        {
            if(!distinct)
                return;
            for(var tree : trees.values())
            {
                observeQuality(tree, session);
            }
        }


        void observeQuality(Tree tree, Neighbor.Session session)
        {
            if(tree.confirmed == null || tree.confirmed.source)
                return;
            var proof = eligibleProof(tree, now());
            if(session.equals(tree.confirmed.parent) || proof != null && session.equals(proof.session))
                tree.quality.observed = true;
        }


        OptionalLong confirmedCost(Tree tree, long at)
        {
            if(!healthy(tree, at) || tree.confirmed.source)
                return OptionalLong.empty();
            var confirmed = tree.confirmed;
            return row(tree.id).route.candidates().stream()
                    .filter(candidate -> candidate.serverEpoch().equals(confirmed.epoch)
                            && candidate.upstream().equals(key(confirmed.parent))
                            && candidate.path().equals(confirmed.path) && candidate.metric().isPresent()
                            && age(at, candidate.generationStartedAtNanos()) < candidate.candidateTtlNanos())
                    .mapToLong(candidate -> candidate.metric().orElseThrow().costMicros()).findFirst();
        }


        boolean qualityValid(Tree tree, long at)
        {
            var round = tree.round;
            if(round == null || round.switching == null || !healthy(tree, at) || !demand(tree, at))
                return false;
            var proof = eligibleProof(tree, at);
            var cost = confirmedCost(tree, at);
            var q = tree.quality;
            return proof != null && proof.sameBranch(round.switching.target) && proof.sameBranch(q.target)
                    && cost.isPresent() && q.observations >= config.runtime().routing().switchObservations()
                    && age(at, q.confirmedAt) >= config.runtime().routing().switchMinDwell().toNanos()
                    && RouteMetric.improves(cost.orElseThrow(), row(tree.id).route.selectedMetric().orElseThrow().costMicros(),
                            config.runtime().routing().switchImprovementPercent());
        }


        void stepQuality(Tree tree, long at)
        {
            var q = tree.quality;
            boolean observed = q.observed;
            q.observed = false;
            if(!healthy(tree, at) || tree.confirmed.source || !demand(tree, at))
                return;
            var proof = eligibleProof(tree, at);
            var cost = confirmedCost(tree, at);
            if(proof == null || cost.isEmpty() || proof.session.equals(tree.confirmed.parent)
                    && proof.path.equals(tree.confirmed.path))
            {
                q.observations = 0;
                q.target = null;
                return;
            }
            if(!proof.sameBranch(q.target))
            {
                q.target = proof;
                q.observations = 0;
            }
            if(q.failed)
            {
                if(q.permanent && q.blocked != null && proof.session.equals(q.blocked.session)
                        && proof.epoch.equals(q.blocked.epoch))
                    return;
                if(observed && !proof.sameBranch(q.blocked))
                {
                    q.rearm = true;
                    q.permanent = false;
                }
                if(!q.rearm)
                    return;
            }
            boolean first = !q.initial;
            q.initial = true;
            long replacement = row(tree.id).route.selectedMetric().orElseThrow().costMicros();
            if(!RouteMetric.improves(cost.orElseThrow(), replacement, config.runtime().routing().switchImprovementPercent()))
            {
                q.observations = 0;
                return;
            }
            if((observed || first) && q.observations < config.runtime().routing().switchObservations())
                q.observations++;
            if(tree.round != null || tree.prune != null || !q.anchored
                    || q.observations < config.runtime().routing().switchObservations()
                    || age(at, q.confirmedAt) < config.runtime().routing().switchMinDwell().toNanos()
                    || tree.roundStarted && age(at, tree.lastRoundStart) < timeout
                    || q.failed && age(at, q.failedAt) < timeout)
                return;

            tree.lastRoundStart = at;
            tree.roundStarted = true;
            tree.generation = Math.incrementExact(tree.generation);
            tree.used = proof;
            tree.round = new Round(at);
            tree.round.switching = new QualitySwitch(tree, proof, cost.orElseThrow(), replacement);
            switchEvent(tree, tree.round, SwitchPhase.STARTED, "SUSTAINED_IMPROVEMENT", at);
        }


        long qualityDelay(Tree tree, long at)
        {
            var q = tree.quality;
            if(tree.round != null || tree.prune != null || q.target == null || !q.anchored
                    || q.failed && !q.rearm || q.permanent
                    || q.observations < config.runtime().routing().switchObservations())
                return Long.MAX_VALUE;
            long remaining = Math.max(0, config.runtime().routing().switchMinDwell().toNanos() - age(at, q.confirmedAt));
            if(q.failed)
                remaining = Math.max(remaining, timeout - age(at, q.failedAt));
            if(tree.roundStarted)
                remaining = Math.max(remaining, timeout - age(at, tree.lastRoundStart));
            return futureDelay(remaining);
        }


        void switchEvent(Tree tree, Round round, SwitchPhase phase, String reason, long at)
        {
            var change = round.switching;
            if(change == null || change.terminal || phase == SwitchPhase.STARTED && change.started)
                return;
            if(phase == SwitchPhase.STARTED)
                change.started = true;
            else
                change.terminal = true;
            var event = new SwitchEvent(tree.id, tree.origin, change.target.epoch, change.operation, phase,
                    change.previous.parent, change.target.session, change.previous.path, change.target.path,
                    change.revision, change.targetRevision, change.previousCost, change.replacementCost,
                    reason.length() > 256 ? reason.substring(0, 256) : reason, age(at, round.began));
            try
            {
                observer.onEvent(new Event(Reason.NONE, false, Optional.of(event)));

            }catch(RuntimeException error){
                requestClose();
            }
        }



        //* === Recuperação === *

        record Proof(UUID epoch, Neighbor.Session session, List<String> path, long sequence)
        {
            //* === Construtores === *

            Proof
            {
                path = List.copyOf(path);
            }



            //* === Lógica === *

            boolean sameBranch(Proof other)
            {
                return other != null && epoch.equals(other.epoch)
                        && session.equals(other.session) && path.equals(other.path);
            }
        }


        Proof eligibleProof(Tree t, long at)
        {
            if(!epochCurrent(t))
                return null;
            var candidate = row(t.id).route.selectedCandidate().orElse(null);
            if(candidate == null || candidate.metric().isEmpty()
                    || age(at, candidate.generationStartedAtNanos()) >= candidate.candidateTtlNanos())
                return null;
            var session = sessions.get(candidate.upstream().nodeId());
            if(session == null || !key(session).equals(candidate.upstream()) || !current(session))
                return null;
            return new Proof(t.epoch, session, candidate.path(), candidate.announceSeq());
        }


        boolean recheckable(ErrorCode code)
        {
            return code == ErrorCode.PATH_CHANGED || code == ErrorCode.NO_ROUTE
                    || code == ErrorCode.SOURCE_UNAVAILABLE || code == ErrorCode.TIMEOUT
                    || code == ErrorCode.RESOURCE_LIMIT;
        }


        long observedSequence(Tree t, Proof proof)
        {
            if(proof == null)
                return -1;
            long sequence = proof.sequence;
            for(var candidate : row(t.id).route.candidates())
            {
                if(candidate.serverEpoch().equals(proof.epoch)
                        && candidate.upstream().equals(key(proof.session)))
                    sequence = Math.max(sequence, candidate.announceSeq());
            }
            var line = lines.get(new LineKey(true, t.id, proof.epoch, proof.session));
            return line == null ? sequence : Math.max(sequence, Math.max(line.observedSequence, line.blockedSequence));
        }


        void observeAnnouncement(Neighbor.Session session, ControlMessage.Announcement announcement, long at, boolean distinct)
        {
            var t = trees.get(announcement.stream().streamId());
            if(t == null || !t.epoch.equals(announcement.stream().serverEpoch()))
                return;
            if(distinct)
            {
                observeQuality(t, session);
                var q = t.quality;
                var eligible = eligibleProof(t, at);
                if(q.failed && eligible != null && eligible.session.equals(session)
                        && eligible.sameBranch(q.blocked) && eligible.sequence > q.blocked.sequence)
                    q.rearm = true;
            }
            var line = lines.get(new LineKey(true, t.id, t.epoch, session));
            if(line != null)
                line.observedSequence = Math.max(line.observedSequence, announcement.announceSeq());
            var proof = eligibleProof(t, at);
            if(proof == null || !proof.session.equals(session)
                    || proof.sequence != announcement.announceSeq())
                return;
            if(t.renewalBlocked != null && proof.sameBranch(t.renewalBlocked)
                    && proof.sequence > t.renewalBlocked.sequence && age(at, t.renewalFailedAt) > 0)
                t.renewalBlocked = null;
            if(t.round != null && t.round.rejected != null && proof.sameBranch(t.round.rejected)
                    && proof.sequence > t.round.rejected.sequence && age(at, t.failedAt) > 0)
                t.round.rejected = null;
            if(!healthy(t, at) && !t.permanent && recheckable(t.failure)
                    && proof.sameBranch(t.blocked) && proof.sequence > t.blocked.sequence
                    && age(at, t.failedAt) > 0)
                t.credit = proof;
        }


        void blockRecoveryProof(Tree t, long at)
        {
            var proof = t.used == null ? eligibleProof(t, at) : t.used;
            if(proof != null)
            {
                long sequence = observedSequence(t, proof);
                t.blocked = new Proof(proof.epoch, proof.session, proof.path, sequence);
                var line = lines.get(new LineKey(true, t.id, proof.epoch, proof.session));
                if(line != null)
                    line.blockedSequence = Math.max(line.blockedSequence, sequence);
            }
            t.failedAt = at;
            if(t.credit != null && t.credit.sameBranch(t.blocked)
                    && t.credit.sequence <= t.blocked.sequence)
                t.credit = null;
        }


        boolean childInterest(Child c, long at)
        {
            return !c.detached && current(c.line.key.session) && epochCurrent(c.tree)
                    && (c.pending && !childElapsed(c, at)
                        || c.active != null && c.active.validity().orElseThrow().remainingNanos(at) > 0
                        || c.suspended != null && c.suspended.remainingNanos(at) > 0);
        }


        void loseConfirmation(Tree t, long at)
        {
            if(t.confirmed == null)
                return;
            boolean transferred = t.round != null && t.round.switching != null
                    && !roundElapsed(t.round, at) && eligibleProof(t, at) != null;
            if(transferred)
                t.round.switching.promoted = true;
            t.confirmed = null;
            t.confirmedLocals.clear();
            t.version = Math.incrementExact(t.version);
            t.lossCredit = !transferred;
            if(t.round != null && t.round.renew)
                fail(t, ErrorCode.NO_ROUTE, "CONFIRMATION_LOST");
            for(var child : t.children.values())
            {
                if(child.active != null)
                {
                    child.suspended = child.active.validity().orElseThrow();
                    child.active = null;
                }
            }
        }


        void reconcileRecovery(Tree t, long at)
        {
            var proof = eligibleProof(t, at);
            var previous = t.view;
            t.view = proof;
            boolean source = epochCurrent(t) && row(t.id).offered;
            boolean sourceReturned = source && !t.sourceAvailable;
            t.sourceAvailable = source;
            if(!demand(t, at))
            {
                t.credit = null;
                t.lossCredit = false;
                return;
            }
            if(healthy(t, at))
                return;
            boolean contextChanged = proof != null && (t.used == null
                    || !proof.session.equals(t.used.session) || !proof.epoch.equals(t.used.epoch));
            if(t.permanent && !contextChanged)
                return;
            if(proof != null)
            {
                boolean unblocked = t.blocked == null || !proof.sameBranch(t.blocked)
                        || proof.sequence > t.blocked.sequence;
                if(!proof.sameBranch(t.used) || previous == null && unblocked)
                    t.credit = proof;
            }
            if(t.credit != null && (!t.credit.sameBranch(proof) || proof.sequence < t.credit.sequence))
                t.credit = null;
            boolean credit = proof != null && (t.credit != null || t.lossCredit)
                    || source && (sourceReturned || t.lossCredit);
            if(t.round != null || !credit || t.roundStarted && age(at, t.lastRoundStart) < timeout)
                return;
            startRound(t, at, at);
        }


        Route.RecoveryPhase recoveryPhase(Tree t, long at)
        {
            if(healthy(t, at))
                return Route.RecoveryPhase.CONFIRMED;
            if(t.round != null)
                return Route.RecoveryPhase.ACTIVATING;
            if((t.credit != null || t.lossCredit) && eligibleProof(t, at) != null)
                return Route.RecoveryPhase.WAITING_FOR_BUDGET;
            return Route.RecoveryPhase.UNAVAILABLE;
        }


        Map<UUID,Route.Recovery> recoveries(long at)
        {
            var result = new LinkedHashMap<UUID,Route.Recovery>();
            for(var t : trees.values())
            {
                var phase = recoveryPhase(t, at);
                var attempt = t.round == null ? null : t.round.attempt;
                long remaining = t.round == null ? 0 : Math.max(0, t.round.budget - age(at, t.round.began));
                result.put(t.id, new Route.Recovery(t.id, t.epoch, phase, Optional.ofNullable(t.failure),
                        t.detail, t.generation, demand(t, at), t.round == null ? t.issued : t.round.issued,
                        attempts, Optional.ofNullable(attempt == null ? null : attempt.line.key.session),
                        attempt == null ? List.of() : attempt.path, remaining));
            }
            return result;
        }



        //* === Ativação === *

        void kick(){treeSweep=treeOrder.size();childSweep=childOrder.size();localSweep=localOrder.size();}
        boolean elapsed(long now,long began){return age(now,began)>=timeout;}
        long age(long now,long began){long age=now-began;if(age<0)throw new IllegalStateException("Activation clock horizon");return age;}
        void outcome(Local l,SubscriptionState state,ErrorCode code,String detail){
            if(l.outcome==null)l.outcome=new SubscriptionOutcome(l.key.stream,l.key.token,l.operation,state,Optional.ofNullable(code),detail);
        }
        SubscriptionTicket request(UUID stream,UUID token,boolean retry){
            Objects.requireNonNull(stream);Objects.requireNonNull(token);var key=new LocalKey(stream,token);
            long began=clock.getAsLong();var ticket=new Local(key,began);
            synchronized(resources){
                if(stopping.get()||view.diagnostics().phase()!=Phase.RUNNING){outcome(ticket,SubscriptionState.NOT_RUNNING,null,"NOT_RUNNING");return ticket;}
                var old=localTickets.get(key);
                if(old!=null&&!old.cancelled.get()&&(!retry||old.outcome==null))return old;
                long perStream=localTickets.keySet().stream().filter(k->k.stream.equals(stream)).count();
                if(old==null&&(localTickets.size()>=localLimit||perStream>=4)){
                    outcome(ticket,SubscriptionState.RESOURCE_LIMIT,ErrorCode.RESOURCE_LIMIT,"LOCAL_CAPACITY");return ticket;
                }
                localTickets.put(key,ticket);
            }
            if(!owner.offer(()->{
                try{admit(ticket);}catch(RuntimeException e){note(Reason.CLOCK_ERROR,true);}
            })){
                synchronized(resources){localTickets.remove(key,ticket);outcome(ticket,SubscriptionState.CLOSED,null,"OWNER_REJECTED");}
            }
            return ticket;
        }
        Tree existing(UUID id){return trees.get(id);}
        Row row(UUID id){return rows.get(id);}
        boolean epochCurrent(Tree t){var row=row(t.id);return row!=null&&row.route.serverEpoch().equals(Optional.of(t.epoch));}
        List<String> selectedPath(Tree t){
            var row=row(t.id);if(!epochCurrent(t))return List.of();
            if(row.offered)return List.of(config.nodeId());
            return row.route.selectedCandidate().map(RouteCandidate::path).orElse(List.of());
        }
        boolean healthy(Tree t,long at){
            var c=t.confirmed;if(c==null||!epochCurrent(t))return false;
            return c.source?row(t.id).offered:current(c.parent)&&c.lease.remainingNanos(at)>0;
        }
        boolean compatible(Tree t,List<String> prefix,long at){
            return healthy(t,at)&&t.confirmed.path.equals(prefix)&&selectedPath(t).equals(prefix)
                    &&(t.confirmed.source||row(t.id).route.knownUpstream().equals(Optional.of(key(t.confirmed.parent))));
        }
        Tree create(Row row){var t=new Tree(row);trees.put(t.id,t);treeOrder.add(t);return t;}
        void admit(Local local)
        {
            requireOwner();
            if(stopping.get())
                return;
            synchronized(resources)
            {
                if(localTickets.get(local.key) != local)
                    return;
            }
            long at = now();
            var row = row(local.key.stream);
            if(local.cancelled.get())
            {
                synchronized(resources)
                {
                    localTickets.remove(local.key, local);
                }
                outcome(local, SubscriptionState.CANCELLED, null, "CANCELLED");
                return;
            }
            ErrorCode rejection = row == null ? ErrorCode.UNKNOWN_STREAM
                    : row.route.serverEpoch().isEmpty() ? ErrorCode.NO_ROUTE : null;
            if(rejection != null)
            {
                synchronized(resources)
                {
                    localTickets.remove(local.key, local);
                }
                outcome(local, SubscriptionState.ERROR, rejection, rejection.name());
                return;
            }
            var tree = existing(row.id);
            if(tree == null && trees.size() >= treeLimit)
            {
                synchronized(resources)
                {
                    localTickets.remove(local.key, local);
                }
                outcome(local, SubscriptionState.RESOURCE_LIMIT, ErrorCode.RESOURCE_LIMIT, "TREE_CAPACITY");
                return;
            }
            if(tree == null)
                tree = create(row);
            localOrder.removeIf(old -> old.key.equals(local.key));
            localOrder.add(local);
            var previous = tree.locals.put(local.key.token, local);
            if(previous != null && previous.cancelled.get() && tree.confirmedLocals.remove(local.key.token))
                tree.version = Math.incrementExact(tree.version);
            if(elapsed(at, local.began))
            {
                if(tree.round == null && !healthy(tree, at))
                {
                    tree.used = eligibleProof(tree, at);
                    tree.view = tree.used;
                    tree.sourceAvailable = row.offered;
                    tree.lastRoundStart = local.began;
                    tree.roundStarted = true;
                    tree.generation = Math.incrementExact(tree.generation);
                    fail(tree, ErrorCode.TIMEOUT, "TIMEOUT");
                }
                outcome(local, SubscriptionState.TIMEOUT, ErrorCode.TIMEOUT, "TIMEOUT");

            }else if(healthy(tree, at) && !compatible(tree, selectedPath(tree), at)){
                outcome(local, SubscriptionState.ERROR, ErrorCode.PATH_CHANGED, "PATH_CHANGED");

            }else{
                tree.failure = null;
                startRound(tree, local.began, at);
            }
            kick();
            RoutingService.this.drive();
        }


        void startRound(Tree t, long began, long at)
        {
            if(t.round != null || healthy(t, at))
                return;
            t.lastRoundStart = began;
            t.roundStarted = true;
            t.generation = Math.incrementExact(t.generation);
            t.issued = 0;
            t.used = eligibleProof(t, at);
            t.view = t.used;
            t.credit = null;
            t.lossCredit = false;
            t.permanent = false;
            t.renewalBlocked = null;
            if(row(t.id).offered)
            {
                t.confirmed = new Confirmed(true, t.epoch, null, List.of(config.nodeId()), null);
                t.failure = null;
                t.version = Math.incrementExact(t.version);
                return;
            }
            if(t.used == null)
            {
                fail(t, ErrorCode.NO_ROUTE, "NO_ROUTE");
                return;
            }
            t.failure = null;
            t.detail = "";
            t.round = new Round(began);
        }
        void receive(Neighbor.Session session,ControlMessage m){
            long at=now();kick();
            if((m.type()==MessageType.ACTIVATE||m.type()==MessageType.SUBSCRIPTION_RENEW)&&m.payload() instanceof ControlMessage.Activation p)
                incoming(session,m.requestId(),p,at,m.type()==MessageType.SUBSCRIPTION_RENEW);
            else if(m.type()==MessageType.DEACTIVATE&&m.payload() instanceof ControlMessage.Deactivation p){
                var line=lines.get(new LineKey(false,p.streamId(),p.serverEpoch(),session));
                if(line!=null&&line.id.equals(p.subscriptionId())&&line.revision==p.revision())
                    cancelChild(session,p.streamId(),p.subscriptionId(),p.revision());
            }
            else if(m.type()==MessageType.ACTIVATE_ACK&&m.payload() instanceof ControlMessage.ActivationAck p){
                var t=trees.get(p.streamId());var a=t==null||t.round==null?null:t.round.attempt;
                if(a!=null&&a.submitted&&a.line.key.session.equals(session)&&a.request.equals(m.requestId())
                        &&t.epoch.equals(p.serverEpoch())&&a.line.id.equals(p.subscriptionId())&&a.revision==p.revision()
                        &&p.grantedLeaseMs()>0&&p.grantedLeaseMs()<=leaseMs){
                    if(a.early==null)a.early=p;if(a.accepted)confirm(a,at);
                }
            }else if(m.type()==MessageType.ERROR&&m.payload() instanceof ControlMessage.ErrorPayload p&&(p.relatedType()==11||p.relatedType()==14)){
                for(var t:trees.values())if(t.round!=null){var a=t.round.attempt;
                    if(a!=null&&p.relatedType()==(a.round.renew?14:11)&&a.submitted&&a.request.equals(m.requestId())&&a.line.key.session.equals(session)
                            &&p.code()!=null&&traceText(p.detail(),256)){
                        failedAttempt(a,p.code(),p.detail());break;
                    }
                }
            }
        }
        void incoming(Neighbor.Session session,UUID request,ControlMessage.Activation p,long at,boolean renew){
            int related=renew?14:11;
            if(p.streamId()==null||p.serverEpoch()==null||p.subscriptionId()==null||p.revision()<0
                    ||p.leaseMs()<1||p.leaseMs()>0xffff_ffffL||!tracePath(p.expectedPath(),false,false)
                    ||p.expectedPath().size()<2||!p.expectedPath().getLast().equals(session.nodeId())){
                unbound(session,request,related,ErrorCode.INVALID_MESSAGE,"INVALID_ACTIVATE",at);return;
            }
            var row=row(p.streamId());
            if(row==null){unbound(session,request,related,ErrorCode.UNKNOWN_STREAM,"UNKNOWN_STREAM",at);return;}
            if(!row.route.serverEpoch().equals(Optional.of(p.serverEpoch()))){unbound(session,request,related,ErrorCode.PATH_CHANGED,"EPOCH_CHANGED",at);return;}
            var lk=new LineKey(false,p.streamId(),p.serverEpoch(),session);var line=lines.get(lk);
            if(line!=null){
                if(!line.id.equals(p.subscriptionId())||p.revision()<line.revision){unbound(session,request,related,ErrorCode.STALE_REVISION,"STALE_REVISION",at);return;}
                if(p.revision()==line.revision){
                    if(!request.equals(line.request)){unbound(session,request,related,ErrorCode.STALE_REVISION,"REVISION_BOUND",at);return;}
                    if(renew!=line.renew||!p.equals(line.fingerprint)){unbound(session,request,related,ErrorCode.INVALID_MESSAGE,"CONFLICTING_DUPLICATE",at);return;}
                    if(line.terminal!=null){unbound(session,request,related,line.terminal,line.detail,at);return;}
                    var c=line.child;if(c!=null&&!c.detached&&c.active!=null&&!childElapsed(c,at)){
                        if(!c.pending){c.ackWanted=true;c.replay=true;}
                    }
                    return;
                }
            }
            if(renew&&(line==null||line.child==null||line.child.active==null
                    ||line.child.active.validity().orElseThrow().remainingNanos(at)==0)){
                unbound(session,request,related,ErrorCode.NO_ROUTE,"NO_ACTIVE_GRANT",at);return;
            }
            var prefix=p.expectedPath().subList(0,p.expectedPath().size()-1);
            if(!prefix.getLast().equals(config.nodeId())||!prefix.getFirst().equals(row.origin)){
                unbound(session,request,related,ErrorCode.PATH_CHANGED,"PATH_CHANGED",at);return;
            }
            if(new HashSet<>(p.expectedPath()).size()!=p.expectedPath().size()){
                unbound(session,request,related,ErrorCode.LOOP_DETECTED,"LOOP_DETECTED",at);return;
            }
            var t=trees.get(row.id);
            var selected=row.offered?List.of(config.nodeId()):row.route.selectedCandidate().map(RouteCandidate::path).orElse(List.of());
            if(row.local&&!row.offered){unbound(session,request,related,ErrorCode.SOURCE_UNAVAILABLE,"SOURCE_UNAVAILABLE",at);return;}
            if(!prefix.equals(selected)||t!=null&&healthy(t,at)&&!compatible(t,prefix,at)){
                var code=selected.isEmpty()&&(t==null||!healthy(t,at))?ErrorCode.NO_ROUTE:ErrorCode.PATH_CHANGED;
                unbound(session,request,related,code,code.name(),at);return;
            }
            var previous=line==null?null:line.child;
            long peerPending=childOrder.stream().filter(c->!c.detached&&c.pending&&c.line.key.session.equals(session)&&c!=previous).count();
            if(t==null&&trees.size()>=treeLimit||line==null&&lines.size()>=historyLimit
                    ||(previous==null||previous.detached)&&childOrder.size()>=childLimit||peerPending>=4){
                unbound(session,request,related,ErrorCode.RESOURCE_LIMIT,"ACTIVATION_CAPACITY",at);return;
            }
            if(t==null)t=create(row);
            if(line==null){line=new Line(lk,p.subscriptionId());lines.put(lk,line);}
            Subscription old=previous==null?null:previous.active;
            if(previous!=null){detach(previous);}
            var c=new Child(t,line,request,p,at);c.active=old;c.renew=renew;
            if(renew)c.budget=Math.min(timeout,old.validity().orElseThrow().remainingNanos(at));
            line.renew=renew;line.revision=p.revision();line.request=request;line.fingerprint=p;line.terminal=null;line.detail="";line.child=c;
            t.children.put(session,c);childOrder.add(c);t.failure=null;
            if(!t.roundStarted)
                startRound(t, at, at);
            else if(!healthy(t, at))
            {
                t.credit = eligibleProof(t, at);
                reconcileRecovery(t, at);
            }
            kick();
        }
        void confirm(Attempt a,long at){
            var t=a.tree;if(t.round!=a.round||a.round.attempt!=a||a.early==null||!a.accepted)return;
            if(roundElapsed(a.round,at)||a.renewal!=null&&a.renewal.previousGrant().remainingNanos(at)==0){
                fail(t,ErrorCode.TIMEOUT,"TIMEOUT");return;
            }
            if(!demand(t, at))
            {
                retireBranch(t, at);
                return;
            }
            if(t.confirmed != null && !healthy(t, at))
                loseConfirmation(t, at);
            if(a.round.switching != null && !a.round.switching.promoted && !qualityValid(t, at))
            {
                fail(t, ErrorCode.PATH_CHANGED, "QUALITY_CHANGED");
                return;
            }
            if(!epochCurrent(t)||!current(a.line.key.session)||!selectedPath(t).equals(a.path)
                    ||!row(t.id).route.knownUpstream().equals(Optional.of(key(a.line.key.session)))){
                failedAttempt(a,ErrorCode.PATH_CHANGED,"PATH_CHANGED");return;
            }
            var validity=new Subscription.Lease(a.began,Math.multiplyExact(a.early.grantedLeaseMs(),1_000_000L));
            if(validity.remainingNanos(at)==0){failedAttempt(a,ErrorCode.TIMEOUT,"GRANT_EXPIRED");return;}
            var previous = t.confirmed;
            var installed = new Proof(t.epoch, a.line.key.session, a.path, -1);
            if(!installed.sameBranch(t.quality.anchor))
            {
                t.quality.confirmedAt = at;
                t.quality.anchored = true;
                t.quality.anchor = installed;
            }
            if(a.round.switching != null)
            {
                for(var child : t.children.values())
                {
                    if(child.active != null && !child.active.expectedPath().subList(0,
                            child.active.expectedPath().size() - 1).equals(a.path))
                    {
                        child.suspended = child.active.validity().orElseThrow();
                        child.active = null;
                    }
                }
            }
            t.confirmed=new Confirmed(false,t.epoch,a.line.key.session,a.path,validity);
            t.upstream=a.line;t.submittedRevision=a.revision;t.renewBegan=a.began;
            t.renewPeriod=Math.min(config.runtime().subscription().renew().toNanos(),validity.durationNanos()/3);
            t.round=null;t.failure=null;
            t.issued = a.round.issued;
            t.detail = "";
            t.version=Math.incrementExact(t.version);kick();
            if(a.round.switching != null)
            {
                for(var local : t.locals.values())
                {
                    if(!local.cancelled.get())
                        t.confirmedLocals.add(local.key.token);
                }
                t.quality.observations = 0;
                t.quality.target = null;
                t.quality.failed = false;
                publish(at);
                switchEvent(t, a.round, SwitchPhase.SUCCESS, "CONFIRMED", at);
                var old = a.round.switching;
                if(!stopping.get() && current(old.previous.parent))
                {
                    var identity = new Subscription.Identity(old.previous.parent, t.id, t.epoch,
                            old.line.id, old.revision, old.version);
                    t.prune = new Prune(new PruneRequest(identity, UUID.randomUUID(), at, timeout), old.line, true);
                }
            }
        }
        void failedAttempt(Attempt a, ErrorCode code, String detail)
        {
            var t = a.tree;
            if(t.round != a.round || a.round.attempt != a)
                return;
            long at = now();
            if(a.round.switching != null && !a.round.switching.promoted)
            {
                fail(t, code, detail);
                return;
            }
            a.round.attempt = null;
            if(a.round.renew && code == ErrorCode.PATH_CHANGED)
            {
                var proof = new Proof(t.epoch, a.line.key.session, a.path, -1);
                long sequence = observedSequence(t, proof);
                t.renewalBlocked = new Proof(t.epoch, a.line.key.session, a.path, sequence);
                t.renewalFailedAt = at;
            }
            if(!a.round.renew && code == ErrorCode.PATH_CHANGED)
            {
                var rejected = new Proof(t.epoch, a.line.key.session, a.path, -1);
                a.round.rejected = new Proof(t.epoch, rejected.session, rejected.path, observedSequence(t, rejected));
                t.failedAt = at;
            }
            if(roundElapsed(a.round, at) || a.round.issued >= (a.round.renew ? 1 : attempts)
                    || code == ErrorCode.INVALID_MESSAGE || code == ErrorCode.STALE_REVISION)
                fail(t, code, detail);
            kick();
        }


        void fail(Tree t, ErrorCode code, String detail)
        {
            var round = t.round;
            if(round != null && round.switching != null)
            {
                t.quality.blocked = new Proof(t.epoch, round.switching.target.session,
                        round.switching.target.path, observedSequence(t, round.switching.target));
                t.quality.failedAt = now();
                t.quality.failed = true;
                t.quality.rearm = false;
                t.quality.permanent = code == ErrorCode.INVALID_MESSAGE || code == ErrorCode.STALE_REVISION;
                t.quality.observations = 0;
                switchEvent(t, round, SwitchPhase.FAILURE, detail, now());
                if(!round.switching.promoted && healthy(t, now()))
                {
                    t.issued = round.issued;
                    t.round = null;
                    kick();
                    return;
                }
            }
            if(t.round != null)
                t.issued = t.round.issued;
            blockRecoveryProof(t, now());
            t.round = null;
            t.failure = code;
            t.detail = detail;
            t.permanent = code == ErrorCode.INVALID_MESSAGE || code == ErrorCode.STALE_REVISION;
            kick();
        }


        void failChild(Child c,ErrorCode code,String detail,long at){
            c.pending=false;c.ackWanted=false;c.error=code;c.detail=detail;c.errorWanted=!childElapsed(c,at);
            c.line.terminal=code;c.line.detail=detail;
            childSweep=childOrder.size();
        }
        void cancelChild(Neighbor.Session session, UUID stream, UUID id, long revision)
        {
            var tree = trees.get(stream);
            var child = tree == null ? null : tree.children.get(session);
            if(child == null || !child.line.id.equals(id) || child.payload.revision() != revision)
                return;
            child.active = null;
            child.suspended = null;
            failChild(child, ErrorCode.STALE_REVISION, "CANCELLED", now());
            child.errorWanted = false;
            tree.version = Math.incrementExact(tree.version);
            kick();
        }


        void detach(Child c)
        {
            c.detached = true;
            c.ackWanted = false;
            c.errorWanted = false;
            c.tree.children.remove(c.line.key.session, c);
            childOrder.remove(c);
            if(c.line.child == c)
                c.line.child = null;
            treeSweep = treeOrder.size();
        }
        boolean wants(Tree t){return t.locals.values().stream().anyMatch(l->l.outcome==null&&!l.cancelled.get())
                ||t.children.values().stream().anyMatch(c->c.pending);}
        boolean roundElapsed(Round r,long at){return age(at,r.began)>=r.budget;}
        boolean childElapsed(Child c,long at){return age(at,c.began)>=c.budget;}
        boolean demand(Tree t, long at)
        {
            return t.locals.values().stream().anyMatch(l -> !l.cancelled.get())
                    || t.children.values().stream().anyMatch(c -> childInterest(c, at));
        }


        void retireBranch(Tree t,long at){
            if(t.round != null && t.round.switching != null)
                switchEvent(t, t.round, SwitchPhase.FAILURE, "CANCELLED", at);
            t.round=null;
            t.credit = null;
            t.lossCredit = false;
            if(t.confirmed!=null&&!t.confirmed.source&&t.upstream!=null&&t.submittedRevision>=0){
                var identity=new Subscription.Identity(t.upstream.key.session,t.id,t.epoch,t.upstream.id,t.submittedRevision,t.version);
                t.prune=new Prune(new PruneRequest(identity,UUID.randomUUID(),at,timeout),t.upstream);
            }
            if(t.confirmed!=null){t.confirmed=null;t.confirmedLocals.clear();t.version=Math.incrementExact(t.version);}
        }
        void stepTree(Tree t, long at)
        {
            if(trees.get(t.id) != t)
                return;
            for(var l : List.copyOf(t.locals.values()))
            {
                boolean latest;
                synchronized(resources)
                {
                    latest = localTickets.get(l.key) == l;
                }
                if(!latest || l.cancelled.get())
                {
                    boolean removed = t.locals.remove(l.key.token, l);
                    localOrder.remove(l);
                    if(removed && l.cancelled.get() && t.confirmedLocals.remove(l.key.token))
                        t.version = Math.incrementExact(t.version);
                    if(latest)
                    {
                        synchronized(resources)
                        {
                            localTickets.remove(l.key, l);
                        }
                    }
                    outcome(l, SubscriptionState.CANCELLED, null, "CANCELLED");
                }
            }
            if(t.confirmed != null && !healthy(t, at))
                loseConfirmation(t, at);
            if(row(t.id).local && !row(t.id).offered && t.failure != ErrorCode.SOURCE_UNAVAILABLE)
                fail(t, ErrorCode.SOURCE_UNAVAILABLE, "SOURCE_UNAVAILABLE");
            boolean wanted = demand(t, at);
            if(!wanted && (t.confirmed != null || t.round != null))
                retireBranch(t, at);
            if(wanted && t.prune != null && !t.prune.retired)
                t.prune = null;
            reconcileRecovery(t, at);
            stepQuality(t, at);
            if(wanted && healthy(t, at) && !t.confirmed.source && t.round == null
                    && t.renewalBlocked == null && age(at, t.renewBegan) >= t.renewPeriod
                    && compatible(t, t.confirmed.path, at))
            {
                t.renewBegan = at;
                t.round = new Round(at);
                t.round.renew = true;
                t.round.budget = Math.min(timeout, t.confirmed.lease.remainingNanos(at));
            }
            if(t.prune != null)
            {
                var prune = t.prune;
                var q = prune.request;
                var i = q.identity();
                if(age(at, q.beganNanos()) >= q.budgetNanos())
                    t.prune = null;
                else if(send(row(t.id), i.session(), SendKind.PRUNE, null, null, null,
                        new ControlMessage(MessageType.DEACTIVATE, q.requestId(), config.nodeId(), instance,
                            new ControlMessage.Deactivation(i.streamId(), i.serverEpoch(), i.subscriptionId(), i.revision())), at))
                    t.prune = null;
            }
            if(t.round != null && roundElapsed(t.round, at))
            {
                boolean capacity = t.round.capacityBlocked && t.round.attempt != null
                        && !t.round.attempt.submitted;
                fail(t, capacity ? ErrorCode.RESOURCE_LIMIT : ErrorCode.TIMEOUT,
                        capacity ? "ACTIVATION_CAPACITY" : "TIMEOUT");
            }
            for(var l : t.locals.values())
            {
                if(!l.cancelled.get() && healthy(t, at) && compatible(t, selectedPath(t), at)
                        && t.confirmedLocals.add(l.key.token))
                    t.version = Math.incrementExact(t.version);
                if(l.outcome != null)
                    continue;
                if(elapsed(at, l.began))
                    outcome(l, SubscriptionState.TIMEOUT, ErrorCode.TIMEOUT, "TIMEOUT");
                else if(healthy(t, at))
                {
                    if(compatible(t, selectedPath(t), at))
                        outcome(l, SubscriptionState.SUCCESS, null, "");
                    else
                        outcome(l, SubscriptionState.ERROR, ErrorCode.PATH_CHANGED, "PATH_CHANGED");

                }else if(t.failure != null){
                    outcome(l, t.failure == ErrorCode.TIMEOUT ? SubscriptionState.TIMEOUT : SubscriptionState.ERROR,
                            t.failure, t.detail);
                }
            }
            var r = t.round;
            if(r != null && r.attempt == null)
            {
                var proof = eligibleProof(t, at);
                if(proof == null)
                {
                    fail(t, ErrorCode.NO_ROUTE, "NO_ROUTE");
                    return;
                }
                if(r.rejected != null && proof.sameBranch(r.rejected))
                    return;
                t.used = proof;
                if(t.credit != null && t.credit.sameBranch(proof) && t.credit.sequence <= proof.sequence)
                    t.credit = null;
                var lk = new LineKey(true, t.id, t.epoch, proof.session);
                var line = lines.get(lk);
                if(line == null)
                {
                    if(lines.size() >= historyLimit)
                    {
                        fail(t, ErrorCode.RESOURCE_LIMIT, "HISTORY_CAPACITY");
                        return;
                    }
                    line = new Line(lk, UUID.randomUUID());
                    lines.put(lk, line);
                }
                line.observedSequence = Math.max(line.observedSequence, proof.sequence);
                if(line.revision == Long.MAX_VALUE)
                {
                    fail(t, ErrorCode.STALE_REVISION, "REVISION_EXHAUSTED");
                    return;
                }
                r.attempt = new Attempt(t, r, line, proof.path, r.issued == 0 ? r.began : at, ++line.revision);
            }
            if(r != null && r.attempt != null && !r.attempt.submitted)
            {
                var a = r.attempt;
                if(r.issued >= (r.renew ? 1 : attempts))
                {
                    fail(t, ErrorCode.TIMEOUT, "ATTEMPT_LIMIT");
                    return;
                }
                if(!selectedPath(t).equals(a.path) || !current(a.line.key.session))
                {
                    failedAttempt(a, ErrorCode.PATH_CHANGED, "PATH_CHANGED");
                    return;
                }
                var m = new ControlMessage(r.renew ? MessageType.SUBSCRIPTION_RENEW : MessageType.ACTIVATE,
                        a.request, config.nodeId(), instance,
                        new ControlMessage.Activation(t.id, t.epoch, a.line.id, a.revision, leaseMs, a.path));
                r.capacityBlocked = !send(row(t.id), a.line.key.session, SendKind.REQUEST, a, null, null, m, at);
            }
            if(t.locals.isEmpty() && t.children.isEmpty() && t.round == null && t.prune == null)
            {
                trees.remove(t.id, t);
                treeOrder.remove(t);
            }
        }


        void stepChild(Child c,long at){
            if(c.detached)return;var t=c.tree;
            if(!epochCurrent(t)||!current(c.line.key.session)){detach(c);return;}
            if(c.active != null && (c.active.validity().orElseThrow().remainingNanos(at) == 0 || !healthy(t, at)))
            {
                c.suspended = c.active.validity().orElseThrow();
                c.active = null;
                if(!c.pending)
                {
                    c.line.terminal = ErrorCode.NO_ROUTE;
                    c.line.detail = "EXPIRED";
                }
            }
            if(c.suspended != null && c.suspended.remainingNanos(at) == 0)
                c.suspended = null;
            if(c.pending){
                if(childElapsed(c,at)||t.round!=null&&roundElapsed(t.round,at))failChild(c,ErrorCode.TIMEOUT,"TIMEOUT",at);
                else if(healthy(t,at)){
                    var prefix=c.payload.expectedPath().subList(0,c.payload.expectedPath().size()-1);
                    if(compatible(t,prefix,at))c.ackWanted=true;else failChild(c,ErrorCode.PATH_CHANGED,"PATH_CHANGED",at);
                }else if(t.failure!=null)failChild(c,t.failure,t.detail,at);
            }
            if(c.ackWanted&&!healthy(t,at))failChild(c,ErrorCode.NO_ROUTE,"CONFIRMATION_EXPIRED",at);
            boolean inFlight;synchronized(resources){inFlight=sends.stream().anyMatch(s->s.child==c&&!s.continuationDone);}
            if(childElapsed(c,at)){c.ackWanted=false;c.errorWanted=false;}
            if(!inFlight&&(c.ackWanted||c.errorWanted)){
                if(c.errorWanted){
                    var m=new ControlMessage(MessageType.ERROR,c.request,config.nodeId(),instance,new ControlMessage.ErrorPayload(c.error,c.renew?14:11,c.detail));
                    if(send(c.line,c.line.key.session,SendKind.ERROR,null,c,null,m,at))c.errorWanted=false;
                }else{
                    long remaining=t.confirmed.source?Math.multiplyExact(Math.min(leaseMs,c.payload.leaseMs()),1_000_000L):t.confirmed.lease.remainingNanos(at);
                    if(c.active!=null&&(!c.renew||c.replay))remaining=Math.min(remaining,c.active.validity().orElseThrow().remainingNanos(at));
                    long grant=Math.min(Math.min(leaseMs,c.payload.leaseMs()),remaining/1_000_000L);
                    if(grant<1){failChild(c,ErrorCode.NO_ROUTE,"GRANT_TOO_SHORT",at);return;}
                    var validity=new Subscription.Lease(at,Math.multiplyExact(grant,1_000_000L));
                    var value=new Subscription(t.id,t.epoch,c.line.key.session,c.line.id,c.payload.revision(),c.request,
                            c.payload.expectedPath(),c.payload.leaseMs(),Subscription.State.ACTIVE,Optional.of(validity));
                    var m=new ControlMessage(MessageType.ACTIVATE_ACK,c.request,config.nodeId(),instance,
                            new ControlMessage.ActivationAck(t.id,t.epoch,c.line.id,c.payload.revision(),grant));
                    if(send(c.line,c.line.key.session,SendKind.ACK,null,c,value,m,at))c.ackWanted=false;
                }
            }
            if(!c.pending&&c.active==null&&c.suspended==null&&!c.ackWanted&&!c.errorWanted&&!inFlight)detach(c);
        }
        boolean quota(Neighbor.Session session,long at){
            var q=responseQuotas.computeIfAbsent(session,s->new ResponseQuota(at));
            if(age(at,q.began)>=WINDOW){q.began=at;q.used=0;}
            if(q.used>=16)return false;q.used++;return true;
        }
        boolean send(Object context,Neighbor.Session session,SendKind kind,Attempt attempt,Child child,
                Subscription grant,ControlMessage message,long at){
            if(stopping.get()||!current(session))return false;
            final ActSend send;
            synchronized(resources){
                if(sends.size()>=sendLimit||sends.stream().filter(s->s.session.equals(session)).count()>=4
                        ||context!=null&&sends.stream().filter(s->s.context==context).count()>=2)return false;
                if(kind==SendKind.UNBOUND&&(sends.stream().filter(s->s.kind==SendKind.UNBOUND).count()>=errorLimit
                        ||sends.stream().anyMatch(s->s.kind==SendKind.UNBOUND&&s.session.equals(session))))return false;
                send=new ActSend(context,session,kind,attempt,child,grant);sends.add(send);
            }
            if((kind==SendKind.ACK||kind==SendKind.ERROR||kind==SendKind.UNBOUND)&&!quota(session,at)){
                synchronized(resources){sends.remove(send);resources.notifyAll();}return false;
            }
            // Reserving a physical ticket/quota can consume time. Revalidate and
            // rebuild durations at the actual port boundary, never extend a grant.
            try{
                long dispatch=now();
                if(stopping.get()||!current(session)
                        ||attempt!=null&&(attempt.tree.round!=attempt.round||roundElapsed(attempt.round,dispatch)
                            ||!selectedPath(attempt.tree).equals(attempt.path))
                        ||child!=null&&(child.detached||childElapsed(child,dispatch))){
                    synchronized(resources){sends.remove(send);resources.notifyAll();}return false;
                }
                if(attempt != null && attempt.round.switching != null && !attempt.round.switching.promoted
                        && !qualityValid(attempt.tree, dispatch))
                {
                    synchronized(resources){sends.remove(send);resources.notifyAll();}
                    fail(attempt.tree, ErrorCode.PATH_CHANGED, "QUALITY_CHANGED");
                    return false;
                }
                if(kind==SendKind.PRUNE){
                    var payload=(ControlMessage.Deactivation)message.payload();var t=trees.get(payload.streamId());
                    var prune=t==null?null:t.prune;
                    if(prune==null||!prune.request.requestId().equals(message.requestId())
                            ||age(dispatch,prune.request.beganNanos())>=prune.request.budgetNanos()){
                        synchronized(resources){sends.remove(send);resources.notifyAll();}return false;
                    }
                }
                if(kind==SendKind.ACK){
                    var t=child.tree;var prefix=child.payload.expectedPath().subList(0,child.payload.expectedPath().size()-1);
                    if(!healthy(t,dispatch)||!child.replay&&!compatible(t,prefix,dispatch)){
                        synchronized(resources){sends.remove(send);resources.notifyAll();}
                        failChild(child,ErrorCode.PATH_CHANGED,"PATH_CHANGED",dispatch);return false;
                    }
                    long remaining=grant.validity().orElseThrow().remainingNanos(dispatch);
                    if(!t.confirmed.source)remaining=Math.min(remaining,t.confirmed.lease.remainingNanos(dispatch));
                    if(child.active!=null&&(!child.renew||child.replay))remaining=Math.min(remaining,child.active.validity().orElseThrow().remainingNanos(dispatch));
                    long millis=Math.min(Math.min(leaseMs,child.payload.leaseMs()),remaining/1_000_000L);
                    if(millis<1){synchronized(resources){sends.remove(send);resources.notifyAll();}
                        failChild(child,ErrorCode.NO_ROUTE,"GRANT_TOO_SHORT",dispatch);return false;}
                    send.grant=new Subscription(grant.streamId(),grant.serverEpoch(),grant.child(),grant.subscriptionId(),
                            grant.revision(),grant.requestId(),grant.expectedPath(),grant.requestedLeaseMs(),grant.state(),
                            Optional.of(new Subscription.Lease(dispatch,Math.multiplyExact(millis,1_000_000L))));
                    message=new ControlMessage(MessageType.ACTIVATE_ACK,child.request,config.nodeId(),instance,
                            new ControlMessage.ActivationAck(t.id,t.epoch,child.line.id,child.payload.revision(),millis));
                }
            }catch(RuntimeException error){synchronized(resources){sends.remove(send);resources.notifyAll();}throw error;}
            if(attempt!=null){
                attempt.submitted=true;attempt.round.issued++;
                if(attempt.round.switching != null)
                    attempt.round.switching.targetRevision = attempt.revision;
                if(attempt.round.switching == null){attempt.tree.upstream=attempt.line;attempt.tree.submittedRevision=attempt.revision;}
            }
            try{Objects.requireNonNull(control.send(session,message)).whenComplete(send::complete);}
            catch(RuntimeException e){send.complete(null,e);}return true;
        }
        void unbound(Neighbor.Session session,UUID request,int related,ErrorCode code,String detail,long at){
            send(null,session,SendKind.UNBOUND,null,null,null,new ControlMessage(MessageType.ERROR,request,
                    config.nodeId(),instance,new ControlMessage.ErrorPayload(code,related,detail)),at);
        }
        boolean release(ActSend s){if(s.callbackDone&&s.continuationDone&&sends.remove(s)){resources.notifyAll();return true;}return false;}
        void completed(ActSend s){
            try{
                long at=now();if(stopping.get())return;
                if((s.result==Connection.SendResult.CLOSED||s.result==Connection.SendResult.OVERFLOW)&&current(s.session)){
                    remove(s.session);return;
                }
                if(s.kind==SendKind.REQUEST){var a=s.attempt;
                    if(a.tree.round!=a.round||a.round.attempt!=a)return;
                    if(s.error==null&&s.result==Connection.SendResult.ACCEPTED){a.accepted=true;if(a.early!=null)confirm(a,at);}
                    else failedAttempt(a,ErrorCode.NO_ROUTE,"ACTIVATE_SEND_FAILED");
                }else if(s.child!=null){var c=s.child;
                    if(c.detached||c.line.child!=c)return;
                    if(s.kind==SendKind.ACK){
                        // Logical cancellation/failure is terminal even while its ACK send is physically live.
                        // The finally below still completes this continuation and retains a running callback.
                        if(c.line.terminal!=null)return;
                        if(s.error==null&&s.result==Connection.SendResult.ACCEPTED&&epochCurrent(c.tree)
                                &&current(c.line.key.session)&&healthy(c.tree,at)&&!childElapsed(c,at)
                                &&s.grant.validity().orElseThrow().remainingNanos(at)>0
                                &&(c.replay||compatible(c.tree,c.payload.expectedPath().subList(0,c.payload.expectedPath().size()-1),at))){
                            if(!c.replay){c.active=s.grant;c.tree.version=Math.incrementExact(c.tree.version);}
                            c.pending=false;c.ackWanted=false;c.line.terminal=null;c.replay=false;
                        }else failChild(c,ErrorCode.PATH_CHANGED,"ACK_NO_LONGER_VALID",at);
                    }
                }
            }finally{synchronized(resources){s.continuationDone=true;release(s);}}
        }
        void drive(){
            if(changed.getAndSet(false))kick();
            List<ActSend> done;synchronized(resources){done=sends.stream().filter(s->s.ready&&!s.continuationDone).limit(4).toList();}
            for(var s:done)completed(s);
            int count=Math.min(4,treeSweep);while(count-->0&&!treeOrder.isEmpty()){
                var t=treeOrder.removeFirst();treeOrder.addLast(t);treeSweep--;stepTree(t,now());
            }
            count=Math.min(6,childSweep);while(count-->0&&!childOrder.isEmpty()){
                var c=childOrder.removeFirst();childOrder.addLast(c);childSweep--;stepChild(c,now());
            }
            count=Math.min(2,localSweep);while(count-->0&&!localOrder.isEmpty()){
                var l=localOrder.removeFirst();localOrder.addLast(l);localSweep--;
                boolean latest;synchronized(resources){latest=localTickets.get(l.key)==l;}
                if(!latest||l.cancelled.get()){
                    localOrder.remove(l);
                    if(latest){synchronized(resources){localTickets.remove(l.key,l);}}
                    var t=trees.get(l.key.stream);
                    if(t!=null&&t.locals.remove(l.key.token,l)&&l.cancelled.get()&&t.confirmedLocals.remove(l.key.token))
                        t.version=Math.incrementExact(t.version);
                    outcome(l,SubscriptionState.CANCELLED,null,"CANCELLED");
                }
            }
            treeSweep=Math.min(treeSweep,treeOrder.size());childSweep=Math.min(childSweep,childOrder.size());localSweep=Math.min(localSweep,localOrder.size());
            boolean ready;synchronized(resources){ready=sends.stream().anyMatch(s->s.ready&&!s.continuationDone);}
            if(treeSweep>0||childSweep>0||localSweep>0||ready||changed.get())wake();
        }
        long futureDelay(long remaining){return remaining>0?remaining:Long.MAX_VALUE;}
        long nextDelay(long at){
            long delay=Long.MAX_VALUE;
            for(var t:trees.values()){
                if(t.round!=null)delay=Math.min(delay,futureDelay(t.round.budget-age(at,t.round.began)));
                if(t.confirmed!=null&&!t.confirmed.source){
                    delay=Math.min(delay,futureDelay(t.confirmed.lease.remainingNanos(at)));
                    delay=Math.min(delay,qualityDelay(t,at));
                    if(t.round==null&&t.renewalBlocked==null&&demand(t,at)&&compatible(t,t.confirmed.path,at))
                        delay=Math.min(delay,futureDelay(t.renewPeriod-age(at,t.renewBegan)));
                }
                if(t.round == null && !healthy(t, at) && demand(t, at)
                        && (t.credit != null || t.lossCredit) && (eligibleProof(t, at) != null || row(t.id).offered))
                    delay = Math.min(delay, futureDelay(timeout - age(at, t.lastRoundStart)));
                if(t.prune!=null)delay=Math.min(delay,futureDelay(timeout-age(at,t.prune.request.beganNanos())));
            }
            for(var c:childOrder){
                if(c.pending||c.ackWanted||c.errorWanted)delay=Math.min(delay,futureDelay(c.budget-age(at,c.began)));
                if(c.active!=null)delay=Math.min(delay,futureDelay(c.active.validity().orElseThrow().remainingNanos(at)));
                if(c.suspended != null)
                    delay = Math.min(delay, futureDelay(c.suspended.remainingNanos(at)));
                var q=responseQuotas.get(c.line.key.session);
                if((c.ackWanted||c.errorWanted)&&q!=null&&q.used>=16)delay=Math.min(delay,futureDelay(WINDOW-age(at,q.began)));
            }
            return delay;
        }
        Map<UUID,Route.Confirmation> forwarding(long at){
            var result=new LinkedHashMap<UUID,Route.Confirmation>();
            for(var t:trees.values())if(healthy(t,at)){
                var c=t.confirmed;var children=new LinkedHashMap<String,Subscription>();
                for(var child:t.children.values())if(child.active!=null&&child.active.validity().orElseThrow().remainingNanos(at)>0)
                    children.put(child.line.key.session.nodeId(),child.active);
                var locals=new HashSet<UUID>();
                for(var token:t.confirmedLocals){var l=t.locals.get(token);if(l!=null&&!l.cancelled.get())locals.add(token);}
                if(!children.isEmpty()||!locals.isEmpty())result.put(t.id,new Route.Confirmation(t.id,t.origin,t.epoch,c.source,
                        Optional.ofNullable(c.parent),c.path,children,locals,Optional.ofNullable(c.lease),t.version));
            }
            return result;
        }
        void sessionDown(Neighbor.Session session)
        {
            long at = now();
            responseQuotas.remove(session);
            metricStamps.remove(session);
            for(var t : trees.values())
            {
                var child = t.children.get(session);
                if(child != null)
                    detach(child);
                if(t.confirmed != null && session.equals(t.confirmed.parent))
                    loseConfirmation(t, at);
                if(t.round != null && t.round.attempt != null
                        && session.equals(t.round.attempt.line.key.session))
                    fail(t, ErrorCode.NO_ROUTE, "SESSION_CLOSED");
            }
            lines.keySet().removeIf(k -> k.session.equals(session));
            kick();
        }


        void epochChanged(String origin, UUID epoch)
        {
            long at = now();
            for(var t : List.copyOf(trees.values()))
            {
                if(!t.origin.equals(origin) || t.epoch.equals(epoch))
                    continue;
                for(var child : List.copyOf(t.children.values()))
                {
                    detach(child);
                }
                for(var local : t.locals.values())
                {
                    outcome(local, SubscriptionState.ERROR, ErrorCode.PATH_CHANGED, "EPOCH_CHANGED");
                }
                loseConfirmation(t, at);
                fail(t, ErrorCode.PATH_CHANGED, "EPOCH_CHANGED");
                t.epoch = epoch;
                t.prune = null;
                t.upstream = null;
                t.submittedRevision = -1;
                t.renewalBlocked = null;
                t.view = null;
                t.credit = null;
                t.lossCredit = true;
                t.version = Math.incrementExact(t.version);
                if(t.locals.isEmpty())
                {
                    trees.remove(t.id, t);
                    treeOrder.remove(t);
                }
            }
            lines.keySet().removeIf(k -> {
                var row = row(k.stream);
                return row != null && row.origin.equals(origin) && !k.epoch.equals(epoch);
            });
            kick();
        }


        ActivationLoad load(){
            synchronized(resources){return new ActivationLoad(trees.size(),childOrder.size(),localTickets.size(),lines.size(),sends.size(),
                    (int)sends.stream().filter(s->s.kind==SendKind.UNBOUND).count(),
                    (int)childOrder.stream().filter(c->c.ackWanted||c.errorWanted).count(),(int)childOrder.stream().filter(c->c.pending).count());}
        }
        void close()
        {
            synchronized(resources)
            {
                for(var local : localTickets.values())
                {
                    outcome(local, SubscriptionState.CLOSED, null, "CLOSED");
                }
                localTickets.clear();
            }
            for(var t : trees.values())
            {
                if(t.round != null && t.round.switching != null)
                {
                    long at = clock.getAsLong();
                    if(at - t.round.began < 0)
                        at = t.round.began;
                    switchEvent(t, t.round, SwitchPhase.FAILURE, "CLOSED", at);
                }
                t.locals.clear();
                t.children.clear();
                t.confirmedLocals.clear();
                t.round = null;
                t.confirmed = null;
                t.credit = null;
                t.lossCredit = false;
                t.view = null;
                t.used = null;
                t.blocked = null;
                t.renewalBlocked = null;
                t.prune = null;
            }
            trees.clear();
            treeOrder.clear();
            childOrder.clear();
            localOrder.clear();
            lines.clear();
            responseQuotas.clear();
            treeSweep = 0;
            childSweep = 0;
            localSweep = 0;
            synchronized(resources)
            {
                for(var send : List.copyOf(sends))
                {
                    send.continuationDone = true;
                    release(send);
                }
            }
        }
    }

    /** One timer worker, at most two physical jobs. Cancellation never releases a running job. */
    private static final class Timers implements Scheduler {
        private final ScheduledThreadPoolExecutor executor=new ScheduledThreadPoolExecutor(1,Thread.ofPlatform().daemon(true).name("ott-routing-timer").factory());
        private final Set<Job> jobs=new HashSet<>();private boolean stopped;
        Timers(){executor.setRemoveOnCancelPolicy(true);}
        private final class Job implements Ticket,Runnable {
            final Runnable task;final AtomicInteger state=new AtomicInteger();ScheduledFuture<?> future;
            Job(Runnable task){this.task=task;}
            public void run(){if(!state.compareAndSet(0,1))return;try{task.run();}finally{state.set(2);synchronized(Timers.this){jobs.remove(this);}}}
            public void cancel(){if(state.compareAndSet(0,3)){synchronized(Timers.this){if(future!=null)future.cancel(false);jobs.remove(this);}}}
        }
        public synchronized Ticket schedule(Runnable task,long delay){
            if(delay<0||stopped||jobs.size()>=2)throw new RejectedExecutionException("Routing timer capacity");
            var job=new Job(task);jobs.add(job);try{job.future=executor.schedule(job,delay,TimeUnit.NANOSECONDS);}catch(RuntimeException e){jobs.remove(job);throw e;}return job;
        }
        public synchronized void requestClose(){if(stopped)return;stopped=true;for(var job:List.copyOf(jobs))job.cancel();executor.shutdown();}
        public boolean awaitTermination(Duration budget){try{return executor.awaitTermination(nanos(budget),TimeUnit.NANOSECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();return false;}}
        public synchronized int physicalJobs(){return jobs.size();}
    }
}
