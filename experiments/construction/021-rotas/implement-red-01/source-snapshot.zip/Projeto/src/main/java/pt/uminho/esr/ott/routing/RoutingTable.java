package pt.uminho.esr.ott.routing;

import java.util.*;
import java.util.function.LongSupplier;

/** In-memory planning domain. All methods must run on the node's existing serial owner. */
public final class RoutingTable {
    public record SessionKey(String nodeId, UUID instanceId, UUID connectionId) {
        public SessionKey {
            RoutingTable.nodeId(nodeId); Objects.requireNonNull(instanceId); Objects.requireNonNull(connectionId);
            if (instanceId.equals(new UUID(0, 0))) throw new IllegalArgumentException("Nonzero instance required");
        }
    }
    public record Advertisement(UUID streamId, String serverId, UUID serverEpoch, SessionKey session,
            long announceSeq, long advertisedCostMicros, List<String> advertisedPath) {
        public Advertisement {
            Objects.requireNonNull(streamId); nodeId(serverId); Objects.requireNonNull(serverEpoch);
            Objects.requireNonNull(session); Objects.requireNonNull(advertisedPath);
            if (announceSeq < 0 || advertisedCostMicros < 0 || advertisedPath.isEmpty() || advertisedPath.size() > 31)
                throw new IllegalArgumentException("Invalid advertisement bounds");
            for (String id : advertisedPath) nodeId(id);
            advertisedPath = List.copyOf(advertisedPath);
        }
    }
    public record Limits(int origins, int streamsPerOrigin, int neighbors, int retiredEpochsPerOrigin) {
        public Limits {
            if (origins < 1 || origins > 64 || streamsPerOrigin < 1 || streamsPerOrigin > 256
                    || neighbors < 1 || neighbors > 63 || retiredEpochsPerOrigin < 1 || retiredEpochsPerOrigin > 8)
                throw new IllegalArgumentException("Invalid table limits");
            Math.multiplyExact(Math.multiplyExact(origins, streamsPerOrigin), neighbors);
        }
        public static Limits forNode(int maxConnections) {
            if (maxConnections < 1 || maxConnections > 64) throw new IllegalArgumentException("Invalid connection limit");
            return new Limits(64, 256, Math.min(maxConnections, 63), 8);
        }
        public int streamCapacity() { return Math.multiplyExact(origins, streamsPerOrigin); }
        public int slotCapacity() { return Math.multiplyExact(streamCapacity(), neighbors); }
    }
    public enum Status { APPLIED, IGNORED, REJECTED }
    public enum Reason {
        NONE, DUPLICATE, STALE_SEQUENCE, GENERATION_EXPIRED, WITHDRAWN_GENERATION,
        STALE_SESSION, STALE_EPOCH, RETIRED_EPOCH, UNKNOWN_STREAM, ORIGIN_CONFLICT,
        INVALID_INPUT, CAPACITY_EXCEEDED, REVISION_EXHAUSTED
    }
    public record Outcome(Status status, Reason reason, Set<UUID> changedStreams) {
        public Outcome {
            Objects.requireNonNull(status); Objects.requireNonNull(reason); Objects.requireNonNull(changedStreams);
            if (changedStreams.size() > 16_384) throw new IllegalArgumentException("Too many changed streams");
            changedStreams = Set.copyOf(changedStreams);
        }
    }
    static void nodeId(String value) {
        Objects.requireNonNull(value);
        if (!value.matches("[A-Za-z0-9_-]{1,32}")) throw new IllegalArgumentException("Invalid node ID");
    }
    static long nextRevision(long current) {
        if (current < 0) throw new IllegalArgumentException("Negative revision");
        return Math.incrementExact(current);
    }

    public RoutingTable(String localNodeId, Limits limits, long candidateTtlMillis,
            long historyTtlMillis, LongSupplier nanoTime) {
        nodeId(localNodeId); Objects.requireNonNull(limits); Objects.requireNonNull(nanoTime);
        if (candidateTtlMillis < 1 || historyTtlMillis < candidateTtlMillis || historyTtlMillis > Integer.MAX_VALUE)
            throw new IllegalArgumentException("Invalid history horizons");
        Math.multiplyExact(candidateTtlMillis, 1_000_000L); Math.multiplyExact(historyTtlMillis, 1_000_000L);
    }
    private Outcome absent() { return new Outcome(Status.REJECTED, Reason.NONE, Set.of()); }
    public Outcome bindStream(UUID streamId, String expectedServerId) { return absent(); }
    public Outcome replaceSession(Optional<SessionKey> expected, SessionKey replacement) { return absent(); }
    public Outcome removeSession(SessionKey session) { return absent(); }
    public Outcome setLinkCost(SessionKey session, OptionalLong costMicros) { return absent(); }
    public Outcome confirmEpoch(String serverId, Optional<UUID> expectedCurrent, UUID replacement) { return absent(); }
    public Outcome offerLocal(UUID streamId, UUID epoch) { return absent(); }
    public Outcome removeLocalOffer(UUID streamId, UUID epoch) { return absent(); }
    public Outcome announce(Advertisement advertisement) { return absent(); }
    public Outcome withdraw(UUID streamId, UUID epoch, SessionKey session, long sequence) { return absent(); }
    public Outcome expire() { return absent(); }
    public Optional<Route> snapshot(UUID streamId) { return Optional.empty(); }
}
